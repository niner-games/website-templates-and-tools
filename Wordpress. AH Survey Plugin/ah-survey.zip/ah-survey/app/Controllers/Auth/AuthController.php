<?php

namespace App\Controllers\Auth;

use App\Models\User;

class AuthController {

   
}
