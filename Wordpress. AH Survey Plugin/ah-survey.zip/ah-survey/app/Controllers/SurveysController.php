<?php

namespace App\Controllers;

use App\Helpers\Publics;
use App\Helpers\Validation;
use App\Mail\Mailer;
use App\Models\Surveys;
use App\Models\Users;
use App\Models\Responses;
use Carbon\Carbon;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Exception;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use Illuminate\Database\Capsule\Manager as DB;

class SurveysController extends Controller {

	/**
	 * @throws \Twig\Error\SyntaxError
	 * @throws \Twig\Error\RuntimeError
	 * @throws \Twig\Error\LoaderError
	 */
	static public function index() {
		if ( isset( $_GET['edit'] ) and ! empty( $_GET['edit'] ) and is_numeric( $_GET['edit'] ) ) {
			$Surveys = Surveys::orderBy( 'created_at', 'DESC' )->get();
			$Survey  = Surveys::where( 'id', $_GET['edit'] )->first();
			echo parent::views()->render( 'surveys/edit.twig', [
				'Surveys'              => $Surveys,
				'Surveys_json'         => json_encode( $Surveys->toArray() ),
				'Survey'               => ( $Survey && $Survey->id ) ? self::survey_data( $Survey ) : [],
				'ajax_url'             => admin_url( 'admin-ajax.php' ),
				'plugin_url'           => admin_url( 'admin.php?page=ah-survey' ),
				'create_new_url'       => admin_url( 'admin.php?page=ah-survey-create-new' ),
				'edit_surveys_nonce'   => wp_create_nonce( "edit_surveys_nonce" ),
				'delete_surveys_nonce' => wp_create_nonce( "delete_surveys_nonce" ),
				'general_settings'     => SettingsController::get_options( 'general_settings' )
			] );
		} else {
			echo parent::views()->render( 'surveys/index.twig', [
				'ajax_url'             => admin_url( 'admin-ajax.php' ),
				'plugin_url'           => admin_url( 'admin.php?page=ah-survey' ),
				'create_new_url'       => admin_url( 'admin.php?page=ah-survey-create-new' ),
				'list_surveys_nonce'   => wp_create_nonce( "list_surveys_nonce" ),
				'delete_surveys_nonce' => wp_create_nonce( "delete_surveys_nonce" ),
				'import_surveys_nonce' => wp_create_nonce( "import_surveys_nonce" )
			] );
		}
	}

	/**
	 * @throws \Twig\Error\SyntaxError
	 * @throws \Twig\Error\RuntimeError
	 * @throws \Twig\Error\LoaderError
	 */
	static public function create() {
		$Surveys = Surveys::orderBy( 'created_at', 'DESC' )->get();
		echo parent::views()->render( 'surveys/new.twig', [
			'ajax_url'          => admin_url( 'admin-ajax.php' ),
			'plugin_url'        => admin_url( 'admin.php?page=ah-survey' ),
			'new_surveys_nonce' => wp_create_nonce( "new_surveys_nonce" ),
			'Surveys'           => $Surveys,
			'Surveys_json'      => json_encode( $Surveys->toArray() ),
			'general_settings'  => SettingsController::get_options( 'general_settings' )
		] );
	}

	static public function get() {
		$list = [];
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'list_surveys_nonce' ) ) {
			header( 'Content-Type: application/json' );
			$Surveys = Surveys::with( [ 'responses' ] )->orderBy( 'created_at', 'DESC' )->get();
			foreach ( $Surveys as $key => $survey ) {
				$list[ $key ]['id']                       = $survey['id'];
				$list[ $key ]['title']                    = $survey['title'];
				$list[ $key ]['description']              = $survey['description'];
				$list[ $key ]['welcome_message']          = $survey['welcome_message'];
				$list[ $key ]['end_message']              = $survey['end_message'];
				$list[ $key ]['is_active']                = (bool) $survey['is_active'];
				$list[ $key ]['start_date']               = Publics::fullDate( $survey['start_date'], false );
				$list[ $key ]['expire_date']              = ( isset( $survey['expire_date'] ) and ! empty( $survey['expire_date'] ) ) ? Publics::fullDate( $survey['expire_date'], false ) : '';
				$list[ $key ]['allow_prev']               = (bool) $survey['allow_prev'];
				$list[ $key ]['allow_multiple_responses'] = (bool) $survey['allow_multiple_responses'];
				$list[ $key ]['allow_progress_bar']       = (bool) $survey['allow_progress_bar'];
				$list[ $key ]['response_type']            = $survey['response_type'];
				$list[ $key ]['survey_view']              = $survey['survey_view'];
				$list[ $key ]['questions']                = ( $survey['questions'] and ! empty( $survey['questions'] ) ) ? unserialize( $survey['questions'] ) : [];
				$list[ $key ]['responses_count']          = $survey->responses->count();
				$list[ $key ]['created_at']               = Publics::fullDate( $survey['created_at'] );
				$list[ $key ]['updated_at']               = Publics::fullDate( $survey['updated_at'] );
			}
			exit( json_encode( $list, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) );
		}
	}

	public static function save() {
		header( 'Content-Type: application/json' );
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'new_surveys_nonce' ) ) {
			$validator = new Validation();
			$validator->name( 'survey_title' )->value( Publics::http_post( 'survey_title' ) )->required()->min( 3 );
			if ( $validator->isSuccess() ) {
				$Survey = Surveys::create( [
					'title'                    => Publics::http_post( 'survey_title' ),
					'description'              => Publics::http_post( 'survey_description' ),
					'welcome_message'          => '',
					'end_message'              => Publics::http_post( 'survey_end_message' ),
					'is_active'                => (int) Publics::http_post( 'survey_active' ),
					'start_date'               => Carbon::parse( Publics::http_post( 'survey_start_date' ) )->toDateTimeString(),
					'expire_date'              => ( isset( $_POST['survey_expire_date'] ) and ! empty( $_POST['survey_expire_date'] ) ) ? Carbon::parse( Publics::http_post( 'survey_expire_date' ) )->toDateTimeString() : null,
					'allow_prev'               => (int) Publics::http_post( 'survey_allow_backward' ),
					'allow_multiple_responses' => (int) Publics::http_post( 'survey_multiple_responses' ),
					'allow_progress_bar'       => (int) Publics::http_post( 'survey_show_progress_bar' ),
					'response_type'            => Publics::http_post( 'survey_response_type' ),
					'survey_view'              => Publics::http_post( 'survey_view' ),
					'questions'                => serialize( json_decode( stripcslashes( Publics::http_post( 'survey_questions' ) ), true ) )
				] );
				$meta   = Publics::http_post( 'meta' );
				if ( $meta and is_array( $meta ) and count( $meta ) >= 1 ) {
					foreach ( $meta as $key => $value ) {
						$Survey->meta()->updateOrCreate( [
							'meta_key'   => $key,
							'meta_value' => $value
						] );
					}
				}
				Publics::http_response_code( 200 );
				exit( json_encode( [
					'type'      => 'success',
					'survey_id' => $Survey->id,
					'message'   => esc_html__( 'Survey has been created', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );
			} else {
				Publics::http_response_code( 422 );
				exit( json_encode( [
					'type'    => 'error',
					'message' => $validator->getErrors()
				], JSON_PRETTY_PRINT ) );
			}
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => 'error',
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	public static function update() {
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'edit_surveys_nonce' ) ) {
			$validator = new Validation();
			$validator->name( 'survey_title' )->value( Publics::http_post( 'survey_title' ) )->required()->min( 3 );
			if ( $validator->isSuccess() ) {
				$Survey = Surveys::where( 'id', Publics::http_post( 'survey_id' ) )->first();
				$Survey->update( [
					'title'                    => Publics::http_post( 'survey_title' ),
					'description'              => Publics::http_post( 'survey_description' ),
					'welcome_message'          => '',
					'end_message'              => Publics::http_post( 'survey_end_message' ),
					'is_active'                => (int) Publics::http_post( 'survey_active' ),
					'start_date'               => Carbon::parse( Publics::http_post( 'survey_start_date' ) )->toDateTimeString(),
					'expire_date'              => ( isset( $_POST['survey_expire_date'] ) and ! empty( $_POST['survey_expire_date'] ) ) ? Carbon::parse( Publics::http_post( 'survey_expire_date' ) )->toDateTimeString() : null,
					'allow_prev'               => (int) Publics::http_post( 'survey_allow_backward' ),
					'allow_multiple_responses' => (int) Publics::http_post( 'survey_multiple_responses' ),
					'allow_progress_bar'       => (int) Publics::http_post( 'survey_show_progress_bar' ),
					'response_type'            => Publics::http_post( 'survey_response_type' ),
					'survey_view'              => Publics::http_post( 'survey_view' ),
					'questions'                => serialize( json_decode( stripcslashes( Publics::http_post( 'survey_questions' ) ), true ) )
				] );
				$meta = Publics::http_post( 'meta' );
				if ( $meta and is_array( $meta ) and count( $meta ) >= 1 ) {
					foreach ( $meta as $key => $value ) {
						$survey_meta = $Survey->meta()->where( 'meta_key', $key );
						if ( $survey_meta ) {
							$survey_meta->delete();
						}
						$Survey->meta()->updateOrCreate( [
							'meta_key'   => $key,
							'meta_value' => $value
						] );
					}
				}
				Publics::http_response_code( 200 );
				exit( json_encode( [
					'type'    => 'success',
					'message' => esc_html__( 'Survey has been updated', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );
			} else {
				Publics::http_response_code( 422 );
				exit( json_encode( [
					'type'    => 'error',
					'message' => $validator->getErrors()
				], JSON_PRETTY_PRINT ) );
			}
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => 'error',
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	static public function delete() {
		header( 'Content-Type: application/json' );
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'delete_surveys_nonce' ) ) {
			$Surveys = Surveys::where( 'id', Publics::http_post( 'ID' ) )->first();
			if ( $Surveys ) {
				$Surveys->delete();
				$Surveys->meta()->delete();
				$Surveys->responses()->delete();
				Publics::http_response_code( 200 );
				exit( json_encode( [
					'type'    => 'success',
					'message' => esc_html__( 'Survey was deleted', 'ah-survey' )
				], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) );
			} else {
				Publics::http_response_code( 404 );
			}
		}
	}

	static public function login() {
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'ah_surveys_login_nonce' ) ) {
			$validator = new Validation();
			$validator->name( 'ah_survey_username' )->value( Publics::http_post( 'ah_survey_username' ) )->required();
			$validator->name( 'ah_survey_password' )->value( Publics::http_post( 'ah_survey_password' ) )->required();
			if ( $validator->isSuccess() ) {
				$info                  = [];
				$info['user_login']    = Publics::http_post( 'ah_survey_username' );
				$info['user_password'] = Publics::http_post( 'ah_survey_password' );
				$info['remember']      = true;
				$user_signon           = wp_signon( $info, false );
				if ( is_wp_error( $user_signon ) ) {
					Publics::http_response_code( 401 );
					exit( json_encode( [
						'type'    => esc_html__( 'Error', 'ah-survey' ),
						'message' => $user_signon->get_error_message()
					], JSON_PRETTY_PRINT ) );
				} else {
					Publics::http_response_code( 200 );
					exit( json_encode( [
						'type'    => 'success',
						'message' => esc_html__( 'Login successful', 'ah-survey' )
					], JSON_PRETTY_PRINT ) );
				}
			} else {
				Publics::http_response_code( 422 );
				exit( json_encode( [
					'type'    => esc_html__( 'Error', 'ah-survey' ),
					'message' => $validator->getErrors()
				], JSON_PRETTY_PRINT ) );
			}
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => esc_html__( 'Error', 'ah-survey' ),
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	static public function survey_submit() {
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'ah_surveys_submit_nonce' ) ) {
			$list        = [];
			$answers     = Publics::http_post( 'answers' );
			$Survey      = Surveys::where( 'id', Publics::http_post( 'survey_id' ) )->with( [ 'meta' ] )->first();
			$Survey_Meta = [];
			if ( $Survey ) {
				if ( $Survey and $Survey->meta() ) {
					foreach ( $Survey->meta()->get() as $meta ) {
						$Survey_Meta[ $meta['meta_key'] ] = $meta['meta_value'];
					}
				}
				$Questions = self::survey_data( $Survey, false )['questions'];
				foreach ( $Questions as $key => $value ) {
					$list[ $key ]['uid']  = $value['uid'];
					$list[ $key ]['type'] = $value['type'];
					if ( $value['type'] == 'short-text' ) {
						if ( isset( $value['options'] ) and isset( $value['options']['input_mask'] ) ) {
							if ( $value['options']['input_mask'] == 'date_time' ) {
								$date_time = Carbon::now( TIME_ZONE );
								if ( isset( $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ] ) ) {
									$date_time = Carbon::parse( $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ], TIME_ZONE );
								} else {
									$list[ $key ]['answers'] = '';
								}
								$list[ $key ]['answers'] = $date_time->format( 'Y-m-d [ h:i A ]' );
							} else if ( $value['options']['input_mask'] == 'date' ) {
								$date = Carbon::now( TIME_ZONE );
								if ( isset( $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ] ) ) {
									$date = Carbon::parse( $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ], TIME_ZONE );
								} else {
									$list[ $key ]['answers'] = '';
								}
								$list[ $key ]['answers'] = $date->format( 'Y-m-d' );
							} else if ( $value['options']['input_mask'] == 'time' ) {
								$time = Carbon::now( TIME_ZONE );
								if ( isset( $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ] ) ) {
									$time = Carbon::parse( $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ], TIME_ZONE );
								} else {
									$list[ $key ]['answers'] = '';
								}
								$list[ $key ]['answers'] = $time->format( 'h:i A' );
							} else {
								if ( isset( $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ] ) ) {
									$list[ $key ]['answers'] = $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ];
								} else {
									$list[ $key ]['answers'] = '';
								}
							}
						}
					} else if ( $value['type'] == 'checkbox-list' ) {
						$checkbox_list = [];
						if ( isset( $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ] ) ) {
							$answers_list = $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ];
							if ( $answers_list and is_array( $answers_list ) ) {
								foreach ( $answers_list as $a_key => $answer ) {
									if ( $answer == 'true' ) {
										$checkbox_list[] = $a_key;
									}
								}
							}
						}
						$list[ $key ]['answers'] = $checkbox_list;
					} else {
						if ( isset( $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ] ) ) {
							$list[ $key ]['answers'] = $answers[ Publics::http_post( 'survey_id' ) ][ $value['uid'] ];
						} else {
							$list[ $key ]['answers'] = '';
						}
					}
				}
				$Response = Responses::create( [
					'participant_id'   => ( is_user_logged_in() ) ? get_current_user_id() : 0,
					'participant_type' => ( is_user_logged_in() ) ? 'user' : 'guest',
					'participant_ip'   => Publics::get_client_ip(),
					'survey_id'        => Publics::http_post( 'survey_id' ),
					'answers'          => serialize( $list ),
				] );
				if ( isset( $Survey_Meta ) and isset( $Survey_Meta['send_responses_email'] ) and $Survey_Meta['send_responses_email'] == 'true' ) {
					$answers_list     = [];
					$answers          = ( $Response['answers'] and ! empty( $Response['answers'] ) ) ? unserialize( $Response['answers'] ) : [];
					$questions        = ( $Survey['questions'] and ! empty( $Survey['questions'] ) ) ? unserialize( $Survey['questions'] ) : [];
					$general_settings = SettingsController::get_options( 'general_settings' );
					$to_emails        = ( ! empty( $Survey_Meta['emails_list'] ) ) ? $Survey_Meta['emails_list'] : $general_settings->activity_email;
					foreach ( $answers as $a_key => $answer ) {
						$question                           = self::array_search( $questions, 'uid', $answer['uid'] );
						$answers_list[ $a_key ]['uid']      = $answer['uid'];
						$answers_list[ $a_key ]['question'] = ( isset( $question ) and isset( $question[0] ) ) ? $question[0] : '';
						$answers_list[ $a_key ]['type']     = $answer['type'];
						$answers_list[ $a_key ]['answer']   = $answer['answers'];
					}
					Mailer::send( 'emails/response.email.twig', [
						'to'      => $to_emails,
						'subject' => "[AH-Survey] - " . esc_html__( 'New response on survey', 'ah-survey' ) . "( {$Survey->title} )",
						'body'    => [
							'site_name'      => get_bloginfo( 'name' ),
							'site_url'       => get_bloginfo( 'url' ),
							'icons_url'      => AH_Survey_URL . '/assets/images/response-icons',
							'survey_title'   => $Survey->title,
							'date_time'      => Publics::fullDate( $Response->created_at ),
							'participant'    => [
								'type'   => $Response['participant_type'],
								'ip'     => $Response['participant_ip'],
								'data'   => ( $Response->participant() and $Response->participant()->first() ) ? $Response->participant()->first()->toArray() : [],
								'avatar' => str_replace( 'http://', 'https://', get_avatar_data( $Response['participant']['user_email'] ) )
							],
							'answers_list'   => $answers_list,
							'icon_style_url' => AH_Survey_URL . '/assets/icons/flaticon.css',
							'emoji_text'     => [
								'angry'      => esc_html__( 'Angry', 'ah-survey' ),
								'sad'        => esc_html__( 'Sad', 'ah-survey' ),
								'normal'     => esc_html__( 'Normal', 'ah-survey' ),
								'happy'      => esc_html__( 'Happy', 'ah-survey' ),
								'very-happy' => esc_html__( 'Very-happy', 'ah-survey' ),
							]
						]
					] );
				}
				Publics::http_response_code( 200 );
				exit( json_encode( [
					'type'          => esc_html__( 'Success', 'ah-survey' ),
					'$answers_list' => $answers_list,
					'message'       => esc_html__( 'Survey submitted', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );
			} else {
				Publics::http_response_code( 404 );
				exit( json_encode( [
					'type'    => esc_html__( 'Error', 'ah-survey' ),
					'message' => esc_html__( 'Survey ID not found', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );
			}
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => esc_html__( 'Error', 'ah-survey' ),
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	static public function responses() {
		echo parent::views()->render( 'surveys/responses.twig', [
			'ajax_url'        => admin_url( 'admin-ajax.php' ),
			'plugin_url'      => admin_url( 'admin.php?page=ah-survey' ),
			'responses_nonce' => wp_create_nonce( "ah_surveys_responses_nonce" ),
			'Surveys'         => Surveys::withCount( [ 'responses' ] )->get(),
		] );
	}

	static public function get_responses() {
		header( 'Content-Type: application/json' );
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'ah_surveys_responses_nonce' ) ) {
			//			DB::enableQueryLog();
			$list      = [];
			$Responses = Responses::with( 'participant' )->with( [ 'survey' ] )->orderBy( 'created_at', 'DESC' )->get();
			foreach ( $Responses as $key => $response ) {
				$list[ $key ]['id']                    = $response['res_id'];
				$list[ $key ]['participant_type']      = $response['participant_type'];
				$list[ $key ]['participant_ip']        = $response['participant_ip'];
				$list[ $key ]['participant']           = $response['participant'];
				$list[ $key ]['participant']['avatar'] = get_avatar_data( $response['participant']['user_email'] );
				$list[ $key ]['survey_id']             = $response['survey_id'];
				if ( $response['survey'] and $response['survey_id'] ) {
					$survey                                             = $response['survey'];
					$list[ $key ]['survey']['id']                       = $survey['id'];
					$list[ $key ]['survey']['title']                    = $survey['title'];
					$list[ $key ]['survey']['description']              = $survey['description'];
					$list[ $key ]['survey']['welcome_message']          = $survey['welcome_message'];
					$list[ $key ]['survey']['end_message']              = $survey['end_message'];
					$list[ $key ]['survey']['is_active']                = (bool) $survey['is_active'];
					$list[ $key ]['survey']['start_date']               = Publics::fullDate( $survey['start_date'], false );
					$list[ $key ]['survey']['expire_date']              = ( isset( $survey['expire_date'] ) and ! empty( $survey['expire_date'] ) ) ? Publics::fullDate( $survey['expire_date'], false ) : '';
					$list[ $key ]['survey']['allow_prev']               = (bool) $survey['allow_prev'];
					$list[ $key ]['survey']['allow_multiple_responses'] = (bool) $survey['allow_multiple_responses'];
					$list[ $key ]['survey']['allow_progress_bar']       = (bool) $survey['allow_progress_bar'];
					$list[ $key ]['survey']['response_type']            = $survey['response_type'];
					$list[ $key ]['survey']['survey_view']              = $survey['survey_view'];
					$list[ $key ]['survey']['questions']                = ( $survey['questions'] and ! empty( $survey['questions'] ) ) ? unserialize( $survey['questions'] ) : [];
				} else {
					$list[ $key ]['survey'] = [];
				}
				$answers = ( $response['answers'] and ! empty( $response['answers'] ) ) ? unserialize( $response['answers'] ) : [];
				foreach ( $answers as $a_key => $answer ) {
					$question                                      = self::array_search( $list[ $key ]['survey']['questions'], 'uid', $answer['uid'] );
					$list[ $key ]['answers'][ $a_key ]['uid']      = $answer['uid'];
					$list[ $key ]['answers'][ $a_key ]['question'] = ( isset( $question ) and isset( $question[0] ) ) ? $question[0] : '';
					$list[ $key ]['answers'][ $a_key ]['type']     = $answer['type'];
					$list[ $key ]['answers'][ $a_key ]['answer']   = $answer['answers'];
				}
				$list[ $key ]['created_at'] = Publics::fullDate( $response['created_at'] );
			}
			//			$queries = DB::getQueryLog();
			exit( json_encode( $list, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) );
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => 'error',
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	static public function delete_responses() {
		header( 'Content-Type: application/json' );
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'ah_surveys_responses_nonce' ) ) {
			$ids = Publics::http_post( 'ids' );
			$id  = Publics::http_post( 'id' );
			Publics::http_response_code( 200 );
			if ( $ids and is_array( $ids ) and count( $ids ) ) {
				$responses = Responses::whereIn( 'res_id', $ids );
				$responses->delete();
				exit( json_encode( [
					'type'    => 'success',
					'message' => esc_html__( 'Responses was deleted', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );
			} else {
				Responses::where( 'res_id', $id )->delete();
				exit( json_encode( [
					'type'    => 'success',
					'message' => esc_html__( 'Response was deleted', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );
			}
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => 'error',
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	static public function export_responses() {
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'ah_surveys_responses_nonce' ) ) {
			$list             = [];
			$letters          = json_decode( '["A","B","C","D","E","F","G","H","I","J","K","l","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","AA","AB","AC","AD","AE","AF","AG","AH","AI","AJ","AK","Al","AM","AN","AO","AP","AQ","AR","AS","AT","AU","AV","AW","AX","AY","AZ","BA","BB","BC","BD","BE","BF","BG","BH","BI","BJ","BK","Bl","BM","BN","BO","BP","BQ","BR","BS","BT","BU","BV","BW","BX","BY","BZ","CA","CB","CC","CD","CE","CF","CG","CH","CI","CJ","CK","Cl","CM","CN","CO","CP","CQ","CR","CS","CT","CU","CV","CW","CX","CY","CZ","DA","DB","DC","DD","DE","DF","DG","DH","DI","DJ","DK","Dl","DM","DN","DO","DP","DQ","DR","DS","DT","DU","DV","DW","DX","DY","DZ","EA","EB","EC","ED","EE","EF","EG","EH","EI","EJ","EK","El","EM","EN","EO","EP","EQ","ER","ES","ET","EU","EV","EW","EX","EY","EZ","FA","FB","FC","FD","FE","FF","FG","FH","FI","FJ","FK","Fl","FM","FN","FO","FP","FQ","FR","FS","FT","FU","FV","FW","FX","FY","FZ","GA","GB","GC","GD","GE","GF","GG","GH","GI","GJ","GK","Gl","GM","GN","GO","GP","GQ","GR","GS","GT","GU","GV","GW","GX","GY","GZ"]', true );
			$Responses        = Responses::where( 'survey_id', Publics::http_post( 'survey_id' ) )->with( [ 'participant', 'survey' ] )->orderBy( 'created_at', 'DESC' )->get();
			$Surveys          = Surveys::where( 'id', Publics::http_post( 'survey_id' ) )->first();
			$questions        = ( isset( $Surveys['questions'] ) and ! empty( $Surveys['questions'] ) ) ? unserialize( $Surveys['questions'] ) : [];
			$general_settings = SettingsController::get_options( 'general_settings' );
			foreach ( $Responses as $key => $response ) {
				$list[ $key ]['id']                 = $response['res_id'];
				$list[ $key ]['participant_type']   = $response['participant_type'];
				$list[ $key ]['participant_ip']     = $response['participant_ip'];
				$list[ $key ]['participant_name']   = ( isset( $response['participant'] ) and isset( $response['participant']->display_name ) ) ? $response['participant']->display_name : __( 'Guest' );
				$list[ $key ]['participant_email']  = ( isset( $response['participant'] ) and isset( $response['participant']->user_email ) ) ? $response['participant']->user_email : '';
				$list[ $key ]['participant_avatar'] = ( isset( $response['participant'] ) and isset( $response['participant']->user_email ) ) ? get_avatar_data( $response['participant']['user_email'] ) : '';
				$list[ $key ]['survey_id']          = $response['survey_id'];
				$list[ $key ]['survey_title']       = $response['survey']->title;
				$answers                            = ( $response['answers'] and ! empty( $response['answers'] ) ) ? unserialize( $response['answers'] ) : [];
				foreach ( $answers as $a_key => $answer ) {
					$question                                      = self::array_search( $questions, 'uid', $answer['uid'] );
					$list[ $key ]['answers'][ $a_key ]['uid']      = $answer['uid'];
					$list[ $key ]['answers'][ $a_key ]['question'] = ( isset( $question[0] ) and isset( $question[0]['name'] ) ) ? $question[0]['name'] : '';
					$list[ $key ]['answers'][ $a_key ]['type']     = $answer['type'];
					$list[ $key ]['answers'][ $a_key ]['answer']   = $answer['answers'];
				}
				$list[ $key ]['created_at'] = Publics::fullDate( $response['created_at'] );
			}
			//			exit(Publics::dump_r($list));
			$spreadsheet = new Spreadsheet();
			$sheet       = $spreadsheet->getActiveSheet();
			$sheet->setCellValue( 'A1', 'Participant Name' );
			$sheet->setCellValue( 'B1', 'Participant Email' );
			$sheet->setCellValue( 'C1', 'Participant Location' );
			$sheet->setCellValue( 'D1', 'Response Date Time' );
			$start_cell = 3;
			$start_row  = 1;
			foreach ( $questions as $question ) {
				$start_cell ++;
				$sheet->setCellValue( $letters[ $start_cell ] . "1", $question['name'] );
			}
			foreach ( $list as $row ) {
				$start_row ++;
				$a_index = 0;
				$answers = $row['answers'];
				$sheet->setCellValue( "A{$start_row}", $row['participant_name'] );
				$sheet->setCellValue( "B{$start_row}", $row['participant_email'] );
				$sheet->setCellValue( "C{$start_row}", "http://ip-api.com/json/" . $row['participant_ip'] );
				$sheet->setCellValue( "D{$start_row}", $row['created_at'] );

				foreach ( $answers as $a_index => $answer ) {
					$question = self::array_search( $questions, 'uid', $answer['uid'] );
					$a_index ++;
					if ( isset( $question ) and isset( $question[0] ) and ! empty( $question[0] ) ) {
						//						$spreadsheet->getActiveSheet()->getStyle( $letters[ $a_index + 3 ] . $start_row )->getFont()->getColor()->setRGB( 'ddccbf' );
						$question_answer = ( is_array( $answer['answer'] ) ) ? implode( " , ", $answer['answer'] ) : $answer['answer'];
						$sheet->setCellValue( $letters[ $a_index + 3 ] . $start_row, $question_answer );
					}
				}
			}
			$types    = [
				'excel' => [
					'type' => 'Xlsx',
					'ext'  => 'xlsx',
				],
				'csv'   => [
					'type' => 'Csv',
					'ext'  => 'csv',
				],
				'html'  => [
					'type' => 'Html',
					'ext'  => 'html',
				]
			];
			$writer   = IOFactory::createWriter( $spreadsheet, $types[ Publics::http_post( 'export_type' ) ]['type'] );
			$title    = Publics::create_slug( $Surveys['title'] );
			$date     = date( 'd-m-Y h.i.A' );
			$ext      = strtolower( $types[ Publics::http_post( 'export_type' ) ]['ext'] );
			$file_url = AH_Survey_PATH . "storage/Response({$title})-({$date}).{$ext}";
			$writer->save( $file_url );
			header( 'Content-Encoding: UTF-8' );
			header( 'Content-Type: application/octet-stream; charset=UTF-8' );
			header( "Content-Transfer-Encoding: Binary" );
			header( "Content-disposition: attachment; filename=" . str_replace( AH_Survey_PATH, '', $file_url ) );
			readfile( $file_url );
			if ( $general_settings->empty_storage == 'true' ) {
				unlink( $file_url );
			}
			exit();
		}
	}

	static public function export_survey() {
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'edit_surveys_nonce' ) ) {
			$Survey           = Surveys::where( 'id', Publics::http_get( 'ID' ) )->with( [ 'meta' ] )->first();
			$general_settings = SettingsController::get_options( 'general_settings' );
			if ( $Survey ) {
				$data     = self::prepare_survey_data( $Survey );
				$date     = date( 'd-m-Y h.i.A' );
				$file_url = AH_Survey_PATH . "storage/ah-survey[{$Survey->id}]-" . ( ( Publics::http_get( 'type' ) == 'full-data' ) ? 'data' : 'questions' ) . '-export[' . $date . '].json';
				$fp       = fopen( $file_url, 'w' );
				fwrite( $fp, json_encode( ( Publics::http_get( 'type' ) == 'full-data' ) ? [ 'ah-survey-data' => $data ] : [ 'ah-survey-questions' => $data['questions'] ] ) );
				fclose( $fp );
				header( 'Content-Encoding: UTF-8' );
				header( 'Content-Type: application/octet-stream; charset=UTF-8' );
				header( "Content-Transfer-Encoding: Binary" );
				header( "Content-disposition: attachment; filename=" . str_replace( AH_Survey_PATH . 'storage/', '', $file_url ) );
				readfile( $file_url );
				if ( $general_settings->empty_storage == 'true' ) {
					unlink( $file_url );
				}
				exit();
			} else {
				header( 'Content-Type: application/json' );
				Publics::http_response_code( 404 );
				exit( json_encode( [
					'type'    => 'error',
					'message' => esc_html__( 'Invalid survey ID or not found', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );
			}
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => 'error',
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	static public function duplicate_survey() {
		header( 'Content-Type: application/json' );
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'edit_surveys_nonce' ) ) {
			$Survey = Surveys::where( 'id', Publics::http_post( 'ID' ) )->with( [ 'meta' ] )->first();
			if ( $Survey ) {
				$data             = self::prepare_survey_data( $Survey );
				$duplicate_survey = Surveys::create( [
					'title'                    => $data['title'] . " [duplicated]",
					'description'              => $data['description'],
					'welcome_message'          => '',
					'end_message'              => $data['end_message'],
					'is_active'                => (int) $data['is_active'],
					'start_date'               => Carbon::parse( $data['start_date'] )->toDateTimeString(),
					'expire_date'              => ( isset( $data['expire_date'] ) and ! empty( $data['expire_date'] ) ) ? Carbon::parse( $data['expire_date'] )->toDateTimeString() : null,
					'allow_prev'               => (int) $data['allow_prev'],
					'allow_multiple_responses' => (int) $data['allow_multiple_responses'],
					'allow_progress_bar'       => (int) $data['allow_progress_bar'],
					'response_type'            => $data['response_type'],
					'survey_view'              => $data['survey_view'],
					'questions'                => serialize( $data['questions'] )
				] );
				if ( $data['meta'] and count( $data['meta'] ) ) {
					$duplicate_survey->meta()->createMany( $data['meta'] );
				}
				Publics::http_response_code( 200 );
				exit( json_encode( [
					'type'    => 'success',
					'message' => esc_html__( 'Survey has been duplicated', 'ah-survey' ),
					'url'     => admin_url( "admin.php?page=ah-survey&edit={$duplicate_survey->id}" )
				], JSON_PRETTY_PRINT ) );
			} else {
				Publics::http_response_code( 404 );
				exit( json_encode( [
					'type'    => 'error',
					'message' => esc_html__( 'Invalid survey ID or not found', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );
			}
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => 'error',
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	static public function import_survey() {
		header( 'Content-Type: application/json' );
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'import_surveys_nonce' ) ) {
			$data          = Publics::http_post( 'survey_data' );
			$import_survey = Surveys::create( [
				'title'                    => $data['title'],
				'description'              => $data['description'],
				'welcome_message'          => '',
				'end_message'              => $data['end_message'],
				'is_active'                => (int) $data['is_active'],
				'start_date'               => Carbon::parse( $data['start_date'] )->toDateTimeString(),
				'expire_date'              => ( isset( $data['expire_date'] ) and ! empty( $data['expire_date'] ) ) ? Carbon::parse( $data['expire_date'] )->toDateTimeString() : null,
				'allow_prev'               => (int) $data['allow_prev'],
				'allow_multiple_responses' => (int) $data['allow_multiple_responses'],
				'allow_progress_bar'       => (int) $data['allow_progress_bar'],
				'response_type'            => $data['response_type'],
				'survey_view'              => $data['survey_view'],
				'questions'                => serialize( $data['questions'] )
			] );
			if ( $data['meta'] and count( $data['meta'] ) ) {
				$import_survey->meta()->createMany( $data['meta'] );
			}
			exit( json_encode( [
				'type'    => 'success',
				'message' => esc_html__( 'Survey has been imported', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => 'error',
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	public static function prepare_survey_data( $Survey ) {
		$data = [];
		if ( $Survey and $Survey->id and $Survey->title ) {
			$data['title']                    = $Survey->title;
			$data['description']              = $Survey->description;
			$data['welcome_message']          = $Survey->welcome_message;
			$data['end_message']              = $Survey->end_message;
			$data['is_active']                = $Survey->is_active;
			$data['start_date']               = $Survey->start_date;
			$data['expire_date']              = $Survey->expire_date;
			$data['allow_prev']               = $Survey->allow_prev;
			$data['allow_multiple_responses'] = $Survey->allow_multiple_responses;
			$data['allow_progress_bar']       = $Survey->allow_progress_bar;
			$data['response_type']            = $Survey->response_type;
			$data['survey_view']              = $Survey->survey_view;
			$data['questions']                = unserialize( $Survey->questions );
			if ( $Survey->meta and count( $Survey->meta ) ) {
				foreach ( $Survey->meta as $key => $meta ) {
					$data['meta'][ $key ]['meta_key']   = $meta->meta_key;
					$data['meta'][ $key ]['meta_value'] = $meta->meta_value;
				}
			} else {
				$data['meta'] = [];
			}
		}

		return $data;
	}

	static public function survey_data( $Survey, $questions_json = true ) {
		$list                             = [];
		$list['id']                       = $Survey['id'];
		$list['title']                    = stripcslashes( $Survey['title'] );
		$list['description']              = stripcslashes( $Survey['description'] );
		$list['welcome_message']          = stripcslashes( $Survey['welcome_message'] );
		$list['end_message']              = stripcslashes( $Survey['end_message'] );
		$list['is_active']                = (bool) $Survey['is_active'];
		$list['start_date']               = Publics::fullDate( $Survey['start_date'], false );
		$list['expire_date']              = ( isset( $Survey['expire_date'] ) and ! empty( $Survey['expire_date'] ) ) ? Publics::fullDate( $Survey['expire_date'], false ) : '';
		$list['allow_prev']               = (bool) $Survey['allow_prev'];
		$list['allow_multiple_responses'] = (bool) $Survey['allow_multiple_responses'];
		$list['allow_progress_bar']       = (bool) $Survey['allow_progress_bar'];
		$list['response_type']            = $Survey['response_type'];
		$list['survey_view']              = $Survey['survey_view'];
		if ( $questions_json ) {
			$list['questions'] = ( $Survey['questions'] and ! empty( $Survey['questions'] ) ) ? json_encode( unserialize( $Survey['questions'] ) ) : [];
		} else {
			$list['questions'] = ( $Survey['questions'] and ! empty( $Survey['questions'] ) ) ? unserialize( $Survey['questions'] ) : [];
		}
		$metas      = $Survey->meta()->get()->toArray();
		$metas_list = [];
		$metas_json = [];
		if ( $metas ) {
			foreach ( $metas as $m_key => $meta ) {
				$metas_list[ $m_key ]['meta_key']   = $meta['meta_key'];
				$metas_list[ $m_key ]['meta_value'] = $meta['meta_value'];
				$metas_json[ $meta['meta_key'] ]    = $meta['meta_value'];
			}
		}
		$list['meta']       = $metas_list;
		$list['meta_json']  = json_encode( $metas_json );
		$list['created_at'] = Publics::fullDate( $Survey['created_at'] );
		$list['updated_at'] = Publics::fullDate( $Survey['updated_at'] );

		return $list;
	}

	static public function array_search( $array, $key, $value ): array {
		$results = array();
		if ( is_array( $array ) ) {
			if ( isset( $array[ $key ] ) && $array[ $key ] == $value ) {
				$results[] = $array;
			}
			foreach ( $array as $subarray ) {
				$results = array_merge( $results, self::array_search( $subarray, $key, $value ) );
			}
		}

		return $results;
	}

}
