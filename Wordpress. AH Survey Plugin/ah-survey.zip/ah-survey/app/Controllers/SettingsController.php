<?php


namespace App\Controllers;

use App\Helpers\Publics;
use App\Models\Surveys;
use App\Models\Posts;

class SettingsController extends Controller {

	static protected $option_prefix = 'ah_survey_';

	static public function index() {
		$data = [
			'ajax_url'              => admin_url( 'admin-ajax.php' ),
			'setting_nonce'         => wp_create_nonce( "setting_nonce" ),
			'AH_Survey_VERSION'     => AH_Survey_VERSION,
			//			'pages'                 => get_pages(),
			'Surveys'               => Surveys::all(),
			'Pages'                 => Posts::where( [ 'post_status' => 'publish', 'post_type' => 'page' ] )->get( [ 'ID', 'post_title' ] ),
			'general_settings'      => self::get_options( 'general_settings', false ),
			'general_settings_json' => ( self::get_options( 'general_settings', false ) ) ? json_encode( self::get_options( 'general_settings', false ) ) : json_encode( [] ),
			'widget_settings'       => self::get_options( 'widget_settings', true ),
			'widget_settings_json'  => ( self::get_options( 'widget_settings', false ) ) ? json_encode( self::get_options( 'widget_settings', false ) ) : json_encode( [] ),
			'email_settings'        => self::get_options( 'email_settings', true ),
			'email_settings_json'   => ( self::get_options( 'email_settings', false ) ) ? json_encode( self::get_options( 'email_settings', false ) ) : json_encode( [] )
		];
		echo parent::views()->render( 'settings/index.twig', $data );
	}

	static public function save() {
		header( 'Content-Type: application/json' );
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'setting_nonce' ) ) {
			Publics::http_response_code( 200 );
			if ( isset( $_POST['ah_survey'] ) and ! empty( $_POST['ah_survey'] ) ) {
				foreach ( $_POST['ah_survey'] as $key => $value ) {
					update_option( self::$option_prefix . "{$key}", $value );
				}
			}
			exit( json_encode( [
				'type'    => 'success',
				'message' => esc_html__( 'Settings was saved', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => 'error',
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	static public function get_options( $option_name, $object = true ) {
		$panel_option = get_option( self::$option_prefix . $option_name );
		if ( $object ) {
			return isset( $panel_option ) ? self::array_to_obj( $panel_option ) : [];
		} else {
			return isset( $panel_option ) ? $panel_option : [];
		}
	}

	public static function send_test_mail() {
		global $phpmailer;
		header( 'Content-Type: application/json' );
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'setting_nonce' ) ) {
			$Options = self::get_options( 'email_settings', false );
			$to      = $_POST['test_email_to'];
			$subject = $_POST['test_email_subject'];
			$body    = $_POST['test_email_message'];
			if ( ! isset( $_POST['test_email_to'] ) or empty( $_POST['test_email_to'] ) ) {
				Publics::http_response_code( 422 );
				exit( json_encode( [
					'type'    => 'error',
					'message' => esc_html__( 'Email must not be empty', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );

			}
			if ( ! filter_var( $_POST['test_email_to'], FILTER_VALIDATE_EMAIL ) ) {
				Publics::http_response_code( 422 );
				exit( json_encode( [
					'type'    => 'error',
					'message' => esc_html__( 'Invalid email format', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );

			} else if ( ! isset( $_POST['test_email_subject'] ) or empty( trim( $_POST['test_email_subject'] ) ) ) {
				Publics::http_response_code( 422 );
				exit( json_encode( [
					'type'    => 'error',
					'message' => esc_html__( 'Subject must not be empty', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );
			}
			$headers = [
				'Content-Type: text/html; charset=UTF-8',
				'From: ' . $Options['from_name'] . ' <' . $Options['from_email'] . '>'
			];
			$send    = wp_mail( $to, $subject, $body, $headers );


			if ( isset( $phpmailer ) ) {
				$mail_errors = $phpmailer->ErrorInfo;
			}
			if ( ! $send ) {
				Publics::http_response_code( 422 );
				exit( json_encode( [
					'status'  => 'error',
					'message' => $mail_errors
				], JSON_PRETTY_PRINT ) );
			} else {
				Publics::http_response_code( 200 );
				exit( json_encode( [
					'status'  => 'success',
					'message' => esc_html__( 'Email sent successfully', 'ah-survey' )
				], JSON_PRETTY_PRINT ) );
			}
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => 'error',
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	public static function email_errors_log() {
		header( 'Content-Type: application/json' );
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'setting_nonce' ) ) {
			if ( function_exists( 'fopen' ) and function_exists( 'fgets' ) and function_exists( 'fclose' ) ) {
				$handle = fopen( AH_Survey_PATH . '/mail.log', "r" );
				$log    = [];
				if ( $handle ) {
					while ( ( $line = fgets( $handle ) ) !== false ) {
						$new_line = explode( '__', $line );
						$log[]    = $new_line;
					}
					fclose( $handle );
					Publics::http_response_code( 200 );
					exit( json_encode( [
						'status'  => 'success',
						'message' => array_reverse( $log, false )
					], JSON_PRETTY_PRINT ) );
				} else {
					Publics::http_response_code( 404 );
					exit( json_encode( [
						'type'    => 'error',
						'message' => esc_html__( 'Can not read log file', 'ah-survey' )
					], JSON_PRETTY_PRINT ) );
				}
			}
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => 'error',
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	public static function email_clear_log() {
		header( 'Content-Type: application/json' );
		if ( isset( $_POST ) and wp_verify_nonce( $_REQUEST['nonce'], 'setting_nonce' ) ) {
			if ( function_exists( 'fopen' ) and function_exists( 'fgets' ) and function_exists( 'fclose' ) ) {
				$handle = fopen( AH_Survey_PATH . '/mail.log', "w" );
				if ( $handle ) {
					fclose( $handle );
					Publics::http_response_code( 200 );
					exit( json_encode( [
						'status'  => 'success',
						'message' => esc_html__( 'Email errors log has been cleaned', 'ah-survey' )
					], JSON_PRETTY_PRINT ) );
				} else {
					Publics::http_response_code( 404 );
					exit( json_encode( [
						'type'    => 'error',
						'message' => esc_html__( 'Can not read log file', 'ah-survey' )
					], JSON_PRETTY_PRINT ) );
				}
			}
		} else {
			Publics::http_response_code( 400 );
			exit( json_encode( [
				'type'    => 'error',
				'message' => esc_html__( 'Bad Request', 'ah-survey' )
			], JSON_PRETTY_PRINT ) );
		}
	}

	static public function array_to_obj( $array ) {
		if ( $array ) {
			foreach ( $array as $key => $value ) {
				if ( is_array( $value ) ) {
					$array[ $key ] = self::array_to_object( $value );
				}
			}
		}

		return (object) $array;
	}
}