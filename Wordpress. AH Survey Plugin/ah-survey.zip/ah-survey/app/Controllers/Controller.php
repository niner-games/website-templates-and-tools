<?php

namespace App\Controllers;

use Twig\Loader\FilesystemLoader;
use Twig\Environment;
use buzzingpixel\twigswitch\SwitchTwigExtension;

class Controller {

	static public function views() {
		$loader = new FilesystemLoader( AH_Survey_ROOT_PATH . '/views' );
		$twig   = new Environment( $loader, [
			'debug' => ( defined( 'WP_DEBUG' ) and WP_DEBUG == true ) ? true : false,
			'cache' => AH_Survey_VIEWS_PATH . '/cache'
		] );
		$twig->addExtension( new \App\Twig\TwigExtension() );
		$twig->addExtension( new \Twig\Extension\StringLoaderExtension() );
		$twig->addExtension( new SwitchTwigExtension() );

		return $twig;
	}

}
