<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SurveysMeta extends Model {

	protected $table = 'ah_surveys_meta';
	public $timestamps = true;
	protected $primaryKey = 'meta_id';
	protected $fillable = [
		'meta_key',
		'meta_value',
		'survey_id'
	];

}
