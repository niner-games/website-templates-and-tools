<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static create( array $array )
 * @method static where( string $string, mixed|null $http_post )
 * @method static orderBy( string $string, string $string1 )
 */
class Posts extends Model {

	protected $table = 'posts';
	public $timestamps = true;
	protected $primaryKey = 'ID';

}