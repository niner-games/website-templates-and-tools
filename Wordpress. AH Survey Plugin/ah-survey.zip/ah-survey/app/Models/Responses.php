<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use \App\Models\Users;
use App\Models\Surveys;

/**
 * @method static where( string $string, mixed|null $http_post )
 * @method static whereIn( string $string, array|mixed|null $ids )
 */
class Responses extends Model {

	protected $table = 'ah_surveys_responses';
	public $timestamps = true;
	protected $primaryKey = 'res_id';
	protected $fillable = [
		'participant_id',
		'participant_type',
		'participant_ip',
		'survey_id',
		'answers'
	];

	// participant
	public function participant() {
		return $this->belongsTo( Users::class, 'participant_id' );
	}

	// survey
	public function survey() {
		return $this->belongsTo( Surveys::class, 'survey_id' );
	}

	public function setCreatedAtAttribute( $value ) {
		$this->attributes['created_at'] = Carbon::parse( $value )->setTimezone( get_option('timezone_string') );
	}

}
