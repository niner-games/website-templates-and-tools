<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use App\Models\SurveysMeta;
use App\Models\Responses;

/**
 * @method static create( array $array )
 * @method static where( string $string, mixed|null $http_post )
 * @method static orderBy( string $string, string $string1 )
 */
class Surveys extends Model {

	protected $table = 'ah_surveys';
	public $timestamps = true;
	protected $primaryKey = 'id';
	protected $fillable = [
		'title',
		'description',
		'welcome_message',
		'end_message',
		'is_active',
		'start_date',
		'expire_date',
		'allow_prev',
		'allow_multiple_responses',
		'allow_progress_bar',
		'response_type',
		'survey_view',
		'questions'
	];

	public function meta() {
		return $this->hasMany( SurveysMeta::class, 'survey_id', 'id' );
	}

	public function responses() {
		return $this->hasMany( Responses::class, 'survey_id', 'id' );
	}

	public function setCreatedAtAttribute( $value ) {
		$this->attributes['created_at'] = Carbon::parse( $value )->setTimezone( get_option('timezone_string') );
	}

}
