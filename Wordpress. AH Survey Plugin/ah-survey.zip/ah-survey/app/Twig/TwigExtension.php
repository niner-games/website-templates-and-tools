<?php

namespace App\Twig;

use App\Helpers\Publics;
use Carbon\Carbon;
use App\Helpers\QuestionsTypes;
use Twig\Extension\AbstractExtension;

class TwigExtension extends AbstractExtension {

	public function getName() {
		return 'app';
	}

	public function getFunctions() {
		return [
			new \Twig\TwigFunction( 'dump', [ $this, 'dump' ] ),
			new \Twig\TwigFunction( 'admin_url', [ $this, 'admin_url' ] ),
			new \Twig\TwigFunction( 'is_array', [ $this, 'is_array' ] ),
			new \Twig\TwigFunction( 'count', [ $this, 'count' ] ),
			new \Twig\TwigFunction( 'baseURL', [ $this, 'base_url' ] ),
			new \Twig\TwigFunction( '__', [ $this, '__' ] ),
			new \Twig\TwigFunction( 'get_avatar_url', [ $this, 'get_avatar_url' ] ),
			new \Twig\TwigFunction( 'http_get', [ $this, 'http_get' ] ),
			new \Twig\TwigFunction( 'full_date', [ $this, 'full_date' ] ),
			new \Twig\TwigFunction( 'date_now', [ $this, 'date_now' ] ),
			new \Twig\TwigFunction( 'twig_load', [ $this, 'twig_load' ] ),
			new \Twig\TwigFunction( 'plugin_path', [ $this, 'plugin_path' ] ),
			new \Twig\TwigFunction( 'views_path', [ $this, 'views_path' ] ),
			new \Twig\TwigFunction( 'base_url', [ $this, 'base_url' ] ),
			new \Twig\TwigFunction( 'do_shortcode', [ $this, 'do_shortcode' ] ),
			new \Twig\TwigFunction( 'selected', [ $this, 'selected' ] ),
			new \Twig\TwigFunction( 'ng_selected', [ $this, 'ng_selected' ] ),
			new \Twig\TwigFunction( 'checked', [ $this, 'checked' ] ),
			new \Twig\TwigFunction( 'questions_count', [ $this, 'questions_count' ] ),
			new \Twig\TwigFunction( 'wp_editor', [ $this, 'wp_editor' ] ),

		];
	}

	public function dump( $array ) {
		return var_dump( $array );
	}

	public function admin_url( $url ) {
		return admin_url( $url );
	}

	public function is_array( $array ) {
		return is_array( $array );
	}

	public function count( $array ) {
		return ( $array and is_array( $array ) ) ? count( $array ) : 0;
	}

	public function views_path( $file ) {
		return $this->twig_load( $file );
	}

	function get_avatar_url( $id_or_email, $args = null ) {
		$args = get_avatar_data( $id_or_email, $args );

		return $args['url'];
	}

	public function plugin_path( $file ) {
		return AH_Survey_ROOT_PATH . "$file";
	}

	public function base_url( $base ) {
		return AH_Survey_URL . $base;
	}

	public function http_get( $value ) {
		return ( isset( $_GET[ $value ] ) and ! empty( $_GET[ $value ] ) ) ? $_GET[ $value ] : null;
	}

	public function __( $context ) {
		return esc_html__( $context, 'ah-survey' );
	}

	public function full_date( $date ) {
		$_date = Carbon::parse( $date, TIME_ZONE );
		$date  = $_date->year . '/' . ( ( $_date->month < 10 ) ? '0' . $_date->month : $_date->month ) . '/' . ( ( $_date->day < 10 ) ? '0' . $_date->day : $_date->day ) . ' ' . $_date->hour . ':' . ( ( $_date->minute < 10 ) ? '0' . $_date->minute : $_date->minute ) . ':' . ( ( $_date->second < 10 ) ? '0' . $_date->second : $_date->second );

		return date( 'Y-m-d [ h:i A ]', strtotime( $date ) );
	}

	public function date_now( $format ) {
		$date = Carbon::now( TIME_ZONE );

		return $date->format( $format );
	}

	public function twig_load( $path ) {
		return AH_Survey_VIEWS_PATH . $path;
	}

	public function do_shortcode( $shortcode ) {
		return do_shortcode( $shortcode );
	}

	public function selected( $name, $value ) {
		return Publics::selected( $name, $value );
	}

	public function ng_selected( $name, $value ) {
		return Publics::ng_selected( $name, $value );
	}

	public function checked( $name, $value ) {
		return Publics::checked( $name, $value );
	}

	public function questions_count( $questions ) {
		$data = @unserialize( $questions );
		if ( $data !== false and is_array( $data ) ) {
			echo (string) count( $data );
		} else {
			echo "0";
		}
	}

	public function wp_editor( $editor_id = '', $content = '', $settings = [] ) {
		return wp_editor( $content, $editor_id, $settings );
	}

}
