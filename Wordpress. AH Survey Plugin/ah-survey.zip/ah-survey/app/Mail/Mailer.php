<?php

namespace App\Mail;

use App\Controllers\Controller;

class Mailer {

	public static function send( $template, $data ) {
		$Options = self::get_options( 'ah_survey_email_settings' );
		$to      = $data['to'];
		$subject = $data['subject'];
		$body    = Controller::views()->render( $template, $data['body'] );
		$headers = [
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $Options['from_name'] . ' <' . $Options['from_email'] . '>'
		];

		return wp_mail( $to, $subject, $body, $headers );
	}

	public static function wp_mailer_config( $phpmailer ) {
		$Options = self::get_options( 'ah_survey_email_settings' );
		$phpmailer->IsSMTP();
		$phpmailer->SMTPDebug  = 0;
		$phpmailer->Host       = $Options['host_name'];
		$phpmailer->SMTPAuth   = true;
		$phpmailer->Port       = $Options['host_port'];
		$phpmailer->SMTPSecure = $Options['host_secure'];
		$phpmailer->Username   = $Options['login_email'];
		$phpmailer->Password   = $Options['login_password'];
		$phpmailer->FromName   = $Options['from_name'];
		$phpmailer->From       = $Options['from_email'];
	}

	static public function get_options( $option_name ) {
		$panel_option = get_option( $option_name );

		return isset( $panel_option ) ? $panel_option : [];
	}

}
