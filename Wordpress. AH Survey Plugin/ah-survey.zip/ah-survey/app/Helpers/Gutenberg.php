<?php


namespace App\Helpers;

use App\Helpers\Publics;
use App\Helpers\Validation;
use App\Models\Surveys;
use App\Models\Users;
use Carbon\Carbon;
use App\Controllers\Controller;

class Gutenberg extends Controller {

	static public function survey_block() {
		wp_enqueue_script( 'ah-survey-gutenberg-block-editor', AH_Survey_URL . '/assets/blocks/survey/block.js', [
			'wp-i18n',
			'wp-element',
			'wp-blocks',
			'wp-components',
			'wp-editor'
		] );
		wp_enqueue_style( 'ah-survey-gutenberg-block-editor', AH_Survey_URL . '/assets/blocks/survey/block.css', [] );
	}
}