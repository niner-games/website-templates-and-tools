<?php


namespace App\Helpers;

use App\Controllers\Controller;
use App\Controllers\SettingsController;

class Widgets extends Controller {

	public static function footer_widget() {
		echo parent::views()->render( 'front/footer-widget.twig', [
			'ajax_url'                => admin_url( 'admin-ajax.php' ),
			'ah_surveys_submit_nonce' => wp_create_nonce( "ah_surveys_submit_nonce" ),
			'ah_surveys_login_nonce'  => wp_create_nonce( "ah_surveys_login_nonce" ),
			'is_user_logged_in'       => is_user_logged_in(),
			'current_page_id'         => get_queried_object_id(),
			'show_surveys_nonce'      => wp_create_nonce( "show_surveys_nonce" ),
			'widget_settings'         => SettingsController::get_options( 'widget_settings', true ),
		] );
	}
}