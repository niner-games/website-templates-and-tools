<?php


namespace App\Helpers;

use App\Helpers\Publics;
use App\Helpers\Validation;
use App\Models\Surveys;
use App\Models\Responses;
use App\Models\Users;
use Carbon\Carbon;
use App\Controllers\Controller;

class Shortcodes extends Controller {

	public static function survey_widget( $atts = [] ) {
		$list                     = [];
		$Survey                   = Surveys::where( 'id', $atts['id'] )->first();
		$allow_multiple_responses = $Survey['allow_multiple_responses'];
		$allow_add_response       = true;

		if ( $Survey ) {
			$start_date  = Carbon::parse( $Survey['start_date'] );
			$expire_date = Carbon::parse( $Survey['expire_date'] );
			if ( ! $allow_multiple_responses ) {
				if ( is_user_logged_in() ) {
					$user     = wp_get_current_user();
					$Response = Responses::where( 'participant_id', $user->ID )->where( 'survey_id', $Survey['id'] )->first();
					if ( $Response ) {
						$allow_add_response = false;
					}
				} else {
					$Response = Responses::where( 'participant_ip', Publics::get_client_ip() )->where( 'survey_id', $Survey['id'] )->first();
					if ( $Response ) {
						$allow_add_response = false;
					}
				}
			}
			$list['id']                       = $Survey['id'];
			$list['title']                    = stripcslashes( $Survey['title'] );
			$list['description']              = stripcslashes( $Survey['description'] );
			$list['welcome_message']          = stripcslashes( $Survey['welcome_message'] );
			$list['end_message']              = stripcslashes( $Survey['end_message'] );
			$list['is_active']                = (bool) $Survey['is_active'];
			$list['start_date']               = Publics::fullDate( $Survey['start_date'], false );
			$list['expire_date']              = ( isset( $Survey['expire_date'] ) and ! empty( $Survey['expire_date'] ) ) ? Publics::fullDate( $Survey['expire_date'], false ) : '';
			$list['start_date_active']        = ( Carbon::now()->lte( $start_date ) ) ? true : false;
			$list['expire_date_active']       = ( Carbon::now()->lte( $expire_date ) ) ? true : false;
			$list['allow_prev']               = (bool) $Survey['allow_prev'];
			$list['allow_multiple_responses'] = (bool) $Survey['allow_multiple_responses'];
			$list['allow_add_response']       = (bool) $allow_add_response;
			$list['allow_progress_bar']       = (bool) $Survey['allow_progress_bar'];
			$list['response_type']            = $Survey['response_type'];
			$list['survey_view']              = $Survey['survey_view'];
			$metas                            = $Survey->meta()->get()->toArray();
			if ( $metas ) {
				foreach ( $metas as $m_key => $meta ) {
					$metas_list[ $meta['meta_key'] ] = $meta['meta_value'];
				}
			}
			$list['meta']       = $metas_list;
			$list['questions']  = ( $Survey['questions'] and ! empty( $Survey['questions'] ) ) ? unserialize( $Survey['questions'] ) : [];
			$list['created_at'] = Publics::fullDate( $Survey['created_at'] );
			$list['updated_at'] = Publics::fullDate( $Survey['updated_at'] );
		}

		return parent::views()->render( 'front/show-survey.twig', [
			'ajax_url'                => admin_url( 'admin-ajax.php' ),
			'icons_url'               => AH_Survey_URL . '/assets/images/response-icons',
			'ah_surveys_submit_nonce' => wp_create_nonce( "ah_surveys_submit_nonce" ),
			'ah_surveys_login_nonce'  => wp_create_nonce( "ah_surveys_login_nonce" ),
			'Survey'                  => $list,
			'questions'               => $list['questions'],
			'Survey_Json'             => json_encode( $list ),
			'is_user_logged_in'       => is_user_logged_in(),
			'show_surveys_nonce'      => wp_create_nonce( "show_surveys_nonce" ),
		] );
	}
}