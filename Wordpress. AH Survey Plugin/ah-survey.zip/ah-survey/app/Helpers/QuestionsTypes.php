<?php


namespace App\Helpers;


class QuestionsTypes {

	public static function short_text( $options, $required = false ) {
		$placeholder = ( isset( $options ) and isset( $options['placeholder'] ) ) ? $options['placeholder'] : '';
		$input_mask  = ( isset( $options ) and isset( $options['input_mask'] ) ) ? $options['input_mask'] : 'text';
		$is_required = ( $required ) ? ' required="required" ' : '';
		switch ( $input_mask ) {
			case 'text':
				return `<input type="text" class="ah-form-control" placeholder="${$placeholder}" ${$is_required}>`;
				break;
			case 'number':
				return `<input type="number" class="ah-form-control" placeholder="${$placeholder}" ${$is_required}>`;
				break;
			case 'date_time':
				return `<input type="datetime-local" class="ah-form-control" placeholder="${$placeholder}" ${$is_required}>`;
				break;
			case 'date':
				return `<input type="date" class="ah-form-control" placeholder="${$placeholder}" ${$is_required}>`;
				break;
			case 'time':
				return `<input type="time" class="ah-form-control" placeholder="${$placeholder}" ${$is_required}>`;
				break;
		}
	}

}