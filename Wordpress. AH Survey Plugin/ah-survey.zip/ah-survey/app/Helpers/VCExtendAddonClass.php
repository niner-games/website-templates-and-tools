<?php


namespace App\Helpers;

use App\Models\Surveys;
use App\Controllers\Controller;

class VCExtendAddonClass extends Controller {


	static public function integrateWithVC() {

		if ( ! defined( 'WPB_VC_VERSION' ) ) {
			return;
		}

		global $wpdb;
		$table_name  = $wpdb->base_prefix . 'ah_surveys';
		$table_exits = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) );

		/*
		  Add your Visual Composer logic here.
		  Lets call vc_map function to "register" our custom shortcode within Visual Composer interface.

		  More info: http://kb.wpbakery.com/index.php?title=Vc_map
		 */

		if ( ! $wpdb->get_var( $table_exits ) == $table_name ) {
			return false;
		}

		$Surveys     = Surveys::all();
		$surveys_lis = [];
		foreach ( $Surveys as $Survey ) {
			$surveys_lis[ $Survey['title'] ] = $Survey['id'];
		}

		vc_map( [
			"name"        => esc_html__( "AH Survey ", 'ah-survey' ),
			"description" => esc_html__( "Select survey id ", 'ah-survey' ),
			"base"        => "ah-survey-vc-widget",
			"class"       => "ah-survey-vc-widget",
			"controls"    => "full",
			"icon"        => AH_Survey_URL . '/assets/images/logo_ah.png',
			// or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
			"category"    => esc_html__( 'AH Addons', 'ah-survey' ),
			// This will load js file in the VC backend editor
			// 'admin_enqueue_js' => array( plugins_url( 'assets/js/vc_extend.js', __FILE__ ) ),
			// 'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
			"params"      => [
				[
					"type"        => "dropdown",
					"admin_label" => true,
					"heading"     => esc_html__( "Select Survey", 'ah-survey' ),
					"param_name"  => "survey_id",
					"class"       => "ah-survey-select",
					"value"       => $surveys_lis
					//						"description" => esc_html__( "Choose Survey to insert it", 'ah-survey' )
				]
			]
		] );
	}

	static public function renderAhSurvey( $atts, $content = null ) {
		$output = "";
		extract( shortcode_atts( array(
			'survey_id' => ''
		), $atts ) );
		if ( ! empty( $survey_id ) ) {
			$output = "[ah-survey-widget id=\"$survey_id\"]";
		}

		return do_shortcode( $output );
	}
}