<?php

/*
 * @link              #
 * @since             1.8.4
 * @package           AH Survey
 *
 * @wordpress-plugin
 * Plugin Name:       AH Survey 
 * Plugin URI:        https://codecanyon.net/user/tatwerat-team/portfolio
 * Description:       Survey builder for create unlimited surveys with multi types of questions
 * Version:           1.8.4
 * Author:            Tatwerat Team
 * Author URI:        https://codecanyon.net/user/tatwerat-team
 * License:           General Public License 2.0
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       ah-survey
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	wp_die();
}

// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	wp_die();
}

if ( ! function_exists( 'add_action' ) ) {
	wp_die();
}

if ( defined( 'WP_DEBUG' ) and WP_DEBUG == true ) {
	error_reporting( E_ALL );
}

define( 'AH_Survey_VERSION', '1.8.2' );
define( 'AH_Survey_URL', plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) );
define( 'AH_Survey_FILE', __FILE__ );
define( 'AH_Survey_PATH', plugin_dir_path( __FILE__ ) );

define( 'AH_Survey_DS', DIRECTORY_SEPARATOR );
define( 'AH_Survey_ROOT_PATH', realpath( __DIR__ . '/' ) . AH_Survey_DS );
define( 'AH_Survey_VIEWS_PATH', realpath( __DIR__ . '/views/' ) . AH_Survey_DS );
define( 'AH_Survey_APP_PATH', realpath( __DIR__ . '/app/' ) . AH_Survey_DS );
define( 'TIME_ZONE', ( get_option( 'timezone_string' ) ) ? get_option( 'timezone_string' ) : 'UTC' );

require( AH_Survey_ROOT_PATH . '/vendor/autoload.php' );


/*
 * Load plugin textdomain.
 */
function ah_survey_load_textdomain() {
	load_plugin_textdomain( 'ah-survey', false, basename( dirname( __FILE__ ) ) . '/languages/' );
}

add_action( 'plugins_loaded', 'ah_survey_load_textdomain' );

function ah_survey_log_mailer_errors( $wp_error ) {
	$fn = AH_Survey_PATH . '/mail.log'; // say you've got a mail.log file in your server root
	if ( function_exists( 'fopen' ) and function_exists( 'fputs' ) and function_exists( 'fclose' ) ) {
		$fp = fopen( $fn, 'a' );
		fputs( $fp, "Mailer Error: " . $wp_error->get_error_message() . " __ " . \Carbon\Carbon::now()->format( 'd M Y (h:i A)' ) . "  " . "\n" );
		fclose( $fp );
	}
}

add_action( 'wp_mail_failed', 'ah_survey_log_mailer_errors', 10, 1 );


// use classes
use App\Controllers\SettingsController;

if ( ! class_exists( 'AH_Survey' ) ) {


	/*
	 * Main plugin class
	 *
	 * @package AH-Survey
	 * @author tatwerat
	 */

	class AH_Survey {

		public static $debug = false;
		protected $wpdb;
		protected $current_user;

		private static $instance = false;

		/*
		 * Class constructor
		 *
		 * @access public
		 * @return void
		 */

		public function __construct() {

			// WordPress DB
			global $wpdb;
			$this->wpdb = $wpdb;

			// email settings
			$email_settings = $this->options( 'email_settings', false );

			// Load translation
			load_plugin_textdomain( 'ah-survey', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

			// On plugin is activation
			register_activation_hook( __FILE__, [ $this, 'on_plugins_activation' ] );

			// Execute other code when all plugins are loaded
			add_action( 'plugins_loaded', [ $this, 'on_plugins_loaded' ], 1 );

			add_action( 'activated_plugin', [ $this, 'activation_redirect' ] );

			add_action( 'wp_ajax_new_survey', [ \App\Controllers\SurveysController::class, 'save' ] );
			add_action( 'wp_ajax_edit_survey', [ \App\Controllers\SurveysController::class, 'update' ] );
			add_action( 'wp_ajax_delete_surveys', [ \App\Controllers\SurveysController::class, 'delete' ] );
			add_action( 'wp_ajax_list_surveys', [ \App\Controllers\SurveysController::class, 'get' ] );
			add_action( 'wp_ajax_list_surveys', [ \App\Controllers\SurveysController::class, 'get' ] );
			add_action( 'wp_ajax_export_survey', [ \App\Controllers\SurveysController::class, 'export_survey' ] );
			add_action( 'wp_ajax_duplicate_survey', [ \App\Controllers\SurveysController::class, 'duplicate_survey' ] );
			add_action( 'wp_ajax_import_survey', [ \App\Controllers\SurveysController::class, 'import_survey' ] );
			add_action( 'wp_ajax_get_responses', [ \App\Controllers\SurveysController::class, 'get_responses' ] );
			add_action( 'wp_ajax_delete_responses', [ \App\Controllers\SurveysController::class, 'delete_responses' ] );
			add_action( 'wp_ajax_export_responses', [ \App\Controllers\SurveysController::class, 'export_responses' ] );
			add_action( 'wp_ajax_survey_submit', [ \App\Controllers\SurveysController::class, 'survey_submit' ] );
			add_action( 'wp_ajax_nopriv_survey_submit', [ \App\Controllers\SurveysController::class, 'survey_submit' ] );

			add_action( 'wp_ajax_survey_login', [ \App\Controllers\SurveysController::class, 'login' ] );
			add_action( 'wp_ajax_nopriv_survey_login', [ \App\Controllers\SurveysController::class, 'login' ] );

			add_action( 'wp_ajax_ah_survey_settings_save', [ \App\Controllers\SettingsController::class, 'save' ] );
			add_action( 'wp_ajax_ah_survey_settings_test_mail', [ \App\Controllers\SettingsController::class, 'send_test_mail' ] );
			add_action( 'wp_ajax_ah_survey_settings_email_errors_log', [ \App\Controllers\SettingsController::class, 'email_errors_log' ] );
			add_action( 'wp_ajax_ah_survey_settings_email_clear_log', [ \App\Controllers\SettingsController::class, 'email_clear_log' ] );

			// Load VC
			add_action( 'init', [ \App\Helpers\VCExtendAddonClass::class, 'integrateWithVC' ] );

			// Add Shortcodes
			add_shortcode( 'ah-survey-widget', [ \App\Helpers\Shortcodes::class, 'survey_widget' ] );
			add_shortcode( 'ah-survey-vc-widget', [ \App\Helpers\VCExtendAddonClass::class, 'renderAhSurvey' ] );

			// Widgets
			add_action( 'wp_footer', [ \App\Helpers\Widgets::class, 'footer_widget' ] );

			// Mailer enable SMTP
			if ( isset( $email_settings['email_provider'] ) and $email_settings['email_provider'] == 'smtp' ) {
				add_action( 'phpmailer_init', [ \App\Mail\Mailer::class, 'wp_mailer_config' ] );
			}

		}

		public function on_plugins_activation() {
			$version = get_option( 'ah_survey_version' );
			if ( ! $version or empty( $version ) ) {
				update_option( 'ah_survey_version', AH_Survey_VERSION );
			}
			$charset_collate   = $this->wpdb->get_charset_collate();
			$create_ah_surveys = "
				                CREATE TABLE IF NOT EXISTS {$this->wpdb->prefix}ah_surveys (
								  id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
								  title text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
								  description text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NULL,
								  welcome_message text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NULL,
								  end_message text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NULL,
								  is_active tinyint(1) NOT NULL DEFAULT '0',
								  start_date timestamp NULL DEFAULT NULL,
								  expire_date timestamp NULL DEFAULT NULL,
								  allow_prev tinyint(1) NOT NULL DEFAULT '1',
								  allow_multiple_responses tinyint(1) NOT NULL DEFAULT '0',
								  allow_progress_bar tinyint(1) NOT NULL DEFAULT '1',
								  response_type varchar(50) NOT NULL,
								  survey_view varchar(50) NOT NULL,
								  questions longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
								  created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
								  updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
								  PRIMARY KEY (id)
								) $charset_collate;";

			$create_ah_surveys_responses = "
								CREATE TABLE IF NOT EXISTS {$this->wpdb->prefix}ah_surveys_responses (
								  res_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT ,
								  participant_id bigint(20) NULL DEFAULT NULL ,
								  participant_type varchar(25) NOT NULL ,
								  participant_ip varchar(25) NULL DEFAULT NULL ,
								  survey_id bigint(20) UNSIGNED NOT NULL ,
								  answers longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci ,
								  created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,
								  updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,
								  PRIMARY KEY (`res_id`)
								 ) $charset_collate;";

			$create_ah_surveys_meta = "
								CREATE TABLE IF NOT EXISTS {$this->wpdb->prefix}ah_surveys_meta (
								  meta_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT ,
								  meta_key varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  								  meta_value longtext COLLATE utf8mb4_unicode_520_ci,
								  survey_id bigint(20) UNSIGNED NOT NULL ,
								  created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,
								  updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,
								  PRIMARY KEY (`meta_id`)
								 ) $charset_collate;";

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $create_ah_surveys );
			dbDelta( $create_ah_surveys_responses );
			dbDelta( $create_ah_surveys_meta );
		}

		public function on_plugins_loaded() {

			// Boot DB
			$this->db()->bootEloquent();

			// Add admin assets ( js , css )
			add_action( 'admin_enqueue_scripts', [ $this, 'admin_head' ] );

			// Add front assets ( js , css )
			add_action( 'wp_enqueue_scripts', [ $this, 'front_head' ] );

			// Add block editor assets
			add_action( 'enqueue_block_editor_assets', [ \App\Helpers\Gutenberg::class, 'survey_block' ] );


			if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
				// Add settings page menu link
				add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
			}

			// Debug class
			if ( self::$debug ) {
				add_action( 'init', [ $this, 'debug' ] );
			}
		}

		/**
		 * Add admin menu items
		 *
		 * @access public
		 * @return void
		 */
		public function add_admin_menu() {
			add_menu_page( esc_html__( 'AH-Survey', 'ah-survey' ), esc_html__( 'AH-Survey', 'ah-survey' ), 'manage_options', 'ah-survey', [
				\App\Controllers\SurveysController::class,
				'index'
			], 'dashicons-smiley' );

			add_submenu_page( 'ah-survey', esc_html__( 'Surveys List', 'ah-survey' ), esc_html__( 'Surveys List', 'ah-survey' ), 'manage_options', 'ah-survey' );

			add_submenu_page( 'ah-survey', esc_html__( 'Create New Survey', 'ah-survey' ), esc_html__( 'Create New', 'ah-survey' ), 'manage_options', 'ah-survey-create-new', [
				\App\Controllers\SurveysController::class,
				'create'
			] );

			add_submenu_page( 'ah-survey', esc_html__( 'Responses', 'ah-survey' ), esc_html__( 'Responses', 'ah-survey' ), 'manage_options', 'ah-survey-responses', [
				\App\Controllers\SurveysController::class,
				'responses'
			] );

			add_submenu_page( 'ah-survey', esc_html__( 'General Setting', 'ah-survey' ), esc_html__( 'General Setting', 'ah-survey' ), 'manage_options', 'ah-survey-settings', [
				\App\Controllers\SettingsController::class,
				'index'
			] );
		}

		public function head_assets() {
			$get_options = $this->options( 'general_settings', false );
			$font        = ( isset( $get_options ) and isset( $get_options['font_family'] ) and ! empty( $get_options['font_family'] ) ) ? $get_options['font_family'] : 'Cairo';
			wp_enqueue_style( 'toastr-style', AH_Survey_URL . '/assets/plugins/toastr/angular-toastr.min.css', [], AH_Survey_VERSION );
			wp_enqueue_style( 'confirm-style', AH_Survey_URL . '/assets/plugins/confirm/angular-confirm.min.css', [], AH_Survey_VERSION );
			wp_enqueue_style( 'chosen-style', AH_Survey_URL . '/assets/plugins/chosen/chosen.min.css', [], AH_Survey_VERSION );
			wp_enqueue_style( 'font-style', 'https://fonts.googleapis.com/css?family=' . $font . ':400,500,600,700,800,900', [], AH_Survey_VERSION );
			wp_enqueue_style( 'datetimepicker-style', AH_Survey_URL . '/assets/plugins/datetimepicker/jquery.datetimepicker.min.css', [], AH_Survey_VERSION );
			wp_enqueue_style( 'tags-input-style', AH_Survey_URL . '/assets/plugins/tags-input/tagsinput.css', [], AH_Survey_VERSION );
			wp_enqueue_style( 'survey-admin-style', AH_Survey_URL . '/assets/css/ah-survey-admin.css', [], AH_Survey_VERSION );
			wp_add_inline_style( 'survey-admin-style', ".ah-survey {font-family:'$font';}" );
			wp_enqueue_script( 'datetimepicker-scripts', AH_Survey_URL . '/assets/plugins/datetimepicker/jquery.datetimepicker.full.min.js', [ 'jquery' ], AH_Survey_VERSION );
			wp_enqueue_script( 'chosen-scripts', AH_Survey_URL . '/assets/plugins/chosen/chosen.min.js', [ 'jquery' ] );
			wp_enqueue_script( 'tags-input-scripts', AH_Survey_URL . '/assets/plugins/tags-input/tagsinput.min.js', [ 'jquery' ] );
			wp_enqueue_script( 'survey-custom-scripts', AH_Survey_URL . '/assets/js/custom-scripts.js', [ 'jquery', 'wp-color-picker' ], AH_Survey_VERSION );
		}

		// Add css and javaScript to admin head
		public function admin_head() {
			wp_enqueue_script( 'survey-setting-tabs-scripts', AH_Survey_URL . '/assets/js/setting-tabs-scripts.js', [ 'jquery' ], AH_Survey_VERSION );
			wp_localize_script( 'survey-setting-tabs-scripts', 'ah_survey_scripts_object', [
				'list_surveys_nonce'             => wp_create_nonce( "list_surveys_nonce" ),
				'wp_ajax_url'                    => admin_url( 'admin-ajax.php' ),
				'plugin_url'                     => admin_url( 'admin.php?page=' ),
				'surveys_page_url'               => admin_url( 'admin.php?page=ah-survey' ),
				'settings_page_url'              => admin_url( 'admin.php?page=ah-survey-settings' ),
				'success'                        => esc_html__( 'Success', 'ah-survey' ),
				'warning'                        => esc_html__( 'Warning', 'ah-survey' ),
				'delete'                         => esc_html__( 'Delete', 'ah-survey' ),
				'remove'                         => esc_html__( 'Remove', 'ah-survey' ),
				'clear'                          => esc_html__( 'Clear', 'ah-survey' ),
				'error'                          => esc_html__( 'Error', 'ah-survey' ),
				'close'                          => esc_html__( 'Close', 'ah-survey' ),
				'text'                           => esc_html__( 'Text', 'ah-survey' ),
				'number'                         => esc_html__( 'Number', 'ah-survey' ),
				'date_time'                      => esc_html__( 'Date Time', 'ah-survey' ),
				'date'                           => esc_html__( 'Date', 'ah-survey' ),
				'time'                           => esc_html__( 'Time', 'ah-survey' ),
				'delete_survey'                  => esc_html__( 'Do you want delete this survey ?', 'ah-survey' ),
				'delete_question'                => esc_html__( 'Do you want delete this question ?', 'ah-survey' ),
				'delete_question_condition'      => esc_html__( 'Do you want remove this condition ?', 'ah-survey' ),
				'delete_response'                => esc_html__( 'Do you want delete this response ?', 'ah-survey' ),
				'delete_responses'               => esc_html__( 'Do you want to delete these responses ?', 'ah-survey' ),
				'add_email'                      => esc_html__( 'Add Email', 'ah-survey' ),
				'equal'                          => esc_html__( 'Equal', 'ah-survey' ),
				'not_equal'                      => esc_html__( 'Not equal', 'ah-survey' ),
				'less_than'                      => esc_html__( 'Less than', 'ah-survey' ),
				'less_than_or_equal'             => esc_html__( 'Less than or equal', 'ah-survey' ),
				'greater_than'                   => esc_html__( 'Greater than', 'ah-survey' ),
				'greater_than_or_equal'          => esc_html__( 'Greater than or equal', 'ah-survey' ),
				'in'                             => esc_html__( 'IN', 'ah-survey' ),
				'not_in'                         => esc_html__( 'Not in', 'ah-survey' ),
				'is_null'                        => esc_html__( 'Is null', 'ah-survey' ),
				'is_not_null'                    => esc_html__( 'Is not null', 'ah-survey' ),
				'error_json_file_type'           => esc_html__( 'Invalid question file, must be json type', 'ahs-survey' ),
				'error_json_questions_structure' => esc_html__( 'Invalid questions structure', 'ahs-survey' ),
				'error_json_survey_structure'    => esc_html__( 'Invalid survey structure', 'ahs-survey' ),
				'error_json_questions_empty'     => esc_html__( 'Empty questions list', 'ahs-survey' ),
				'error_json_file_size'           => esc_html__( 'JSON file greater than 5 MB', 'ahs-survey' ),
				'export_survey_title'            => esc_html__( 'Export', 'ahs-survey' ),
				'export_survey_content'          => esc_html__( 'Export survey data or only questions', 'ahs-survey' ),
				'export_survey_button_text'      => esc_html__( 'Full Data', 'ahs-survey' ),
				'export_questions_text'          => esc_html__( 'Questions', 'ahs-survey' ),
				'duplicate_survey_title'         => esc_html__( 'Duplicate Survey', 'ahs-survey' ),
				'duplicate_survey_content'       => esc_html__( 'Will duplicate survey without responses and will take new ID', 'ahs-survey' ),
				'duplicate_survey_button_text'   => esc_html__( 'Duplicate', 'ahs-survey' ),
			] );
			if ( $this->is_ah_survey_page() ) {
				$this->head_assets();
				wp_enqueue_script( 'jquery-ui-datepicker' );
				wp_enqueue_style( 'wp-color-picker' );
				wp_enqueue_script( 'ajax-form-script', AH_Survey_URL . '/assets/plugins/ajax-form/form.min.js', [ 'jquery' ], AH_Survey_VERSION );
				wp_enqueue_script( 'bootstrap-modal-script', AH_Survey_URL . '/assets/plugins/bootstrap/modal.js', [ 'jquery' ], AH_Survey_VERSION );
				wp_enqueue_script( 'fontawesome-script', AH_Survey_URL . '/assets/plugins/fontawesome/fontawesome.js', [], AH_Survey_VERSION );
				wp_enqueue_script( 'angular-script', AH_Survey_URL . '/assets/plugins/angular/angular.min.js', [], AH_Survey_VERSION );
				wp_enqueue_script( 'angular-toastr-script', AH_Survey_URL . '/assets/plugins/toastr/angular-toastr.tpls.min.js', [], AH_Survey_VERSION );
				wp_enqueue_script( 'angular-confirm-script', AH_Survey_URL . '/assets/plugins/confirm/angular-confirm.min.js', [], AH_Survey_VERSION );
				wp_enqueue_script( 'sortable-script', AH_Survey_URL . '/assets/plugins/sortable/sortable.js', [ 'jquery', 'jquery-ui-sortable' ], AH_Survey_VERSION );
				wp_enqueue_script( 'angular-app-script', AH_Survey_URL . '/assets/js/angular-app.js', [], AH_Survey_VERSION );
				wp_enqueue_script( 'angular-survey-admin-script', AH_Survey_URL . '/assets/js/controllers/survey-admin.js' );
				wp_enqueue_script( 'angular-settings-script', AH_Survey_URL . '/assets/js/controllers/settings.js' );
			}
		}

		// Add css and javaScript to front head
		public function front_head() {
			$get_options = $this->options( 'general_settings', false );
			$font        = ( isset( $get_options ) and isset( $get_options['font_family'] ) and ! empty( $get_options['font_family'] ) ) ? $get_options['font_family'] : 'Cairo';
			wp_enqueue_style( 'ah-survey-font-style', 'https://fonts.googleapis.com/css?family=' . $font . ':400,500,600,700,800,900', [], AH_Survey_VERSION );
			wp_enqueue_style( 'toastr-style', AH_Survey_URL . '/assets/plugins/toastr/angular-toastr.min.css', [], AH_Survey_VERSION );
			wp_enqueue_style( 'ah-survey-front-style', AH_Survey_URL . '/assets/css/ah-survey-front.css', [], AH_Survey_VERSION );
			wp_enqueue_style( 'ah-survey-style-scrollbar', AH_Survey_URL . '/assets/plugins/scrollbar/jquery.scrollbar.css', [], AH_Survey_VERSION );
			wp_add_inline_style( 'ah-survey-front-style', ".ah-survey-front, .ah-survey-footer-widget {font-family:'$font';}" );
			wp_enqueue_style( 'ah-survey-datetimepicker-style', AH_Survey_URL . '/assets/plugins/datetimepicker/jquery.datetimepicker.min.css', [], AH_Survey_VERSION );
			wp_enqueue_style( 'dashicons' );
			wp_enqueue_script( 'ah-survey-datetimepicker-scripts', AH_Survey_URL . '/assets/plugins/datetimepicker/jquery.datetimepicker.full.min.js', [ 'jquery' ], AH_Survey_VERSION );
			wp_enqueue_script( 'ah-survey-jquery-scrollbar', AH_Survey_URL . '/assets/plugins/scrollbar/jquery.scrollbar.min.js', [ 'jquery' ], AH_Survey_VERSION );
			wp_enqueue_script( 'ah-survey-ajax-form', AH_Survey_URL . '/assets/plugins/ajax-form/form.min.js', [ 'jquery' ], AH_Survey_VERSION );
			wp_enqueue_script( 'ah-survey-custom-scripts', AH_Survey_URL . '/assets/js/custom-scripts.js', [ 'jquery' ], AH_Survey_VERSION );
			wp_localize_script( 'ah-survey-custom-scripts', 'ah_survey_scripts_object', [
				'wp_ajax_url'       => admin_url( 'admin-ajax.php' ),
				'is_user_logged_in' => is_user_logged_in(),
				'close'             => esc_html__( 'Close', 'ah-survey' ),
				'delete'            => esc_html__( 'Delete', 'ah-survey' ),
				'clear'             => esc_html__( 'Clear', 'ah-survey' ),
				'angry'             => esc_html__( 'Angry', 'ah-survey' ),
				'sad'               => esc_html__( 'Sad', 'ah-survey' ),
				'normal'            => esc_html__( 'Normal', 'ah-survey' ),
				'happy'             => esc_html__( 'Happy', 'ah-survey' ),
				'very_happy'        => esc_html__( 'Very-happy', 'ah-survey' ),
			] );
			wp_enqueue_script( 'ah-survey-chosen-scripts', AH_Survey_URL . '/assets/plugins/chosen/chosen.min.js', [ 'jquery' ], AH_Survey_VERSION );
			wp_enqueue_script( 'ah-survey-angular', AH_Survey_URL . '/assets/plugins/angular/angular.min.js', [], AH_Survey_VERSION );
			wp_enqueue_script( 'angular-toastr-script', AH_Survey_URL . '/assets/plugins/toastr/angular-toastr.tpls.min.js', [], AH_Survey_VERSION );
			wp_enqueue_script( 'ah-survey-angular-sanitize', AH_Survey_URL . '/assets/plugins/angular/angular-sanitize.js', [], AH_Survey_VERSION );
			wp_enqueue_script( 'ah-survey-angular-front-app', AH_Survey_URL . '/assets/js/front/angular-front-app.js', [], AH_Survey_VERSION, true );
		}

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function is_ah_survey_page() {
			global $pagenow;
			if ( isset( $pagenow ) and $pagenow == 'admin.php' and isset( $_GET['page'] ) and strpos( $_GET['page'], 'ah-survey' ) !== false ) {
				return true;
			} else {
				return false;
			}
		}

		public function db() {
			$capsule = new \Illuminate\Database\Capsule\Manager;
			$capsule->addConnection( [
				'driver'    => 'mysql',
				'host'      => $this->wpdb->dbhost,
				'username'  => $this->wpdb->dbuser,
				'password'  => $this->wpdb->dbpassword,
				'database'  => $this->wpdb->dbname,
				'charset'   => $this->wpdb->charset,
				'collation' => $this->wpdb->collate,
				'prefix'    => $this->wpdb->prefix,
			] );
			$capsule->setAsGlobal();
			$capsule->bootEloquent();

			return $capsule;
		}

		public function options( $option, $object = true ) {
			if ( isset( $option ) ) {
				return SettingsController::get_options( $option, $object );
			}
		}

		public function activation_redirect( $plugin ) {
			if ( $plugin == plugin_basename( __FILE__ ) ) {
				exit( wp_redirect( admin_url( 'admin.php?page=ah-survey-settings' ) ) );
			}
		}

	}

}

AH_Survey::get_instance();
