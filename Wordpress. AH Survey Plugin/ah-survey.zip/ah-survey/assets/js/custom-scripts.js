/* 
 * Custom Scripts
 */

(function ($) {

    "use strict";

    $(document).ready(function () {

        angular.element(this).ready(function () {
            $('.ah-survey').css('visibility', 'visible');
        });

        $(".chosen-select").chosen({width: "100%"});

        if ($('.wp-color-picker').length) {
            $('.wp-color-picker').wpColorPicker({
                defaultColor: true,
            });
        }

        if ($('.scrollbar-dynamic').length) {
            $('.scrollbar-dynamic').scrollbar({
                autoScrollSize: true,
                autoUpdate: true
            });
        }

        $(document).on('click', '.show-password', function (e) {
            e.preventDefault();
            if ($(this).hasClass('shown')) {
                $(this).removeClass('shown');
                $('i.dashicons', this).removeClass('dashicons-hidden').addClass('dashicons-visibility');
                $(this).parents('.ah-input-group').find('input').attr('type', 'password');
            } else {
                $(this).addClass('shown');
                $('i.dashicons', this).removeClass('dashicons-visibility').addClass('dashicons-hidden');
                $(this).parents('.ah-input-group').find('input').attr('type', 'text');
            }
        });

        $(document).on('click', '[data-toggle="ah-dropdown"]', function (event) {
            event.preventDefault();
            let dropdown_menu = $(this).parent('.ah-dropdown').find('.ah-dropdown-content');
            if (dropdown_menu.hasClass('ah-show')) {
                dropdown_menu.removeClass('ah-show');
            } else {
                dropdown_menu.addClass('ah-show');
            }
        })
        window.onclick = function (event) {
            if (!event.target.matches('[data-toggle="ah-dropdown"]')) {
                $('[data-toggle="ah-dropdown"]').each(function () {
                    let dropdown_menu = $(this).parent('.ah-dropdown').find('.ah-dropdown-content');
                    if (dropdown_menu.hasClass('ah-show')) {
                        dropdown_menu.removeClass('ah-show');
                    }
                });
            }
        }

    });


})(jQuery);

function ah_survey_inputNumber($event) {
    let theEvent = $event || window.event;
    let key;
    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }
    // var regex = /[0-9]|\./;
    let regex = /[0-9]/;
    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }
}


