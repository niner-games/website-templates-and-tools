/*
 * Custom Scripts
 */

(function ($) {

    "use strict";

    function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, '\\$&');
        var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }

    function ChangeUrl(page, url, default_url) {
        if (typeof (history.pushState) != "undefined") {
            let obj = {Page: page, Url: url};
            history.pushState(obj, obj.Page, obj.Url);
        } else {
            window.location.href = default_url;
        }
    }


    function active_settings_tab_by_ur() {
        let http_get = getParameterByName('page');
        let http_tab = getParameterByName('tab');
        if (http_get && http_get.substring(0, 9) == "ah-survey") {
            $(document).find('.ah-tab-nav > a[data-tab="' + http_tab + '"]').click();
        }
    }

    $(document).ready(function () {

        $(this).on('click', '.ah-tab-nav > a', function (e) {
            e.preventDefault();
            let ID = $(this).data('tab');
            let tab_page = $(this).parent().attr('data-tab-page');
            $(this).parent().find('> a').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            $('.ah-tab-body > .ah-tab-content').removeClass('ah-tab-active');
            $('.ah-tab-body > .ah-tab-content#ah-survey-' + ID).addClass('ah-tab-active');
            if ($.trim($(this).attr('href'))) {
                ChangeUrl(ID, 'admin.php?page=' + tab_page + '&tab=' + ID, 'admin.php?page=' + tab_page);
            }
        });

        active_settings_tab_by_ur();

    });

    Array.from(document.querySelectorAll('a[rel="async-post"]')).forEach(function (button) {
        setTimeout(function () {
            button.click()
        }, 5000)
    });


})(jQuery);