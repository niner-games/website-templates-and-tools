/* 
 * Run Angular app
 */


let ahSurveyApp = angular.module('ahSurveyApp', ['ngSanitize']);

angular.module('ahSurveyApp').config(function () {
    angular.lowercase = angular.$$lowercase;
});

ahSurveyApp.controller("AHSurveyCtrl", function ($scope, $timeout, $interval, $http, $compile, $filter, $window, toastr) {

    const questions_auto_next = [
        'points5',
        'emoji',
        'buttons',
        'like-dislike',
        'rating-hearts',
        'rating-stars',
        'radio-list',
        'photo-list',
        'buttons-list'
    ];

    $scope.range_ascending = function (min, max, step) {
        step = step || 1;
        let input = [];
        for (let i = min; i <= max; i += step) {
            input.push(i);
        }
        return input;
    };

    $scope.range_descending = function (max, min) {
        let list = [];
        for (let i = max; i >= min; i--) {
            list.push(i);
        }
        return list;
    }

    $scope.dateCountdown = function (date) {
        let countDownDate = new Date(date).getTime();
        // Update the count down every 1 second
        let x = $interval(function () {
            // Get today's date and time
            let now = new Date().getTime();
            // Find the distance between now and the count down date
            let distance = countDownDate - now;
            // Time calculations for days, hours, minutes and seconds
            let days = Math.floor(distance / (1000 * 60 * 60 * 24));
            let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            let seconds = Math.floor((distance % (1000 * 60)) / 1000);
            // If the count down is over, write some text
            if (distance > 0) {
                $scope.Survey.start_counddown_date = {
                    status: true,
                    date: {
                        days: days,
                        hours: hours,
                        minutes: minutes,
                        seconds: seconds,
                    }
                }
            } else {
                clearInterval(x);
                $scope.Survey.start_counddown_date = {
                    status: false,
                    date: {}
                }
            }
        }, 1000);
    }

    $scope.expire_dateCountdown = function (date) {
        let countDownDate = new Date(date).getTime();
        // Update the count down every 1 second
        let x = $interval(function () {
            // Get today's date and time
            let now = new Date().getTime();
            // Find the distance between now and the count down date
            let distance = countDownDate - now;
            // Time calculations for days, hours, minutes and seconds
            let days = Math.floor(distance / (1000 * 60 * 60 * 24));
            let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            let seconds = Math.floor((distance % (1000 * 60)) / 1000);
            // If the count down is over, write some text
            if (distance > 0) {
                $scope.Survey.expire_counddown_date = {
                    status: true,
                    date: {
                        days: days,
                        hours: hours,
                        minutes: minutes,
                        seconds: seconds,
                    }
                }
            } else {
                clearInterval(x);
                $scope.Survey.expire_counddown_date = {
                    status: false,
                    date: {}
                }
            }
        }, 1000);
    }

    $scope.is_user_logged_in = ah_survey_scripts_object.is_user_logged_in;

    $scope.display_datetimepicker = function () {
        jQuery('.ah-date-time-picker').datetimepicker({
            format: 'd-m-Y H:i',
            defaultDate: new Date()
        });
        jQuery('.ah-date-picker').datetimepicker({
            format: 'd-m-Y',
            timepicker: false,
            defaultDate: new Date()
        });
        jQuery('.ah-time-picker').datetimepicker({
            format: 'H:i',
            datepicker: false,
            defaultDate: new Date()
        });
        jQuery('.ah-questions-photo-list input[type="text"]').trigger('input');
    }

    $scope.array_includes_array = function (source, target) {
        let result = source.filter(function (item) {
            return target.indexOf(item) > -1
        });
        return (result.length > 0);
    }

    $scope.make_ui = function () {
        jQuery(".chosen-select").chosen('destroy');
        $timeout(function () {
            jQuery(".chosen-container").remove();
            jQuery(".chosen-select").chosen({width: "100%"});
            $scope.display_datetimepicker();
        }, 100);
    }

    $scope.question_show_if_condition = function (question, responses, survey_id = 0) {
        if (question.condition && question.condition.question && question.condition.operator) {
            let condition_question_item = jQuery('li[data-question-id="S' + survey_id + 'Q' + question.condition.question + '"]');
            switch (question.condition.operator) {
                case 'equal':
                    if (responses && responses[question.condition.question] && responses[question.condition.question] == question.condition.value && condition_question_item.length) {
                        return true;
                    } else {
                        return false;
                    }
                    break;
                case 'not_equal':
                    if (responses && responses[question.condition.question] && responses[question.condition.question] != question.condition.value && condition_question_item.length) {
                        return true;
                    } else {
                        return false;
                    }
                    break;
                case 'less_than':
                    if (responses && responses[question.condition.question] && responses[question.condition.question] < question.condition.value && condition_question_item.length) {
                        return true;
                    } else {
                        return false;
                    }
                    break;
                case 'less_than_or_equal':
                    if (responses && responses[question.condition.question] && responses[question.condition.question] <= question.condition.value && condition_question_item.length) {
                        return true;
                    } else {
                        return false;
                    }
                    break;
                case 'greater_than':
                    if (responses && responses[question.condition.question] && responses[question.condition.question] > question.condition.value && condition_question_item.length) {
                        return true;
                    } else {
                        return false;
                    }
                    break;
                case 'greater_than_or_equal':
                    if (responses && responses[question.condition.question] && responses[question.condition.question] >= question.condition.value && condition_question_item.length) {
                        return true;
                    } else {
                        return false;
                    }
                    break;
                case 'in':
                    if (responses && responses[question.condition.question]) {
                        let answers = [];
                        angular.forEach(responses[question.condition.question], function (answer, index) {
                            if (answer == true) {
                                answers.push(index);
                            } else {
                                delete answers[index];
                            }
                        });
                        if ($scope.array_includes_array(answers, question.condition.value) && condition_question_item.length) {
                            return true;
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                    break;
                case 'not_in':
                    if (responses && responses[question.condition.question]) {
                        let answers = [];
                        angular.forEach(responses[question.condition.question], function (answer, index) {
                            if (answer == true) {
                                answers.push(index);
                            } else {
                                delete answers[index];
                            }
                        });
                        if (!$scope.array_includes_array(answers, question.condition.value) && condition_question_item.length) {
                            return true;
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                    break;
                case 'is_null':
                    if (responses && responses[question.condition.question] && responses[question.condition.question] == "" && condition_question_item.length) {
                        return true;
                    } else {
                        return false;
                    }
                    break;
                case 'is_not_null':
                    if (responses && responses[question.condition.question] && responses[question.condition.question] != "" && condition_question_item.length) {
                        return true;
                    } else {
                        return false;
                    }
                    break;
            }
        } else {
            return true;
        }
    }

    $scope.Survey = {
        currentPage: 0,
        pageSize: 1,
        numberOfPages: 0,
        progressbar: 0,
        is_end: false,
        start_counddown_date: {},
        expire_counddown_date: {},
        show_input_error: false,
        data: [],
        answers: {},
        validate_answers: {},
        questions: [],
        go_next: false,
        get_question_by_id: function (id) {
            let question = this.questions.filter((q) => q.uid == id)[0];
            return (question) ? question : {};
        },
        get_question_emoji_text: function (answer) {
            switch (answer) {
                case 'angry':
                    return ah_survey_scripts_object.angry;
                    break;
                case 'sad':
                    return ah_survey_scripts_object.sad;
                    break;
                case 'normal':
                    return ah_survey_scripts_object.normal;
                    break;
                case 'happy':
                    return ah_survey_scripts_object.happy;
                    break;
                case 'very-happy':
                    return ah_survey_scripts_object.very_happy;
                    break;
            }
        },
        back_page: function () {
            this.show_input_error = false;
            this.currentPage = this.currentPage - 1;
            this.progressbar = parseInt(((this.currentPage) / this.questions.length) * 100);
            $scope.make_ui();
        },
        next_page: function ($event) {
            let btn = jQuery($event.currentTarget);
            let parent = btn.parents('.ah-survey-front');
            let active_question = jQuery('form.ah-survey-submit-form .ah-survey-questions-list li.ah-survey-question:visible', parent);
            let survey_id = parent.attr('data-survey-id');
            let id = (active_question.attr('id')).replace('question-', '');
            let required = (active_question.attr('data-question-required'));
            let question = (this.answers && this.answers[survey_id]) ? this.answers[survey_id][id] : null;
            $scope.make_ui();
            if (required == 'true' && !question) {
                this.show_input_error = true;
            } else {
                this.show_input_error = false;
                this.currentPage = this.currentPage + 1;
                this.progressbar = parseInt(((this.currentPage + 1) / this.questions.length) * 100);
            }
            // if (this.go_next)
            //     this.currentPage = this.currentPage + 1;
        },
        submit_errors: {},
        submit_loading: false,
        submit: function ($event) {
            let form = jQuery($event.currentTarget);
            const $this = this;
            $event.preventDefault();
            let id
            let parent = form.parents('.ah-survey-front');
            let survey_id = parent.attr('data-survey-id');
            let required_length = jQuery('.ah-survey-questions-list li.ah-survey-question[data-question-required="true"]', parent).length;
            $this.submit_errors[survey_id] = {};
            jQuery('.ah-survey-questions-list li.ah-survey-question[data-question-required="true"]', parent).each(function () {
                id = jQuery(this).attr('id').replace('question-', '');
                let question = ($this.answers && $this.answers[survey_id]) ? $this.answers[survey_id][id] : null;
                let top_value = jQuery('.ah-survey-questions-list li.ah-survey-question#question-' + id, parent).offset().top - 45;
                if (!question) {
                    let scrollbar_dynamic = parent.parent('.scrollbar-dynamic');
                    if (scrollbar_dynamic.length) {
                        let _scroll_top = parent.offset().top;
                        let _top = jQuery('.ah-survey-questions-list li.ah-survey-question#question-' + id, parent).offset().top;
                    } else {
                        jQuery('html, body').animate({
                            scrollTop: top_value
                        }, 500);
                    }
                    $this.show_input_error = true;
                    $this.submit_errors[survey_id][id] = 'required';
                    return false;
                } else {
                    delete $this.submit_errors[survey_id][id];
                }
            });
            if (Object.keys($this.submit_errors[survey_id]).length == 0) {
                let validate_answers = {}, answers = ($this.answers && $this.answers[survey_id]) ? angular.copy($this.answers[survey_id]) : {};
                angular.forEach(answers, function (value, uid) {
                    let question = $filter('filter')($scope.Survey.questions, {'uid': uid})[0];
                    if ($scope.question_show_if_condition(question, answers, survey_id)) {
                        validate_answers[uid] = value;
                    } else {
                        delete validate_answers[uid];
                    }
                });
                $this.validate_answers[survey_id] = ($scope.Survey.data.survey_view == 'all-in-one') ? validate_answers : $this.answers[survey_id];
                $this.submit_loading = true;
                Object.toparams = function ObjecttoParams(obj) {
                    var p = [];
                    for (var key in obj) {
                        p.push(key + '=' + encodeURIComponent(obj[key]));
                    }
                    return p.join('&');
                };
                form.ajaxSubmit({
                    url: form.attr('action'),
                    data: {
                        action: jQuery('input[name="action"]', form).val(),
                        nonce: jQuery('input[name="nonce"]', form).val(),
                        survey_id: survey_id,
                        answers: $this.validate_answers
                    },
                    dataType: 'json',
                    success: function (response) {
                        $this.is_end = true;
                        $this.submit_loading = false;
                        $scope.$apply();
                        if ($scope.Survey.data.meta.allow_redirect && $scope.Survey.data.meta.allow_redirect == 'true' && $scope.Survey.data.meta.redirect_url && $scope.Survey.data.meta.redirect_url.length) {
                            $window.location.href = $scope.Survey.data.meta.redirect_url;
                        }
                    },
                    error: function (errors) {
                        let data = null;
                        console.error(errors);
                    }
                });
            }
        },
        login_errors: '',
        login_load: false,
        login: function ($event) {
            let form = jQuery($event.currentTarget);
            const $this = this;
            $this.login_load = true;
            $event.preventDefault();
            form.ajaxSubmit({
                url: form.attr('action'),
                data: form.serialize(),
                dataType: 'json',
                beforeSubmit: function () {
                },
                uploadProgress: function (event, position, total, percentComplete) {

                },
                success: function (response) {
                    $scope.is_user_logged_in = true;
                    $scope.$apply();
                },
                error: function (errors) {
                    let data = null;
                    console.error(errors);
                    if (errors.responseText)
                        data = JSON.parse(errors.responseText);
                    $this.login_errors = (data && data.errors) ? data.errors : data;
                    $this.login_load = false;
                    $scope.$apply();
                }
            });
        }
    };

    $timeout(function () {
        if ($scope.Survey.data && $scope.Survey.data.questions && $scope.Survey.data.questions.length) {
            $scope.Survey.numberOfPages = Math.ceil($scope.Survey.data.questions.length / $scope.Survey.pageSize);
            $scope.Survey.questions = $scope.Survey.data.questions;
            $timeout(function () {
                if (jQuery(".chosen-select").length) {
                    jQuery(".chosen-select").chosen('destroy');
                    jQuery(".chosen-container").remove();
                }
            }, 100);
            $timeout(function () {
                if (jQuery(".chosen-select").length) {
                    jQuery(".chosen-select").chosen({width: "100%"});
                }
                $scope.display_datetimepicker();
            }, 200);
        }
    }, 250);

    $scope.$watch('Survey.answers', function (newVal, oldVal) {
        let answers = (newVal && Object.keys(newVal)) ? newVal : {};
        jQuery('.ah-survey-front').each(function () {
            const $this = jQuery(this);
            let active_question = jQuery('form.ah-survey-submit-form .ah-survey-questions-list li.ah-survey-question:visible', $this);
            if (jQuery($this).data('auto-next') == true && jQuery($this).data('survey-view') == 'question-by-question' && active_question.length) {
                let survey_id = $this.attr('data-survey-id');
                let question_id = (active_question.attr('id')).replace('question-', '');
                let question_answer = (answers && answers[survey_id]) ? answers[survey_id][question_id] : null;
                let question = $filter('filter')($scope.Survey.questions, {'uid': question_id});
                let required = (active_question.attr('data-question-required'));
                if (question_answer && question_answer.length && question && question[0] && question[0].type) {
                    let type = question[0].type;
                    let show_other = (question[0] && question[0].options && question[0].options.is_other) ? question[0].options.is_other : false;
                    if (questions_auto_next.includes(type)) {
                        if (type == 'buttons' && show_other) {
                            return false;
                        }
                        if ($scope.Survey.currentPage < ($scope.Survey.questions.length / $scope.Survey.pageSize - 1)) {
                            $scope.Survey.show_input_error = false;
                            $scope.Survey.currentPage = $scope.Survey.currentPage + 1;
                            $scope.Survey.progressbar = parseInt((($scope.Survey.currentPage + 1) / $scope.Survey.questions.length) * 100);
                        } else if ($scope.Survey.currentPage >= ($scope.Survey.questions.length / $scope.Survey.pageSize - 1)) {
                            jQuery('form.ah-survey-submit-form', this).trigger('submit');
                        }
                    }
                }
            }
        });
    }, true);

    jQuery(document).on('click', '.ah-survey-question-type .ah-question-buttons .ah-btn', function () {
        let value = jQuery(this).data('value');
        jQuery(this).parent().find('.ah-btn').removeClass('active');
        jQuery(this).addClass('active');
        if (value != 'other-btn') {
            jQuery(this).parent().next().hide().find('input:text').val(value).trigger('input');
        } else {
            jQuery(this).parent().next().fadeIn(300).find('input:text').val('').trigger('input');
        }
    });

    jQuery(document).on('click', '.ah-survey-question-type .ah-questions-photo-list > ul > li > div.img', function () {
        let value = jQuery(this).data('value');
        jQuery(this).parent().parent().find('> li > div.img').removeClass('active');
        jQuery(this).addClass('active');
        jQuery(this).parent().parent().parent().find('input[type="text"]').val(value).trigger('input');
    });

    jQuery(document).on('blur', '.ah-date-time-picker, .ah-date-picker, .ah-time-picker', function () {
        jQuery(this).trigger('input');
    });

    jQuery(document).on('input', '.ah-questions-photo-list input[type="text"]', function () {
        jQuery(this).parent().find('ul > li > div.img').removeClass('active');
        jQuery(this).parent().find('ul > li > div[data-value="' + jQuery(this).val() + '"]').addClass('active');
    });

    jQuery(document).on('keypress', 'form.ah-survey-submit-form input', function (e) {
        let keyCode = e.keyCode || e.which;
        let survey = jQuery(this).parents('.ah-survey-front');
        if (keyCode === 13) {
            e.preventDefault();
            return false;
        }
    });

    angular.element(document).ready(function () {
        jQuery('.ah-survey-front').css('visibility', 'visible');
        jQuery(".chosen-select").chosen({width: "100%"});
    });

}).filter('startFrom', function () {
    return function (input, start) {
        start = +start;
        return input.slice(start);
    }
}).filter("trustHTML", function ($sce) {
    return function (htmlCode) {
        return $sce.trustAsHtml(htmlCode);
    }
});

ahSurveyApp.filter('unsafe', function ($scope) {
    return $scope.trustAsHtml;
});

ahSurveyApp.filter('range', function () {
    return function (input, total) {
        total = parseInt(total);
        for (let i = 0; i < total; i++) {
            input.push(i);
        }
        return input;
    };
});

ahSurveyApp.directive('ahNgStarsRating', function ($compile, $timeout) {
    return {
        template: `<div class="ah-ng-rating ah-ng-stars-rating"> 
                        <input type="hidden" ng-model="directiveModel" name="questions[{{questionId}}]">    
                   </div>`,
        replace: true,
        link: function (scope, element) {
            scope.directiveModel = 0;
            scope.rating = 0;
            scope.changeValue = (value) => {
                scope.directiveModel = value;
                scope.rating = value;
            }
            const el = angular.element('<span/>');
            const count_elm = angular.element('<span class="ah-ng-rating-count"></span>');
            console.log('---scope-----', scope)
            const max = (scope.questionOptions && scope.questionOptions.stars_count) ? scope.questionOptions.stars_count : 5;
            let value = 0;
            const stars = [];
            for (let i = 0; i < max; i++) {
                let tooltip = (scope.questionOptions.show_tooltip == 'on') ? String(i + 1) : '';
                const star = angular.element('<span tooltip="' + tooltip + '" data-id="' + (i + 1) + '"  ng-click="changeValue(' + (i + 1) + ');"><i class="fi-star-1"></i></span>');
                stars.push(star);
                el.append(star);
                star.bind('mouseover', function () {
                    jQuery(this).find('>i').removeClass('star-empty');
                    jQuery(this).find('>i').addClass('star-active');
                    value = angular.element(this).attr('data-id');
                    updateStars(value);
                }).bind('mouseout', function () {
                    updateStars(value);
                });
            }
            el.append(`<span class="ah-ng-rating-count" ng-if="questionOptions.show_value=='on'">({{rating}}/{{questionOptions.stars_count}})</span>`);

            function updateStars(val) {
                for (let j = 0; j < max; j++) {
                    if (parseInt(stars[j].attr('data-id')) <= val) {
                        stars[j].find('>i').removeClass("star-empty");
                        stars[j].find('>i').addClass("star-active");
                    } else {
                        stars[j].find('>i').removeClass("star-active");
                        stars[j].find('>i').addClass("star-empty");
                    }
                }
            }

            el.bind('mouseout', function () {
                updateStars(scope.rating);
            });
            $compile(el)(scope);
            element.append(el);
        },
        scope: {
            questionId: '=',
            questionOptions: '=',
            directiveModel: '=ngModel',
        }
    }
})

ahSurveyApp.directive('ahNgHeartsRating', function ($compile, $timeout) {
    return {
        template: `<div class="ah-ng-rating ah-ng-hearts-rating"> 
                        <input type="hidden" ng-model="directiveModel" name="questions[{{questionId}}]">  
                   </div>`,
        replace: true,
        link: function (scope, element) {
            scope.directiveModel = 0;
            scope.rating = 0;
            scope.changeValue = (value) => {
                scope.directiveModel = value;
                scope.rating = value;
            }
            const el = angular.element('<span/>');
            const count_elm = angular.element('<span class="ah-ng-rating-count"></span>');
            const max = (scope.questionOptions && scope.questionOptions.hearts_count) ? scope.questionOptions.hearts_count : 5;
            let value = 0;
            const stars = [];
            for (let i = 0; i < max; i++) {
                let tooltip = (scope.questionOptions.show_tooltip == 'on') ? String(i + 1) : '';
                const star = angular.element('<span tooltip="' + tooltip + '" data-id="' + (i + 1) + '"  ng-click="changeValue(' + (i + 1) + ');"><i class="fi-like-1"></i></span>');
                stars.push(star);
                el.append(star);
                star.on('mouseover', function () {
                    jQuery(this).find('>i').removeClass('heart-empty');
                    jQuery(this).find('>i').addClass('heart-active');
                    value = angular.element(this).attr('data-id');
                    updateStars(value);
                }).on('mouseout', function () {
                    updateStars(value);
                });
            }
            el.append(`<span class="ah-ng-rating-count" ng-if="questionOptions.show_value=='on'">({{rating}}/{{questionOptions.hearts_count}})</span>`);

            function updateStars(val) {
                for (let j = 0; j < max; j++) {
                    if (parseInt(stars[j].attr('data-id')) <= val) {
                        stars[j].find('>i').removeClass("heart-empty");
                        stars[j].find('>i').addClass("heart-active");
                    } else {
                        stars[j].find('>i').removeClass("heart-active");
                        stars[j].find('>i').addClass("heart-empty");
                    }
                }
            }

            el.bind('mouseout', function () {
                updateStars(scope.rating);
            });
            $compile(el)(scope);
            element.append(el);
        },
        scope: {
            questionId: '=',
            questionOptions: '=',
            directiveModel: '=ngModel',
        }
    }
})

ahSurveyApp.run(function (toastrConfig) {
    angular.extend(toastrConfig, {
        autoDismiss: false,
        containerId: 'toast-container',
        maxOpened: 0,
        newestOnTop: true,
        positionClass: 'toast-bottom-right',
        preventDuplicates: false,
        preventOpenDuplicates: false,
        target: 'body',
        progressBar: true,
        closeButton: true,
        extendedTimeOut: 10000,
    });
});

angular.bootstrap(angular.element('.ah-survey-front'), ['ahSurveyApp', 'toastr']);

function arrayFilter(array, value, key) {
    return array.filter(key
        ? a => a[key] === value
        : a => Object.keys(a).some(k => a[k] === value)
    );
}
