/*
 * Admin Survey Controller
 */

ahSurveyApp.controller("AdminSurveyCtrl", function ($scope, $timeout, $interval, $compile, $filter, $http, toastr, Confirm) {

    function questions_type() {
        return {
            "short-text": {
                type: "short-text",
                img: "short-text.svg",
                title: "Short Text",
                options: {
                    placeholder: '',
                    input_mask: 'text'
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "slider": {
                type: "slider",
                img: "slider.svg",
                title: "Slider",
                options: {
                    min_value: 0,
                    max_value: 100,
                    step_value: 1
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "long-text": {
                type: "long-text",
                img: "long-text.svg",
                title: "Long Text",
                options: {
                    placeholder: '',
                    rows_count: 4,
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "dropdown": {
                type: "dropdown",
                img: "dropdown.svg",
                title: "Select Dropdown",
                options: {
                    placeholder: '',
                    answers: [{
                        label: 'Answer 1'
                    }]
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "points5": {
                type: "points5",
                img: "points5.svg",
                title: "5 Points Choice",
                options: {
                    no_answer: false
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "buttons": {
                type: "buttons",
                img: "buttons.svg",
                title: "Buttons Choice",
                options: {
                    answers: [{
                        label: 'Answer 1'
                    }],
                    other: false,
                    is_other: false,
                    toggle_other: function () {
                    }
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "emoji": {
                type: "emoji",
                img: "emoji.svg",
                title: "Emoji Buttons",
                options: {
                    emoji_count: '2'
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "like-dislike": {
                type: "like-dislike",
                img: "like-dislike.png",
                title: "Like And Dislike",
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "rating-hearts": {
                type: "rating-hearts",
                img: "rating-hearts.svg",
                title: "Hearts Rating",
                options: {
                    hearts_count: '5',
                    show_tooltip: 'on',
                    show_value: 'on',
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "rating-stars": {
                type: "rating-stars",
                img: "rating-stars.png",
                title: "Stars Rating",
                options: {
                    stars_count: '5',
                    show_tooltip: 'on',
                    show_value: 'on',
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "radio-list": {
                type: "radio-list",
                img: "radio-list.svg",
                title: "Radio List",
                options: {
                    display_type: 'list',
                    answers: [{
                        label: 'Answer 1'
                    }]
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "buttons-list": {
                type: "buttons-list",
                img: "buttons-list.svg",
                title: "Buttons List",
                options: {
                    answers: [{
                        label: 'Answer 1'
                    }]
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "photo-list": {
                type: "photo-list",
                img: "photo-list.svg",
                title: "Photos Choices List",
                options: {
                    display_type: 'list',
                    display_size: '64',
                    display_custom_size: {
                        width: 64,
                        height: 64
                    },
                    answers: [{
                        label: 'Answer 1',
                        photo: ''
                    }]
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
            "checkbox-list": {
                type: "checkbox-list",
                img: "checkbox-list.svg",
                title: "Checkbox List",
                options: {
                    answers: [{
                        label: 'Answer 1'
                    }]
                },
                condition: {
                    question: 0,
                    operator: '',
                    value: ''
                }
            },
        };

    }

    let import_progressbar_interval;

    $scope.range = function (min, max, step) {
        step = step || 1;
        let input = [];
        for (let i = min; i <= max; i += step) {
            input.push(i);
        }
        return input;
    };

    $scope.range_descending = function (max, min) {
        let list = [];
        for (let i = max; i >= min; i--) {
            list.push(i);
        }
        return list;
    }


    $scope.questions_types = questions_type();

    $scope.wp_test = 'Hello Wp Editor';

    $scope.answers_count = 0;

    $scope.Survey = {
        table_loading: false,
        list: [],
        meta: {},
        search: {
            title: '',
        },
        get_data: function () {
            return $filter('filter')(this.list, this.search)
        },
        number_of_pages: function () {
            return Math.ceil(this.get_data().length / this.pagination.page_size);
        },
        pagination: {
            current_page: 0,
            page_size: 10,
            next: function ($event) {
                $event.preventDefault();
                let btn = jQuery($event.currentTarget);
                this.current_page = this.current_page + 1;
            },
            prev: function ($event) {
                $event.preventDefault();
                let btn = jQuery($event.currentTarget);
                this.current_page = this.current_page - 1;
            }
        },
        is_expiry_date: function (expire_date) {
            let today = $filter('date')(new Date(), 'yyyy-MM-dd');
            return (expire_date <= today);
        },
        delete: function ($event) {
            let btn = jQuery($event.currentTarget);
            let ajax_url = btn.data('ajax');
            let nonce = btn.data('nonce');
            let ID = btn.data('id');
            Confirm.delete({
                title: ah_survey_scripts_object.delete,
                content: ah_survey_scripts_object.delete_survey
            }, function () {
                btn.parents('tr#survey-' + ID).css('background', '#ffbebe').delay(200).fadeOut();
                jQuery.post(ajax_url, {
                    action: 'delete_surveys',
                    nonce: nonce,
                    ID: ID
                }).done(function (response) {
                    toastr.success(response.message);
                }).fail(function (xhr, status, errors) {
                    if (xhr.status == 400) {
                        toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 400');
                    }
                });
            });
        },
        get: function () {
            let table = jQuery('table.surveys-list')
            let data = {
                action: table.data('action'),
                nonce: table.data('nonce')
            };
            $scope.Survey.table_loading = true;
            jQuery.post(table.attr('action'), data).done(function (response) {
                $scope.Survey.table_loading = false;
                $scope.Survey.list = response;
                $scope.$apply();
            }).fail(function (xhr, status, errors) {
                if (xhr.status == 400) {
                    toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 400');
                }
                $scope.Survey.table_loading = false;
                $scope.$apply();
            });
        },
        form: {
            loading: false,
            errors: {},
            data: {
                survey_view: 'all-in-one',
                send_responses_email: 'false',
                next_on_answer: 'false',
            },
            save: function ($event) {
                let form = jQuery($event.currentTarget);
                const $this = this;
                $this.loading = true;
                tinymce.triggerSave();
                let data = form.serializeArray();
                let formData = _.object(_.pluck(data, 'name'), _.pluck(data, 'value'));
                Object.toparams = function ObjecttoParams(obj) {
                    var p = [];
                    for (var key in obj) {
                        p.push(key + '=' + encodeURIComponent(obj[key]));
                    }
                    return p.join('&');
                };
                $event.preventDefault();
                $http({
                    method: "POST",
                    url: form.attr('action'),
                    data: Object.toparams(formData),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                }).then(function (response) {
                    if (response.data.survey_id && response.data.survey_id >= 1) {
                        redirect(ah_survey_scripts_object.plugin_url + 'ah-survey&edit=' + response.data.survey_id);
                    } else {
                        toastr.success(response.data.message, ah_survey_scripts_object.success);
                        $this.loading = false;
                    }
                }, function (response) {
                    if (response.data.message) {
                        $this.errors = (response.data.message) ? response.data.message : {};
                    }
                    jQuery("html, body").animate({scrollTop: 0}, "slow");
                    $this.loading = false;
                });
            },
            export: function ($event) {
                const $this = this;
                let btn = jQuery($event.currentTarget);
                let ajax_url = btn.data('ajax')
                let nonce = btn.data('nonce')
                let ID = btn.data('id');
                let data_type = 'full-data';
                Confirm.export_survey({
                    title: ah_survey_scripts_object.export_survey_title,
                    content: ah_survey_scripts_object.export_survey_content,
                    survey_button_text: ah_survey_scripts_object.export_survey_button_text,
                    questions_text: ah_survey_scripts_object.export_questions_text
                }, function () {
                    data_type = 'full-data';
                    window.open(ajax_url + `?action=${'export_survey'}&nonce=${nonce}&ID=${ID}&type=${data_type}`, '_blank').focus();
                }, function () {
                    data_type = 'questions';
                    window.open(ajax_url + `?action=${'export_survey'}&nonce=${nonce}&ID=${ID}&type=${data_type}`, '_blank').focus();
                });
            },
            duplicate: function ($event) {
                const $this = this;
                let btn = jQuery($event.currentTarget);
                let ajax_url = btn.data('ajax')
                let nonce = btn.data('nonce')
                let ID = btn.data('id');
                let data_type = 'full-data';
                Confirm.duplicate_survey({
                    title: ah_survey_scripts_object.duplicate_survey_title,
                    content: ah_survey_scripts_object.duplicate_survey_content,
                    duplicate_survey_button_text: ah_survey_scripts_object.duplicate_survey_button_text,
                }, function () {
                    jQuery('.ah-survey-wrap.ah-survey').addClass('has-loading');
                    jQuery.post(ajax_url, {
                        action: 'duplicate_survey',
                        nonce: nonce,
                        ID: ID
                    }).done(function (response) {
                        window.location.replace(response.url);
                        jQuery('.ah-survey-wrap.ah-survey').removeClass('has-loading');
                    }).fail(function (xhr, status, errors) {
                        if (xhr.status == 400) {
                            toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 400');
                        } else if (xhr.status == 404) {
                            toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 404');
                        }
                        jQuery('.ah-survey-wrap.ah-survey').removeClass('has-loading');
                    });
                });
            },
            delete: function ($event) {
                let btn = jQuery($event.currentTarget);
                let ajax_url = btn.data('ajax')
                let nonce = btn.data('nonce')
                let ID = btn.data('id');
                Confirm.delete({
                    title: ah_survey_scripts_object.delete,
                    content: ah_survey_scripts_object.delete_survey
                }, function () {
                    jQuery('.ah-survey-wrap.ah-survey').addClass('has-loading');
                    jQuery.post(ajax_url, {
                        action: 'delete_surveys',
                        nonce: nonce,
                        ID: ID
                    }).done(function (response) {
                        window.location.replace(ah_survey_scripts_object.surveys_page_url);
                        jQuery('.ah-survey-wrap.ah-survey').removeClass('has-loading');
                    }).fail(function (xhr, status, errors) {
                        if (xhr.status == 400) {
                            toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 400');
                        } else if (xhr.status == 404) {
                            toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 404');
                        }
                        jQuery('.ah-survey-wrap.ah-survey').removeClass('has-loading');
                    });
                });
            },
            export_download: function (ajax_url, nonce, ID, type, done) {
                jQuery.post(ajax_url + `?action=${'export_survey'}&nonce=${nonce}&ID=${ID}&type=${type}`, {
                    ID: ID,
                    type: type,
                }).done(function (response) {
                    done(response);
                }).fail(function (xhr, status, errors) {
                    if (xhr.status == 400) {
                        toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 400');
                    } else if (xhr.status == 404) {
                        toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 404');
                    }
                });
            },
        },
        import: {
            data: {},
            survey_data: {},
            file_name: '',
            input_file: '',
            show_data: false,
            has_error: false,
            error: '',
            progressbar: 0,
            start_progressbar: function (callback) {
                const $this = this;
                if (angular.isDefined(import_progressbar_interval)) return;
                import_progressbar_interval = $interval(function () {
                    if ($this.progressbar < 100) {
                        $this.progressbar++;
                    } else {
                        $this.stop_progressbar();
                        callback();
                    }
                }, 50);
            },
            stop_progressbar: function () {
                if (angular.isDefined(import_progressbar_interval)) {
                    $interval.cancel(import_progressbar_interval);
                    import_progressbar_interval = undefined;
                }
            },
            open: function ($event) {
                this.cancel($event);
            },
            upload: function (input) {
                const $this = this;
                let file = input.files[0];
                $this.file_name = (file && file.name) ? file.name : '';
                if (file && file.name && file.size && file.type && file.type == 'application/json') {
                    if (parseFloat((file.size / 1024) / 1024) <= 5) {
                        let fr = new FileReader();
                        fr.onload = (e) => {
                            let lines = e.target.result;
                            try {
                                $this.data = JSON.parse(lines);
                                if ($this.data && $this.data['ah-survey-data'] && $this.data['ah-survey-data'].title) {
                                    $this.start_progressbar(function () {
                                        let meta = {};
                                        $this.show_data = true;
                                        $this.data = $this.data['ah-survey-data'];
                                        $this.data.title += ' [imported]';
                                        $this.survey_data = angular.copy($this.data);
                                        $this.data.meta.map((m) => meta[m.meta_key] = m.meta_value);
                                        $this.data.meta = meta;
                                    });
                                } else {
                                    $this.has_error = true;
                                    $this.error = ah_survey_scripts_object.error_json_survey_structure;
                                }
                                $scope.$apply();
                            } catch (e) {
                                $this.has_error = true;
                                $this.error = String(e);
                                $scope.$apply();
                            }
                        };
                        fr.readAsText(file);
                        $this.has_error = false;
                    } else {
                        $this.has_error = true;
                        $this.error = ah_survey_scripts_object.error_json_file_size;
                    }
                } else {
                    $this.has_error = true;
                    $this.error = ah_survey_scripts_object.error_json_file_type;
                }
                $scope.$apply();
            },
            insert: function ($event) {
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                let ajax_url = btn.data('ajax');
                let nonce = btn.data('nonce');
                let data = this.survey_data;
                console.log('this.survey_data', this.survey_data)
                modal.modal('hide');
                jQuery.post(ajax_url, {
                    action: 'import_survey',
                    nonce: nonce,
                    survey_data: data
                }).done(function (response) {
                    toastr.success(response.message);
                    $scope.Survey.get();
                }).fail(function (xhr, status, errors) {
                    if (xhr.status == 400) {
                        toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 400');
                    }
                });
            },
            cancel: function ($event) {
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                jQuery('#survey-file', modal).val('');
                this.data = {};
                this.survey_data = {};
                this.file_name = '';
                this.input_file = '';
                this.error = '';
                this.progressbar = 0;
                this.has_error = false;
                this.show_data = false;
                this.stop_progressbar();
            },
        }
    }

    $scope.Questions = {
        list: [],
        sort_list: {
            handle: '.question-btn-move',
            update: function (e, ui) {

            },
            stop: function (e, ui) {
            }
        },
        selected_type: '',
        active_type: '',
        add_type: function () {
            $scope.questions_types = [];
            $scope.questions_types = questions_type();
            this.selected_type = $scope.questions_types[this.active_type];
            this.modal.form.question.type = this.active_type;
            this.modal.form.question.options = this.selected_type.options;
            this.show_types = false;
        },
        select_type: function ($event) {
            let question = jQuery($event.currentTarget);
            this.active_type = question.data('question-type');
        },
        open_types: function () {
            let top = 0;
            this.show_types = true;
            if (this.selected_type)
                this.active_type = this.selected_type.type
            $timeout(function () {
                top = 0;
                let $questions_list = jQuery('.ah-survey-questions-types .questions-types-content.types-list');
                if (jQuery('.question-type-block.active', $questions_list).length) {
                    top = jQuery('.question-type-block.active', $questions_list).offset().top - $questions_list.offset().top;
                }
                $questions_list.each(function () {
                    if ($scope.Questions.modal.type == 'update') {
                        if (top >= 200) {
                            jQuery(this).animate({
                                scrollTop: top - 10
                            }, 500);
                        }
                    } else if ($scope.Questions.modal.type == 'create') {
                        if (top >= 200) {
                            jQuery(this).animate({
                                scrollTop: top - 10
                            }, 500);
                        }
                    }
                }, 100);
            }, 250);
        },
        show_types: false,
        input_mask_list: {
            "text": {
                type: 'text',
                label: ah_survey_scripts_object.text,
            },
            "number": {
                type: 'number',
                label: ah_survey_scripts_object.number,
            },
            "date_time": {
                type: 'date_time',
                label: ah_survey_scripts_object.date_time,
            },
            "date": {
                type: 'date',
                label: ah_survey_scripts_object.date,
            },
            "time": {
                type: 'time',
                label: ah_survey_scripts_object.time,
            },
        },
        buttons: {
            empty_question: function () {
                $scope.Questions.modal.form.question.name = '';
                $scope.Questions.modal.form.question.help = '';
                $scope.Questions.modal.form.question.type = '';
                $scope.Questions.modal.form.question.options = '';
                $scope.Questions.modal.form.question.is_required = false;
                $scope.Questions.selected_type = '';
                $scope.Questions.active_type = '';
            },
            new: function ($event) {
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                $scope.Questions.modal.type = 'create';
                this.empty_question();
                $scope.Questions.show_types = false;
                $scope.Questions.selected_type = '';
                $scope.Questions.active_type = '';
                $scope.answers_count = 0;
            },
            save: function ($event) {
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                let question = $scope.Questions.modal.form.question;
                modal.modal('hide');
                $scope.Questions.list.push({
                    uid: new Date().getTime(),
                    name: question.name,
                    help: question.help,
                    type: question.type,
                    is_required: question.is_required,
                    options: question.options,
                })
            },
            edit: function ($event) {
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                let options = {};
                let uid = btn.attr('data-question-uid');
                let question = $filter('filter')($scope.Questions.list, {'uid': uid});
                $timeout(function () {
                    jQuery('.btn-question-update', modal).attr('data-question-uid', btn.attr('data-question-uid'));
                }, 100);
                if (question && question[0]) {
                    $scope.Questions.show_types = false;
                    $scope.Questions.selected_type = $scope.questions_types[question[0].type];
                    $scope.Questions.active_type = question[0].type;
                    $scope.Questions.modal.type = 'update';
                    $scope.questions_types = [];
                    $scope.questions_types = questions_type();
                    $scope.Questions.selected_type = $scope.questions_types[question[0].type];
                    $scope.Questions.modal.form.question.name = question[0].name;
                    $scope.Questions.modal.form.question.help = question[0].help;
                    $scope.Questions.modal.form.question.type = question[0].type;
                    $scope.Questions.modal.form.question.is_required = question[0].is_required;
                    if (question[0].options) {
                        Object.keys(question[0].options).forEach(function (option) {
                            if (question && question[0] && question[0].options['answers']) {
                                let answers = question[0].options['answers'];
                                $scope.answers_count = (answers.length - 1);
                            }
                            options[option] = question[0].options[option];
                        });
                    }
                    $scope.Questions.modal.form.question.options = options;
                }
            },
            update: function ($event) {
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                let uid = btn.attr('data-question-uid');
                let options = {}
                let question = $scope.Questions.modal.form.question;
                let update_question = $filter('filter')($scope.Questions.list, {'uid': uid});
                modal.modal('hide');
                if (update_question && update_question[0]) {
                    update_question[0].name = question.name;
                    update_question[0].help = question.help;
                    update_question[0].type = question.type;
                    update_question[0].is_required = question.is_required;
                    if (question.options) {
                        Object.keys(question.options).forEach(function (option) {
                            options[option] = question.options[option];
                        });
                    }
                    update_question[0].options = options;
                }
            },
            delete: function ($event) {
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                let options = {};
                let uid = btn.attr('data-question-uid');
                for (let i = $scope.Questions.list.length - 1; i >= 0; i--) {
                    if ($scope.Questions.list[i].uid == uid) {
                        Confirm.delete({
                            title: ah_survey_scripts_object.delete,
                            content: ah_survey_scripts_object.delete_question
                        }, function () {
                            $scope.Questions.list.splice(i, 1);
                            $scope.$apply();
                        });
                    }
                }
            },
            set_condition: function ($event, question) {
                const $this = this;
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                let index = $scope.Questions.list.map(q => q.uid).indexOf(question.uid);
                let questions = $scope.Questions.list.slice(0, index);
                $scope.Questions.modal.form.condition.type = 'create';
                $scope.Questions.modal.form.condition.questions_list = questions;
                $scope.Questions.modal.form.condition.select_question = question;
                $timeout(function () {
                    jQuery('.chosen-select').trigger('change');
                    jQuery('.chosen-select').trigger('chosen:updated');
                }, 250);
            },
            update_condition: function ($event, question) {
                const $this = this;
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                let index = $scope.Questions.list.map(q => q.uid).indexOf(question.uid);
                let questions = $scope.Questions.list.slice(0, index);
                let previous_question = $scope.Questions.list.filter(q => q.uid == question.condition.question)[0];
                $scope.Questions.modal.form.condition.type = 'update';
                $scope.Questions.modal.form.condition.questions_list = questions;
                $scope.Questions.modal.form.condition.select_question = question;
                $scope.Questions.modal.form.condition.previous_question = {
                    uid: question.condition.question,
                    data: previous_question
                };
                $scope.Questions.modal.form.condition.data.operator = question.condition.operator;
                $scope.Questions.modal.form.condition.data.value = ((['slider']).includes(previous_question.type)) ? parseFloat(question.condition.value) : question.condition.value;
                $timeout(function () {
                    jQuery('.chosen-select').trigger('change');
                    jQuery('.chosen-select').trigger('chosen:updated');
                }, 250);
            },
            remove_condition: function ($event, question) {
                let condition_question = $scope.Questions.list.filter(q => q.uid == question.condition.question)[0];
                let default_question = $scope.questions_types[condition_question.type];
                Confirm.delete({
                    title: ah_survey_scripts_object.remove,
                    content: ah_survey_scripts_object.delete_question_condition
                }, function () {
                    $timeout(function () {
                        question.condition = default_question.condition
                    }, 100);
                });
            },
            change_condition: function ($event) {
                let question_uid = $scope.Questions.modal.form.condition.previous_question.uid;
                let previous_question = {};
                let operator = $scope.Questions.modal.form.condition.data.operator;
                if (question_uid && question_uid.length) {
                    previous_question = $scope.Questions.list.filter(q => q.uid == $scope.Questions.modal.form.condition.previous_question.uid)[0];
                    $scope.Questions.modal.form.condition.previous_question.data = (previous_question && previous_question.uid) ? previous_question : {};
                    $scope.Questions.modal.form.condition.data.value = "";
                }
            },
            save_condition: function ($event) {
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                let previous_question = $scope.Questions.modal.form.condition.previous_question;
                let select_question = $scope.Questions.modal.form.condition.select_question;
                let operator = $scope.Questions.modal.form.condition.data.operator;
                let value = $scope.Questions.modal.form.condition.data.value;
                select_question.condition = {
                    question: previous_question.uid,
                    operator: operator,
                    value: value
                };
                modal.modal('hide');
            }
        },
        modal: {
            type: 'create',
            form: {
                enable_update: false,
                updated_question: {},
                question: {
                    uid: new Date().getTime(),
                    name: '',
                    help: '',
                    type: '',
                    options: {},
                    is_required: false,
                    add_answers: function (type = '', value = 'Answer ') {
                        $scope.answers_count++;
                        let answer = value + ($scope.answers_count + 1);
                        if (this.type && this.type == 'photo-list') {
                            this.options.answers.push({
                                label: answer,
                                photo: ''
                            });
                        } else {
                            this.options.answers.push({
                                label: answer,
                            })
                        }
                    },
                    remove_answers: function (answers, answer) {
                        answers.splice(answers.indexOf(answer), 1);
                        $scope.answers_count = (answers.length - 1);
                    },
                    is_sort_answers: false,
                    sort_answers: {
                        handle: '.answer-move',
                        update: function (e, ui) {

                        },
                        stop: function (e, ui) {
                        }
                    },
                },
                condition: {
                    type: 'create',
                    operators: [
                        {
                            operator: 'equal',
                            label: ah_survey_scripts_object.equal,
                            dependencies: ['short-text', 'long-text', 'dropdown', 'slider', 'points5', 'buttons', 'emoji', 'like-dislike', 'rating-hearts', 'rating-stars', 'radio-list', 'buttons-list', 'photo-list']
                        },
                        {
                            operator: 'not_equal',
                            label: ah_survey_scripts_object.not_equal,
                            dependencies: ['short-text', 'long-text', 'dropdown', 'slider', 'points5', 'buttons', 'emoji', 'like-dislike', 'rating-hearts', 'rating-stars', 'radio-list', 'buttons-list', 'photo-list']
                        },
                        {
                            operator: 'less_than',
                            label: ah_survey_scripts_object.less_than,
                            dependencies: ['slider', 'points5', 'rating-hearts', 'rating-stars']
                        },
                        {
                            operator: 'less_than_or_equal',
                            label: ah_survey_scripts_object.less_than_or_equal,
                            dependencies: ['slider', 'points5', 'rating-hearts', 'rating-stars']
                        },
                        {
                            operator: 'greater_than',
                            label: ah_survey_scripts_object.greater_than,
                            dependencies: ['slider', 'points5', 'rating-hearts', 'rating-stars']
                        },
                        {
                            operator: 'greater_than_or_equal',
                            label: ah_survey_scripts_object.greater_than_or_equal,
                            dependencies: ['slider', 'points5', 'rating-hearts', 'rating-stars']
                        },
                        {
                            operator: 'in',
                            label: ah_survey_scripts_object.in,
                            dependencies: ['checkbox-list']
                        },
                        {
                            operator: 'not_in',
                            label: ah_survey_scripts_object.not_in,
                            dependencies: ['checkbox-list']
                        },
                        {
                            operator: 'is_null',
                            label: ah_survey_scripts_object.is_null,
                            dependencies: ['short-text', 'long-text']
                        },
                        {
                            operator: 'is_not_null',
                            label: ah_survey_scripts_object.is_not_null,
                            dependencies: ['short-text', 'long-text']
                        },
                    ],
                    data: {
                        operator: '',
                        value: '',
                    },
                    questions_list: [],
                    select_question: {},
                    previous_question: {
                        uid: 0,
                        data: {}
                    },
                }
            }
        },
        show_condition: function (condition) {
            let operators_text = {
                'equal': '==',
                'not_equal': '!=',
                'less_than': '<',
                'less_than_or_equal': '<=',
                'greater_than': '>',
                'greater_than_or_equal': '>=',
                'in': 'in',
                'not_in': 'not in',
                'is_null': '==',
                'is_not_null': '!=',
            };
            let question = $scope.Questions.list.filter(q => q.uid == condition.question)[0];
            let operator = condition.operator;
            let value = (Array.isArray(condition.value)) ? '(' + condition.value.join(',') + ')' : condition.value;
            if (question && question.uid && operator) {
                return `<div class="ah-survey-show-condition">
                             <a class="d-inline-block text-primary cursor-pointer font-12 font-600" tooltip="${question.name} ${operators_text[operator]} ${(value) ? value : 'null'}" ng-click="Questions.buttons.update_condition($event,question)" data-toggle="modal" data-target="#questionConditionModal">Q[${question.uid}]
                             <span class="d-inline-block text-success font-14 font-600"> ${operators_text[operator]} </span>
                             <span class="d-inline-block text-secondary font-14 font-600"> ${(value) ? value : 'null'} </span>
                             </a>
                             <button type="button" ng-click="Questions.buttons.remove_condition($event,question)" tooltip="${ah_survey_scripts_object.remove}" class="ah-btn ah-btn-sm ah-btn-outline-danger ah-btn-survey-remove-condition"><i class="far fa-times"></i></button> 
                        </div>
                       `;
            }
        },
        import: {
            list: [],
            surveys: [],
            questions: [],
            selected_questions: {},
            selected_survey: '',
            file_name: '',
            input_file: '',
            show_questions: false,
            has_error: false,
            error: '',
            progressbar: 0,
            selected_questions_count: 0,
            start_progressbar: function (callback) {
                const $this = this;
                if (angular.isDefined(import_progressbar_interval)) return;
                import_progressbar_interval = $interval(function () {
                    if ($this.progressbar < 100) {
                        $this.progressbar++;
                    } else {
                        $this.stop_progressbar();
                        callback();
                    }
                }, 50);
            },
            stop_progressbar: function () {
                if (angular.isDefined(import_progressbar_interval)) {
                    $interval.cancel(import_progressbar_interval);
                    import_progressbar_interval = undefined;
                }
            },
            open: function ($event) {
                this.cancel($event);
            },
            cancel: function ($event) {
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                jQuery('#questions-file', modal).val('');
                jQuery('a[data-tab="import-upload-file"]', modal).trigger('click');
                this.file_name = '';
                this.input_file = '';
                this.selected_survey = '';
                this.error = '';
                this.progressbar = 0;
                this.show_questions = false;
                this.has_error = false;
                this.questions = [];
                this.selected_questions = {};
                this.stop_progressbar();
            },
            upload: function (input) {
                const $this = this;
                let file = input.files[0];
                $this.file_name = (file && file.name) ? file.name : '';
                if (file && file.name && file.size && file.type && file.type == 'application/json') {
                    if (parseFloat((file.size / 1024) / 1024) <= 5) {
                        let fr = new FileReader();
                        fr.onload = (e) => {
                            let lines = e.target.result;
                            try {
                                $this.questions = JSON.parse(lines);
                                if ($this.questions && $this.questions['ah-survey-questions']) {
                                    if ($this.questions['ah-survey-questions'].length) {
                                        $this.start_progressbar(function () {
                                            $this.show_questions = true;
                                            $this.questions = $this.questions['ah-survey-questions'];
                                        });
                                    } else {
                                        $this.has_error = true;
                                        $this.error = ah_survey_scripts_object.error_json_questions_empty;
                                    }
                                } else {
                                    $this.has_error = true;
                                    $this.error = ah_survey_scripts_object.error_json_questions_structure;
                                }
                                $scope.$apply();
                            } catch (e) {
                                $this.has_error = true;
                                $this.error = String(e);
                                $scope.$apply();
                            }
                        };
                        fr.readAsText(file);
                        $this.has_error = false;
                    } else {
                        $this.has_error = true;
                        $this.error = ah_survey_scripts_object.error_json_file_size;
                    }
                } else {
                    $this.has_error = true;
                    $this.error = ah_survey_scripts_object.error_json_file_type;
                }
                $scope.$apply();
            },
            insert: function ($event) {
                let btn = jQuery($event.currentTarget);
                let modal = jQuery(btn.data('target'));
                modal.modal('hide');
                $scope.Questions.list = $scope.Questions.import.list;
            },
            clear: function () {
                const $this = this;
                let modal = jQuery('#importQuestionsModal');
                $this.show_questions = true;
                $this.questions = [];
                jQuery('a[data-tab="import-upload-file"]', modal).trigger('click');
            }
        }
    };

    $scope.Responses = {
        list: [],
        filter: {
            survey: {
                title: ''
            }
        },
        select_all: false,
        selected_ids: [],
        currentPage: 0,
        pageSize: 10,
        getData: function () {
            return $filter('filter')(this.list, this.filter)
        },
        numberOfPages: function () {
            return Math.ceil(this.getData().length / this.pageSize);
        },
        table_loading: false,
        get: function () {
            let table = jQuery('table.responses-list')
            let data = {
                action: table.data('action'),
                nonce: table.data('nonce')
            };
            this.table_loading = true;
            jQuery.post(table.data('ajax-url'), data)
                .done(function (response) {
                    $scope.Responses.table_loading = false;
                    $scope.Responses.list = response;
                    $scope.Responses.select_all = false;
                    $scope.$apply();
                })
                .fail(function (xhr, status, errors) {
                    if (xhr.status == 400) {
                        toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 400');
                    }
                    $scope.Responses.table_loading = false;
                    $scope.$apply();
                });
        },
        delete: function ($event) {
            $event.preventDefault();
            const $this = this;
            let btn = jQuery($event.currentTarget);
            let data = {
                action: btn.data('action'),
                nonce: btn.data('nonce'),
                id: btn.data('response-id')
            };
            Confirm.delete({
                title: ah_survey_scripts_object.delete,
                content: ah_survey_scripts_object.delete_response
            }, function () {
                jQuery.post(btn.data('ajax-url'), data).done(function (response) {
                    toastr.success(response.message);
                    $this.get();
                }).fail(function (xhr, status, errors) {
                    if (xhr.status == 400) {
                        toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 400');
                    }
                });
            });
        },
        delete_selected: function ($event) {
            $event.preventDefault();
            const $this = this;
            let btn = jQuery($event.currentTarget);
            let data = {
                action: btn.data('action'),
                nonce: btn.data('nonce'),
                ids: $this.selected_ids
            };
            Confirm.delete({
                title: ah_survey_scripts_object.delete,
                content: ah_survey_scripts_object.delete_responses + ' <span style="font-size:14px;letter-spacing:0.5px;display:block;margin-top:10px;word-break:break-word;">' + JSON.stringify($this.selected_ids) + ' </span>'
            }, function () {
                jQuery.post(btn.data('ajax-url'), data).done(function (response) {
                    toastr.success(response.message);
                    $this.get();
                }).fail(function (xhr, status, errors) {
                    if (xhr.status == 400) {
                        toastr.error((xhr && xhr.responseJSON) ? xhr.responseJSON.message : '', 'Error 400');
                    }
                });
            });
        },
        show_location: function ($event) {
            let btn = jQuery($event.currentTarget);
            let ip = btn.attr('href').replace('#ip:', '');
            this.modal.location.get(ip);
        },
        show_answers: function ($event) {
            let btn = jQuery($event.currentTarget);
            let answers = JSON.parse(btn.attr('data-response-answers'));
            this.modal.answers.data = answers;
        },
        pagination: {
            next: function ($event) {
                $event.preventDefault();
                let btn = jQuery($event.currentTarget);
                $scope.Responses.currentPage = $scope.Responses.currentPage + 1;
                $scope.Responses.select_all = false;
            },
            prev: function ($event) {
                $event.preventDefault();
                let btn = jQuery($event.currentTarget);
                $scope.Responses.currentPage = $scope.Responses.currentPage - 1;
                $scope.Responses.select_all = false;
            }
        },
        modal: {
            location: {
                data: [],
                loading: true,
                get: function (ip) {
                    jQuery.get("https://ipinfo.io/" + ip + "/?token=6994c60112047e", function (response) {
                        $scope.Responses.modal.location.data = response;
                        $scope.Responses.modal.location.loading = false;
                        $scope.$apply();
                    }, "jsonp");
                }
            },
            answers: {
                questions: [],
                data: []
            }
        }
    };

    $scope.$watch('Responses.filter.survey_id', function (newValue, oldValue, scope) {
        scope.Responses.currentPage = 0;
    });

    $scope.$watch('Responses.selected', function (newValue, oldValue, scope) {
        angular.forEach(newValue, function (response_id, id) {
            scope.Responses.selected_ids.removeArrayItem(id);
            if (response_id == true) {
                scope.Responses.selected_ids.push(id);
            }
        });
        if (scope.Responses.selected_ids.length == scope.Responses.pageSize) {
            scope.Responses.select_all = true;
        } else if (scope.Responses.selected_ids.length == 0) {
            scope.Responses.select_all = false;
        }
    }, true);

    $scope.$watch('Responses.select_all', function (newValue, oldValue, scope) {
        jQuery('table.responses-list').each(function () {
            jQuery('tbody > tr.has-items').each(function () {
                if (newValue == true) {
                    jQuery('th[scope="row"]> input:checkbox').prop('checked', false).trigger('click');
                } else {
                    jQuery('th[scope="row"]> input:checkbox').prop('checked', true).trigger('click');
                }
            });
        });
    });

    $scope.$watch('Questions.import.selected_questions', function (newValue, oldValue, scope) {
        let selected_ids = [];
        let selected_questions = [];
        angular.forEach(newValue, (selected, id) => {
            if (selected == true) {
                selected_ids.push(id);
            } else {
                delete selected_ids[id];
            }
        });
        selected_questions = scope.Questions.import.questions.filter(question => selected_ids.includes(String(question.uid)));
        scope.Questions.import.list = selected_questions;
        scope.Questions.import.selected_questions_count = selected_ids.length;
    }, true);

    $scope.$watch('Questions.import.selected_survey', function (newValue, oldValue, scope) {
        let survey = scope.Questions.import.surveys.filter((survey) => survey.id == newValue)[0];
        if (survey && survey.questions && survey.questions.length) {
            scope.Questions.import.questions = PHP.parse(survey.questions);
            scope.Questions.import.show_questions = true;
        }
    }, true);

    jQuery(document).on('click', '.add_media_button', function (e) {
        let wp_custom_media = true;
        const wp_orig_send_attachment = wp.media.editor.send.attachment;
        let send_attachment_bkp = wp.media.editor.send.attachment;
        let button = jQuery(this);
        wp_custom_media = true;
        wp.media.editor.send.attachment = function (props, attachment) {
            if (wp_custom_media) {
                jQuery('#' + button.data('input-id')).val(attachment.url).trigger('input');
            } else {
                return wp_orig_send_attachment.apply(this, [props, attachment]);
            }
        };
        wp.media.editor.open(button);
        return false;
    });

    jQuery('.add_media').on('click', function () {
        wp_custom_media = false;
    });

    angular.element(document).ready(function () {
        jQuery('.ah-date-time-picker').datetimepicker({
            format: 'Y-m-d',
            timepicker: false,
            // format:'d.m.Y H:i',
            defaultDate: new Date()
        });

        jQuery('.ah-tags-input').tagsInput({
            width: '100%',
            height: 'auto',
            defaultText: ah_survey_scripts_object.add_email,
            pattern: /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/
        });
    });


}).filter('startFrom', function () {
    return function (input, start) {
        start = +start;
        return input.slice(start);
    }
}).filter('capitalize', function () {
    return function (input) {
        return (angular.isString(input) && input.length > 0) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : input;
    }
}).filter('capitalizeAll', function () {
    return function (str) {
        if (str === undefined) return; // avoid undefined
        str = str.toLowerCase().split(" ");
        var c = '';
        for (var i = 0; i <= (str.length - 1); i++) {
            var word = ' ';
            for (var j = 0; j < str[i].length; j++) {
                c = str[i][j];
                if (j === 0) {
                    c = c.toUpperCase();
                }
                word += c;
            }
            str[i] = word;
        }
        str = str.join('');
        return str;
    }
}).filter('dashToSpace', function () {
    return function (input) {
        return input.replace(/-/g, ' ');
    }
}).filter('slice', function () {
    return function (arr, start, end) {
        return (arr || []).slice(start, end);
    };
}).filter('operators_dependencies', function () {
    return function (operators, type) {
        let operators_list = [];
        angular.forEach(operators, function (operator) {
            if (operator.dependencies && operator.dependencies.includes(type)) {
                operators_list.push(operator);
            }
        });
        return operators_list;
    };
}).filter("trustHTML", function ($sce) {
    return function (htmlCode) {
        return $sce.trustAsHtml(htmlCode);
    }
}).directive('copyToClipboard', function (toastr) {
    return {
        restrict: 'A',
        link: function (scope, elem, attrs) {
            elem.click(function () {
                toastr.success('Shortcode copied', {
                    progressBar: true,
                    iconClass: 'toast-black'
                });
                if (attrs.copyToClipboard) {
                    var $temp_input = jQuery("<input>");
                    jQuery("body").append($temp_input);
                    $temp_input.val(attrs.copyToClipboard).select();
                    document.execCommand("copy");
                    $temp_input.remove();
                }
            });
        }
    };
}).directive('bindHtmlCompile', function ($compile) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            scope.$watch(function () {
                return scope.$eval(attrs.bindHtmlCompile);
            }, function (value) {
                // Incase value is a TrustedValueHolderType, sometimes it
                // needs to be explicitly called into a string in order to
                // get the HTML string.
                element.html(value && value.toString());
                // If scope is provided use it, otherwise use parent scope
                var compileScope = scope;
                if (attrs.bindHtmlScope) {
                    compileScope = scope.$eval(attrs.bindHtmlScope);
                }
                $compile(element.contents())(compileScope);
            });
        }
    };
});

function search(array, value) {
    return array.filter(obj => obj.uid === value);
}

function redirect(url) {
    var ua = navigator.userAgent.toLowerCase(),
        isIE = ua.indexOf('msie') !== -1,
        version = parseInt(ua.substr(4, 2), 10);

    // Internet Explorer 8 and lower
    if (isIE && version < 9) {
        var link = document.createElement('a');
        link.href = url;
        document.body.appendChild(link);
        link.click();
    }

    // All other browsers can use the standard window.location.href (they don't lose HTTP_REFERER like Internet Explorer 8 & lower does)
    else {
        window.location.href = url;
    }
}

function file_size_to_mb(size, show_label = false) {
    if (size > 0 && Math.floor(size / 1024) < 1024) {
        return parseFloat(Number(size / 1024).toFixed(2)) + ((show_label) ? ' KB' : '');
    } else if (Math.floor(size / 1024) >= 1024) {
        return parseFloat(Number((size / 1024) / 1024).toFixed(2)) + ((show_label) ? ' MB' : '');
    }
}

Array.prototype.removeArrayItem = function () {
    var what, a = arguments, L = a.length, ax;
    while (L && this.length) {
        what = a[--L];
        while ((ax = this.indexOf(what)) !== -1) {
            this.splice(ax, 1);
        }
    }
    return this;
};