/*
 * "Settings Controller
 */

ahSurveyApp.controller("SettingsCtrl", function ($scope, $http, $timeout, $compile, $filter, toastr, Confirm) {

    $scope.google_fonts = [];
    $scope.get_google_fonts = function () {
        jQuery.getJSON('https://www.googleapis.com/webfonts/v1/webfonts?sort=popularity&key=AIzaSyBJqVVeXitrpDa8jdbChll3SDc06ECwWTg', function (data) {
            $scope.google_fonts = (data && data.items) ? data.items : [];
            $scope.$apply();
            jQuery(".chosen-select").trigger("chosen:updated");
        })
    }

    $scope.general_settings = {};
    $scope.widget_settings = {};
    $scope.email_settings = {
        email_provider: 'wordpress'
    };

    $scope.Settings = {
        active_tabs: '',
        form: {
            loading: false,
            save: function ($event) {
                $event.preventDefault();
                const $this = this;
                var form = jQuery($event.currentTarget);
                this.loading = true;
                form.ajaxSubmit({
                    url: form.attr('action'),
                    data: form.serialize(),
                    dataType: 'json',
                    beforeSubmit: function () {

                    },
                    uploadProgress: function (event, position, total, percentComplete) {

                    },
                    success: function (response) {
                        toastr.success(response.message, ah_survey_scripts_object.success);
                        $this.loading = false;
                        $scope.$apply();
                    },
                    error: function (errors) {
                        if (errors.status == 400) {
                            toastr.error((errors && errors.responseJSON) ? errors.responseJSON.message : ah_survey_scripts_object.error, ah_survey_scripts_object.error + ' ' + errors.status);
                        }
                        $this.loading = false;
                        $scope.$apply();
                    }
                });
            }
        },
        testMailModal: {
            loading: false,
            errors_log: [],
            send: function ($event) {
                $event.preventDefault();
                const $this = this;
                var form = jQuery($event.currentTarget);
                this.loading = true;
                form.ajaxSubmit({
                    url: form.attr('action'),
                    data: form.serialize(),
                    dataType: 'json',
                    success: function (response) {
                        jQuery('#test_email_to, #test_email_subject, #test_email_message', form).val('');
                        jQuery('#sendTestEmailModal').modal('hide')
                        toastr.success(response.message, ah_survey_scripts_object.success);
                        $this.loading = false;
                        $scope.$apply();
                    },
                    error: function (errors) {
                        if (errors && errors.responseJSON) {
                            toastr.error((errors && errors.responseJSON) ? errors.responseJSON.message : ah_survey_scripts_object.error, ah_survey_scripts_object.error);
                        }
                        $this.loading = false;
                        $scope.$apply();
                    }
                });
            },
            show_errors_loading: false,
            show_errors: function ($event) {
                $event.preventDefault();
                const $this = this;
                var btn = jQuery($event.currentTarget);
                $this.show_errors_loading = true;
                jQuery.post(ah_survey_scripts_object.wp_ajax_url, {action: btn.data('action'), nonce: btn.data('nonce')}, function (response) {
                    $this.errors_log = response.message;
                    $this.show_errors_loading = false;
                    $scope.$apply();
                });
            },
            clear_log: function ($event) {
                $event.preventDefault();
                const $this = this;
                var btn = jQuery($event.currentTarget);
                Confirm.clear({
                    title: btn.data('title'),
                    content: btn.data('content')
                }, function () {
                    $this.show_errors_loading = true;
                    jQuery.post(ah_survey_scripts_object.wp_ajax_url, {action: btn.data('action'), nonce: btn.data('nonce')}, function (response) {
                        $this.errors_log = [];
                        $this.show_errors_loading = false;
                        jQuery('#emailErrorsLogModal').modal('hide');
                        toastr.success(response.message, ah_survey_scripts_object.success);
                        $scope.$apply();
                    });
                });
            }
        }
    };

});