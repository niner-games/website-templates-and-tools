/* block.js */

const {__} = wp.i18n
let el = wp.element.createElement;

wp.blocks.registerBlockType('ah-survey-gutenberg/survey-block', {

    title: 'AH Survey', // Block name visible to user

    icon: 'smiley', // Toolbar icon can be either using WP Dashicons or custom SVG

    category: 'common', // Under which category the block would appear

    attributes: { // The data this block will be storing

        survey_id: {type: 'string', default: ''}, // Notice box type for loading the appropriate CSS class. Default class is 'default'.

    },

    edit: function (props) {
        // How our block renders in the editor in edit mode
        let data = {
            action: 'list_surveys',
            nonce: ah_survey_scripts_object.list_surveys_nonce
        };
        let list_surveys = [];

        jQuery.post(ah_survey_scripts_object.wp_ajax_url, data).done(function (response) {
            list_surveys = response;
            console.log('response', response)
        });

        function updateSurveyID(event) {
            props.setAttributes({survey_id: event.target.value});
        }

        function updateOptions(elm) {
            let options = "<option> __ " + __('Select Survey') + " __ </option>";
            let $this = jQuery(elm);
            list_surveys.forEach((item) => {
                options += `<option  value="${item.id}">${item.title}</option>`
            });
            if ($this.find('select > option').length == 0)
                $this.find('select').html(options);

            setTimeout(function () {
                $this.find('select').change();
                $this.find('select').trigger('change');
            }, 200)

        }

        setTimeout(function () {
            jQuery('.ah-survey-block').each(function () {
                updateOptions(this);
            });
        }, 500);

        return el('div',
            {
                className: 'ah-survey-block',
            },
            el(
                'h3',
                {
                    class: 'ah-label-block',
                },
                __('AH Survey')
            ),
            el(
                'select',
                {
                    onChange: updateSurveyID,
                    value: props.attributes.survey_id,
                },
                // el("option", {value: "1"}, "Default"),
                // el("option", {value: "2"}, "Success"),
                // el("option", {value: "3"}, "Danger")
            ),
        ); // End return

    },  // End edit()

    save: function (props) {
        // How our block renders on the frontend
        return el('div',
            {
                className: 'ah-survey-block',
            },
            el(
                'h3',
                {
                    class: 'ah-label-block',
                },
                __('Survey')
            ),
            el(
                'div',
                {},
                '[ah-survey-widget id="' + props.attributes.survey_id + '"]',
            ),
        ); // End return
    }
});