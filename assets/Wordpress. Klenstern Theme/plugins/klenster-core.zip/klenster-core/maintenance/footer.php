<?php

/**

 * The template for coming soon footer

 *

 */

?>

		</div><!-- .klenster-content-wrapper -->

	</div><!-- #page -->

<?php wp_footer(); ?>

</body>

</html>