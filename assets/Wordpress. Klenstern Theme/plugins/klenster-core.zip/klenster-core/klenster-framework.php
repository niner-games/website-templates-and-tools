<?php
	
class KlensterFamework {
	
	public static $klenster_mod = '';
	
	function __construct(){
		$klenster_mod = get_option( 'klenster_theme_options_new');
		if( !empty( $klenster_mod ) ){
			self::$klenster_mod = $klenster_mod;
		}elseif( function_exists( 'klenster_default_theme_values' ) ){
			$input_val = klenster_default_theme_values();
			self::$klenster_mod = json_decode( $input_val, true );
		}
	}
	
	public static function klenster_static_theme_mod($field){
		$klenster_mod = self::$klenster_mod;
		return isset( $klenster_mod[$field] ) && $klenster_mod[$field] != '' ? $klenster_mod[$field] : '';
	}

}
$klenster_framework = new KlensterFamework();