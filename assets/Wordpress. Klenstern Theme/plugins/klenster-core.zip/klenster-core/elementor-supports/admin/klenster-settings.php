<?php 
add_action( 'admin_menu', 'klenster_admin_menu' );
function klenster_admin_menu() {
	add_submenu_page(
		'klenster',
		esc_html__( 'Elementor Settings', 'klenster' ),
		esc_html__( 'Elementor Settings', 'klenster' ),
		'administrator',
		'klenster-addons',
		'classic_elementor_addon_admin_page'
	);
}

function change_admin_menu_name(){
	global $submenu;
	if(isset($submenu['klenster-addons'])){
		$submenu['klenster-addons'][0][0] = esc_html__( 'Widgets Settings', 'klenster-core' );
	}
}
add_action( 'admin_menu', 'change_admin_menu_name');    

function classic_elementor_addon_admin_page(){
	?>
	<div class="klenster-admin-wrap">
		<h1><?php esc_html_e( 'Klenster Elementor Addons', 'klenster-core' ); ?></h1>
		<p class="pa-title-sub"><?php esc_html_e( 'Thank you for using Klenster Elementor Addons for Elementor. This plugin has been developed by ', 'klenster-core' ); ?><strong><?php echo esc_html( 'zozothemes' ); ?></strong></p>
		
		<?php
			$shortcode_stat = array(
				'animated-text' 	=> esc_html__( 'Animated Text', 'klenster-core' ),
				'circle-progress'	=> esc_html__( 'Circle Progress', 'klenster-core' ),
				'contact-form' 		=> esc_html__( 'Contact Form', 'klenster-core' ),
				'contact-info' 		=> esc_html__( 'Contact Info', 'klenster-core' ),
				'content-carousel' 	=> esc_html__( 'Content Carousel', 'klenster-core' ),
				'counter' 			=> esc_html__( 'Counter', 'klenster-core' ),
				'day-counter' 		=> esc_html__( 'Day Counter', 'klenster-core' ),
				'feature-box' 		=> esc_html__( 'Feature Box', 'klenster-core' ),
				'flip-box' 			=> esc_html__( 'Flip Box', 'klenster-core' ),
				'google-map' 		=> esc_html__( 'Google Map', 'klenster-core' ),
				'icon' 				=> esc_html__( 'Icon', 'klenster-core' ),
				'icon-list' 		=> esc_html__( 'Icon List', 'klenster-core' ),
				'image-grid' 		=> esc_html__( 'Image Grid', 'klenster-core' ),
				'modal-popup' 		=> esc_html__( 'Modal Popup', 'klenster-core' ),
				'pricing-table' 	=> esc_html__( 'Pricing Table', 'klenster-core' ),
				'section-title' 	=> esc_html__( 'Section Title', 'klenster-core' ),
				'social-links' 		=> esc_html__( 'Social Links', 'klenster-core' ),
				'timeline' 			=> esc_html__( 'Timeline', 'klenster-core' ),
				'timeline-slide' 	=> esc_html__( 'Timeline Slide', 'klenster-core' ),
				'chart' 			=> esc_html__( 'Chart', 'klenster-core' ),
				'recent-popular' 	=> esc_html__( 'Recent/Popular Post', 'klenster-core' ),
				'blog' 				=> esc_html__( 'Blog', 'klenster-core' ),
				'portfolio' 		=> esc_html__( 'Portfolio', 'klenster-core' ),
				'team' 				=> esc_html__( 'Team', 'klenster-core' ),
				'event' 			=> esc_html__( 'Event', 'klenster-core' ),
				'service' 			=> esc_html__( 'Service', 'klenster-core' ),
				'testimonial' 		=> esc_html__( 'Testimonial', 'klenster-core' ),
				'toggle-content' 	=> esc_html__( 'Toggle Content', 'klenster-core' ),
				'mailchimp' 		=> esc_html__( 'Mailchimp', 'klenster-core' ),
				'popup-anything' 	=> esc_html__( 'Popup Anything', 'klenster-core' ),
				'popover' 			=> esc_html__( 'Popover', 'klenster-core' ),
				'round-tab' 		=> esc_html__( 'Round Tab', 'klenster-core' )
			);
			
			if ( isset( $_POST['save_klenster_shortcodes_options'] ) && wp_verify_nonce( $_POST['save_klenster_shortcodes_options'], 'klenster_plugin_shortcodes_options' ) ) {
				update_option( 'klenster_shortcodes', $_POST['klenster_shortcodes'] );
			}
			$klenster_shortcodes = get_option('klenster_shortcodes');
			
		?>
		
		<div class="klenster-admin-content-wrap">
			<form method="post" action="#" enctype="multipart/form-data" id="klenster-plugin-form-wrapper">
				<?php wp_nonce_field( 'klenster_plugin_shortcodes_options', 'save_klenster_shortcodes_options' ); ?>
				<input class="klenster-plugin-submit button button-primary" type="submit" value="<?php echo esc_attr__( 'Save', 'klenster-core' ); ?>" />
				<div class="klenster-shortcodes-container">
			<?php
				$row = 1;
				foreach( $shortcode_stat as $key => $value ){
				
					$shortcode_name = str_replace( "-", "_", $key );
					if( !empty( $klenster_shortcodes ) ){
						if( isset( $klenster_shortcodes[$shortcode_name] ) ){
							$saved_val = 'on';
						}else{
							$saved_val = 'off';
						}
					}else{
						$saved_val = 'on';
					}
					$checked_stat = $saved_val == 'on' ? 'checked="checked"' : '';
				
					if( $row % 4 == 1 ) echo '<div class="klenster-row">';
					
						echo '
						<div class="klenster-col-3">
							<div class="element-group">
								<h4>'. esc_html( $value ) .'</h4>
								<label class="switch">
									<input class="switch-checkbox" type="checkbox" name="klenster_shortcodes['. esc_attr( $shortcode_name ) .']" '. $checked_stat .'>
									<span class="slider round"></span>
								</label>
							</div><!-- .element-group -->
						</div><!-- .klenster-col-2 -->';
									
					if( $row % 4 == 0 ) echo '</div><!-- .klenster-row -->';
					$row++;
				}
				
				if( $row % 4 != 1 ) echo '</div><!-- .klenster-row unexpceted close -->';
			?>
				</div> <!-- .klenster-shortcodes-container -->
			</form>
		</div><!-- .klenster-admin-content-wrap -->
		
		<div class="klenster-customizer-options-wrap">
			<h2><?php esc_html_e( 'Enable/Disable Customizer Auto Refresh Option', 'klenster-core' ); ?></h2>
			<?php 
				$customizer_auto_load = get_option( 'klenster_customizer_auto_load' );;
				$checked_stat = $customizer_auto_load == '1' ? 'checked="checked"' : '';
			?>
			<div class="klenster-customizer-option">
				<label class="switch">
					<input class="switch-checkbox" type="checkbox" <?php echo ''. $checked_stat ?>>
					<span class="slider round"></span>
				</label>
			</div>
			<p><?php esc_html_e( 'If you want to live editor experience, Just turn on this option. No need to auto load customizer editor for every option change means turn off this option.' ); ?></p>
		</div><!-- .klenster-customizer-options-wrap -->
		
	</div><!-- .klenster-admin-wrap -->
	<?php
}

add_action('wp_ajax_klenster-customizer-auto-load', 'klenster_customizer_auto_load_option');
function klenster_customizer_auto_load_option(){
	$nonce = $_POST['nonce'];
  
    if ( ! wp_verify_nonce( $nonce, 'klenster-customizer-#$%&*(' ) )
        die ( esc_html__( 'Busted!', 'klenster' ) );
	
	$auto_load = isset( $_POST['auto_load'] ) && $_POST['auto_load'] == '1' ? 1 : 0;
	update_option( 'klenster_customizer_auto_load', $auto_load );
	echo 'success';
	exit;
}