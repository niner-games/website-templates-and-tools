/*
 * Klenster Addons for Elementor Scripts
 * Description: Classic addons plugin have 20+ massive widgets for Elementor page builder.
 * Version: 1.0
 * Author: zozothemes
 */
 
(function( $ ) {
	
	"use strict";
	
	$( document ).ready(function() {
	
		/* Page Loader */
		
		
		
	}); // document ready end
		
	//Window Load
	$(window).on('load', function() { 
		
		
		
	}); // window load end
			
})( jQuery );

