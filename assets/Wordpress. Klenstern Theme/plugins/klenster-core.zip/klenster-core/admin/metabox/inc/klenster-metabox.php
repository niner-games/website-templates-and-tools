<?php
/* Klenster Page Options */
$prefix = 'klenster_post_';
$fields = array(
	array( 
		'label'	=> esc_html__( 'Post General Settings', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are single post general settings.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Post Layout', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose post layout for current post single view.', 'klenster-core' ), 
		'id'	=> $prefix.'layout',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'wide' => esc_html__( 'Wide', 'klenster-core' ),
			'boxed' => esc_html__( 'Boxed', 'klenster-core' )			
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Post Content Padding Option', 'klenster-core' ),
		'id'	=> $prefix.'content_padding_opt',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'		
	),
	array( 
		'label'	=> esc_html__( 'Post Content Padding', 'klenster-core' ), 
		'desc'	=> esc_html__( 'Set the top/right/bottom/left padding of post content.', 'klenster-core' ),
		'id'	=> $prefix.'content_padding',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'space',
		'required'	=> array( $prefix.'content_padding_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Post Template Option', 'klenster-core' ),
		'id'	=> $prefix.'template_opt',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'		
	),
	array( 
		'label'	=> esc_html__( 'Post Template', 'klenster-core' ),
		'id'	=> $prefix.'template',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'image_select',
		'options' => array(
			'no-sidebar'	=> get_theme_file_uri( '/assets/images/page-layouts/1.png' ), 
			'right-sidebar'	=> get_theme_file_uri( '/assets/images/page-layouts/2.png' ), 
			'left-sidebar'	=> get_theme_file_uri( '/assets/images/page-layouts/3.png' ), 
			'both-sidebar'	=> get_theme_file_uri( '/assets/images/page-layouts/4.png' ), 
		),
		'default'	=> 'right-sidebar',
		'required'	=> array( $prefix.'template_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Left Sidebar', 'klenster-core' ),
		'id'	=> $prefix.'left_sidebar',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'sidebar',
		'required'	=> array( $prefix.'template_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Right Sidebar', 'klenster-core' ),
		'id'	=> $prefix.'right_sidebar',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'sidebar',
		'required'	=> array( $prefix.'template_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Sidebar On Mobile', 'klenster-core' ),
		'id'	=> $prefix.'sidebar_mobile',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'1' => esc_html__( 'Show', 'klenster-core' ),
			'0' => esc_html__( 'Hide', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Featured Slider', 'klenster-core' ),
		'id'	=> $prefix.'featured_slider',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'1' => esc_html__( 'Enable', 'klenster-core' ),
			'0' => esc_html__( 'Disable', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Full Width Wrap', 'klenster-core' ),
		'id'	=> $prefix.'full_wrap',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'1' => esc_html__( 'Enable', 'klenster-core' ),
			'0' => esc_html__( 'Disable', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Post Items Option', 'klenster-core' ),
		'id'	=> $prefix.'items_opt',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'		
	),
	array( 
		'label'	=> esc_html__( 'Post Items', 'klenster-core' ),
		'desc'	=> esc_html__( 'Needed single post items drag from disabled and put enabled part.', 'klenster-core' ),
		'id'	=> $prefix.'items',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'dragdrop_multi',
		'dd_fields' => array ( 
			'Enabled'  => array(
				'title' 	=> esc_html__( 'Title', 'klenster-core' ),
				'top-meta'	=> esc_html__( 'Top Meta', 'klenster-core' ),
				'thumb' 	=> esc_html__( 'Thumbnail', 'klenster-core' ),
				'content' 	=> esc_html__( 'Content', 'klenster-core' ),
				'bottom-meta'		=> esc_html__( 'Bottom Meta', 'klenster-core' )
			),
			'disabled' => array()
		),
		'required'	=> array( $prefix.'items_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Post Overlay', 'klenster-core' ),
		'id'	=> $prefix.'overlay_opt',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'1' => esc_html__( 'Enable', 'klenster-core' ),
			'0' => esc_html__( 'Disable', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Post Overlay Items', 'klenster-core' ),
		'desc'	=> esc_html__( 'Needed overlay post items drag from disabled and put enabled part.', 'klenster-core' ),
		'id'	=> $prefix.'overlay_items',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'dragdrop_multi',
		'dd_fields' => array ( 
			'Enabled'  => array(
				'title' 	=> esc_html__( 'Title', 'klenster-core' )
			),
			'disabled' => array(
				'top-meta'	=> esc_html__( 'Top Meta', 'klenster-core' ),
				'bottom-meta'		=> esc_html__( 'Bottom Meta', 'klenster-core' )
			)
		),
		'required'	=> array( $prefix.'overlay_opt', '1' )
	),
	array( 
		'label'	=> esc_html__( 'Post Page Items Option', 'klenster-core' ),
		'id'	=> $prefix.'page_items_opt',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'		
	),
	array( 
		'label'	=> esc_html__( 'Post Page Items', 'klenster-core' ),
		'desc'	=> esc_html__( 'Needed post page items drag from disabled and put enabled part.', 'klenster-core' ),
		'id'	=> $prefix.'page_items',
		'tab'	=> esc_html__( 'General', 'klenster-core' ),
		'type'	=> 'dragdrop_multi',
		'dd_fields' => array ( 
			'Enabled'  => array(
				'post-items' 	=> esc_html__( 'Post Items', 'klenster-core' ),
				'author-info'	=> esc_html__( 'Author Info', 'klenster-core' ),
				'related-slider'=> esc_html__( 'Related Slider', 'klenster-core' ),
				'post-nav' 	=> esc_html__( 'Post Nav', 'klenster-core' ),
				'comment' 	=> esc_html__( 'Comment', 'klenster-core' )
			),
			'disabled' => array()
		),
		'default'	=> 'post-items,author-info,related-slider,post-nav,comment',
		'required'	=> array( $prefix.'page_items_opt', 'custom' )
	),
	//Header
	array( 
		'label'	=> esc_html__( 'Header General Settings', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header general settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Header Layout', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose post layout for current post header layout.', 'klenster-core' ), 
		'id'	=> $prefix.'header_layout',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'wide' => esc_html__( 'Wide', 'klenster-core' ),
			'boxed' => esc_html__( 'Boxed', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Type', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose post layout for current post header type.', 'klenster-core' ), 
		'id'	=> $prefix.'header_type',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'default' => esc_html__( 'Default', 'klenster-core' ),
			'left-sticky' => esc_html__( 'Left Sticky', 'klenster-core' ),
			'right-sticky' => esc_html__( 'Right Sticky', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Background Image', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header background image for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'image',
		'id'	=> $prefix.'header_bg_img',
		'required'	=> array( $prefix.'header_type', 'default' )
	),
	array( 
		'label'	=> esc_html__( 'Header Items Options', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header items options for enable header drag and drop items.', 'klenster-core' ), 
		'id'	=> $prefix.'header_items_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Items', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header general items for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dragdrop_multi',
		'id'	=> $prefix.'header_items',
		'dd_fields' => array ( 
			'Normal' => array( 
				'header-topbar' 	=> esc_html__( 'Topbar', 'klenster-core' ),
				'header-logo'	=> esc_html__( 'Logo Bar', 'klenster-core' )
			),
			'Sticky' => array( 
				'header-nav' 	=> esc_html__( 'Navbar', 'klenster-core' )
			),
			'disabled' => array()
		),
		'required'	=> array( $prefix.'header_items_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Absolute Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header absolute to change header look transparent.', 'klenster-core' ), 
		'id'	=> $prefix.'header_absolute_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'1' => esc_html__( 'Enable', 'klenster-core' ),
			'0' => esc_html__( 'Disable', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header sticky options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_sticky_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'sticky' => esc_html__( 'Header Sticky Part', 'klenster-core' ),
			'sticky-scroll' => esc_html__( 'Sticky Scroll Up', 'klenster-core' ),
			'none' => esc_html__( 'None', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header topbar settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Options', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header items options for enable header drag and drop items.', 'klenster-core' ), 
		'id'	=> $prefix.'header_topbar_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Height', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header topbar height for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dimension',
		'id'	=> $prefix.'header_topbar_height',
		'property' => 'height',
		'required'	=> array( $prefix.'header_topbar_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Sticky Height', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header topbar sticky height for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dimension',
		'id'	=> $prefix.'header_topbar_sticky_height',
		'property' => 'height',
		'required'	=> array( $prefix.'header_topbar_opt', 'custom' )
	),
	array( 
		'label'	=> '',
		'desc'	=> esc_html__( 'These all are header topbar skin settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Skin Settings', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header topbar skin settings options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_topbar_skin_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header topbar font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'header_topbar_font',
		'required'	=> array( $prefix.'header_topbar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Background', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header topbar background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'header_topbar_bg',
		'required'	=> array( $prefix.'header_topbar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header topbar link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'header_topbar_link',
		'required'	=> array( $prefix.'header_topbar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header topbar border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'header_topbar_border',
		'required'	=> array( $prefix.'header_topbar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header topbar padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'header_topbar_padding',
		'required'	=> array( $prefix.'header_topbar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Sticky Skin Settings', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header top bar sticky skin settings options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_topbar_sticky_skin_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Sticky Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header top bar sticky font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'header_topbar_sticky_font',
		'required'	=> array( $prefix.'header_topbar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Sticky Background', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header top bar sticky background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'header_topbar_sticky_bg',
		'required'	=> array( $prefix.'header_topbar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Sticky Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header top bar sticky link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'header_topbar_sticky_link',
		'required'	=> array( $prefix.'header_topbar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Sticky Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header top bar sticky border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'header_topbar_sticky_border',
		'required'	=> array( $prefix.'header_topbar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Sticky Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header top bar sticky padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'header_topbar_sticky_padding',
		'required'	=> array( $prefix.'header_topbar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Items Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header topbar items enable options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_topbar_items_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Top Bar Items', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header topbar items for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dragdrop_multi',
		'id'	=> $prefix.'header_topbar_items',
		'dd_fields' => array ( 
			'Left'  => array(
				'header-topbar-date' => esc_html__( 'Date', 'klenster-core' ),						
			),
			'Center' => array(),
			'Right' => array(),
			'disabled' => array(
				'header-topbar-text-1'	=> esc_html__( 'Custom Text 1', 'klenster-core' ),
				'header-topbar-text-2'	=> esc_html__( 'Custom Text 2', 'klenster-core' ),
				'header-topbar-text-3'	=> esc_html__( 'Custom Text 3', 'klenster-core' ),
				'header-topbar-menu'    => esc_html__( 'Top Bar Menu', 'klenster-core' ),
				'header-topbar-social'	=> esc_html__( 'Social', 'klenster-core' ),
				'header-topbar-search'	=> esc_html__( 'Search', 'klenster-core' )
			)
		),
		'required'	=> array( $prefix.'header_topbar_items_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Options', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header items options for enable header drag and drop items.', 'klenster-core' ), 
		'id'	=> $prefix.'header_logo_bar_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Height', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar height for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dimension',
		'id'	=> $prefix.'header_logo_bar_height',
		'property' => 'height',
		'required'	=> array( $prefix.'header_logo_bar_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Sticky Height', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar sticky height for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dimension',
		'id'	=> $prefix.'header_logo_bar_sticky_height',
		'property' => 'height',
		'required'	=> array( $prefix.'header_logo_bar_opt', 'custom' )
	),
	array( 
		'label'	=> '',
		'desc'	=> esc_html__( 'These all are header logo bar skin settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Skin Settings', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header logo bar skin settings options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_logo_bar_skin_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'header_logo_bar_font',
		'required'	=> array( $prefix.'header_logo_bar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Background', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'header_logo_bar_bg',
		'required'	=> array( $prefix.'header_logo_bar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'header_logo_bar_link',
		'required'	=> array( $prefix.'header_logo_bar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'header_logo_bar_border',
		'required'	=> array( $prefix.'header_logo_bar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'header_logo_bar_padding',
		'required'	=> array( $prefix.'header_logo_bar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Sticky Skin Settings', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header logo bar sticky skin settings options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_logobar_sticky_skin_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Sticky Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar sticky font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'header_logobar_sticky_font',
		'required'	=> array( $prefix.'header_logobar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Sticky Background', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar sticky background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'header_logobar_sticky_bg',
		'required'	=> array( $prefix.'header_logobar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Sticky Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar sticky link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'header_logobar_sticky_link',
		'required'	=> array( $prefix.'header_logobar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Sticky Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar sticky border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'header_logobar_sticky_border',
		'required'	=> array( $prefix.'header_logobar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Sticky Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar sticky padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'header_logobar_sticky_padding',
		'required'	=> array( $prefix.'header_logobar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Items Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header logo bar items enable options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_logo_bar_items_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Logo Bar Items', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header logo bar items for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dragdrop_multi',
		'id'	=> $prefix.'header_logo_bar_items',
		'dd_fields' => array ( 
			'Left'  => array(
				'header-logobar-logo'		=> esc_html__( 'Logo', 'klenster-core' ),
				'header-logobar-sticky-logo' => esc_html__( 'Sticky Logo', 'klenster-core' )											
			),
			'Center' => array(),
			'Right' => array(),
			'disabled' => array(
				'header-logobar-social'		=> esc_html__( 'Social', 'klenster-core' ),
				'header-logobar-search'		=> esc_html__( 'Search', 'klenster-core' ),
				'header-logobar-secondary-toggle'	=> esc_html__( 'Secondary Toggle', 'klenster-core' ),	
				'header-phone'   			=> esc_html__( 'Phone Number', 'klenster-core' ),
				'header-address'  			=> esc_html__( 'Address Text', 'klenster-core' ),
				'header-email'   			=> esc_html__( 'Email', 'klenster-core' ),
				'header-logobar-menu'   	=> esc_html__( 'Main Menu', 'klenster-core' ),
				'header-logobar-search-toggle'	=> esc_html__( 'Search Toggle', 'klenster-core' ),
				'header-logobar-text-1'		=> esc_html__( 'Custom Text 1', 'klenster-core' ),
				'header-logobar-text-2'		=> esc_html__( 'Custom Text 2', 'klenster-core' ),
				'header-logobar-text-3'		=> esc_html__( 'Custom Text 3', 'klenster-core' ),	
				'header-cart'   			=> esc_html__( 'Cart', 'klenster-core' ),
				'header-wishlist'   		=> esc_html__( 'Wishlist', 'klenster-core' ),
				'multi-info'   				=> esc_html__( 'Address, Phone, Email', 'klenster-core' )
			)
		),
		'required'	=> array( $prefix.'header_logo_bar_items_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Options', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header items options for enable header drag and drop items.', 'klenster-core' ), 
		'id'	=> $prefix.'header_navbar_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Height', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar height for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dimension',
		'id'	=> $prefix.'header_navbar_height',
		'property' => 'height',
		'required'	=> array( $prefix.'header_navbar_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Sticky Height', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar sticky height for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dimension',
		'id'	=> $prefix.'header_navbar_sticky_height',
		'property' => 'height',
		'required'	=> array( $prefix.'header_navbar_opt', 'custom' )
	),
	array( 
		'label'	=> '',
		'desc'	=> esc_html__( 'These all are header navbar skin settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Skin Settings', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header navbar skin settings options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_navbar_skin_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'header_navbar_font',
		'required'	=> array( $prefix.'header_navbar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Background', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'header_navbar_bg',
		'required'	=> array( $prefix.'header_navbar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'header_navbar_link',
		'required'	=> array( $prefix.'header_navbar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'header_navbar_border',
		'required'	=> array( $prefix.'header_navbar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'header_navbar_padding',
		'required'	=> array( $prefix.'header_navbar_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Sticky Skin Settings', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header navbar sticky skin settings options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_navbar_sticky_skin_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Sticky Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar sticky font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'header_navbar_sticky_font',
		'required'	=> array( $prefix.'header_navbar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Sticky Background', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar sticky background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'header_navbar_sticky_bg',
		'required'	=> array( $prefix.'header_navbar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Sticky Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar sticky link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'header_navbar_sticky_link',
		'required'	=> array( $prefix.'header_navbar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Sticky Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar sticky border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'header_navbar_sticky_border',
		'required'	=> array( $prefix.'header_navbar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Sticky Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar sticky padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'header_navbar_sticky_padding',
		'required'	=> array( $prefix.'header_navbar_sticky_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Items Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header navbar items enable options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_navbar_items_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Navbar Items', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header navbar items for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dragdrop_multi',
		'id'	=> $prefix.'header_navbar_items',
		'dd_fields' => array ( 
			'Left'  => array(											
				'header-navbar-menu'    => esc_html__( 'Main Menu', 'klenster-core' ),
			),
			'Center' => array(
			),
			'Right' => array(
				'header-navbar-search'	=> esc_html__( 'Search', 'klenster-core' ),
			),
			'disabled' => array(
				'header-navbar-text-1'	=> esc_html__( 'Custom Text 1', 'klenster-core' ),
				'header-navbar-text-2'	=> esc_html__( 'Custom Text 2', 'klenster-core' ),
				'header-navbar-text-3'	=> esc_html__( 'Custom Text 3', 'klenster-core' ),
				'header-navbar-logo'	=> esc_html__( 'Logo', 'klenster-core' ),
				'header-navbar-social'	=> esc_html__( 'Social', 'klenster-core' ),
				'header-navbar-secondary-toggle'	=> esc_html__( 'Secondary Toggle', 'klenster-core' ),
				'header-navbar-search-toggle'	=> esc_html__( 'Search Toggle', 'klenster-core' ),
				'header-navbar-sticky-logo'	=> esc_html__( 'Stikcy Logo', 'klenster-core' ),
				'header-cart'   		=> esc_html__( 'Cart', 'klenster-core' )
			)
		),
		'required'	=> array( $prefix.'header_navbar_items_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky/Fixed Part', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header sticky settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky/Fixed Part Options', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header sticky part option.', 'klenster-core' ), 
		'id'	=> $prefix.'header_stikcy_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky/Fixed Part Width', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header Sticky part width for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dimension',
		'id'	=> $prefix.'header_stikcy_width',
		'property' => 'width',
		'required'	=> array( $prefix.'header_stikcy_opt', 'custom' )
	),
	array( 
		'label'	=> '',
		'desc'	=> esc_html__( 'These all are header Sticky skin settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky/Fixed Part Skin Settings', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header Sticky skin settings options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_stikcy_skin_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky/Fixed Part Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header Sticky font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'header_stikcy_font',
		'required'	=> array( $prefix.'header_stikcy_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky/Fixed Part Background', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header Sticky background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'header_stikcy_bg',
		'required'	=> array( $prefix.'header_stikcy_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky/Fixed Part Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header Sticky link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'header_stikcy_link',
		'required'	=> array( $prefix.'header_stikcy_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky/Fixed Part Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header Sticky border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',

		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'header_stikcy_border',
		'required'	=> array( $prefix.'header_stikcy_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky/Fixed Part Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header Sticky padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'header_stikcy_padding',
		'required'	=> array( $prefix.'header_stikcy_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky/Fixed Part Items Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose header Sticky items enable options.', 'klenster-core' ), 
		'id'	=> $prefix.'header_stikcy_items_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Header Sticky/Fixed Part Items', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are header Sticky items for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dragdrop_multi',
		'id'	=> $prefix.'header_stikcy_items',
		'dd_fields' => array ( 
			'Top'  => array(
				'header-fixed-logo' => esc_html__( 'Logo', 'klenster-core' )
			),
			'Middle'  => array(
				'header-fixed-menu'	=> esc_html__( 'Menu', 'klenster-core' )					
			),
			'Bottom'  => array(
				'header-fixed-social'	=> esc_html__( 'Social', 'klenster-core' )					
			),
			'disabled' => array(
				'header-fixed-text-1'	=> esc_html__( 'Custom Text 1', 'klenster-core' ),
				'header-fixed-text-2'	=> esc_html__( 'Custom Text 2', 'klenster-core' ),				
				'header-fixed-search'	=> esc_html__( 'Search Form', 'klenster-core' )
			)
		),
		'required'	=> array( $prefix.'header_stikcy_items_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Bar', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are post title bar settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Post Title Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose post title enable or disable.', 'klenster-core' ), 
		'id'	=> $prefix.'header_post_title_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'1' => esc_html__( 'Enable', 'klenster-core' ),
			'0' => esc_html__( 'Disable', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Post Title Text', 'klenster-core' ),
		'desc'	=> esc_html__( 'If this post title is empty, then showing current post default title.', 'klenster-core' ), 
		'id'	=> $prefix.'header_post_title_text',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'text',
		'default'	=> '',
		'required'	=> array( $prefix.'header_post_title_opt', '1' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Description', 'klenster-core' ),
		'desc'	=> esc_html__( 'Enter post title description.', 'klenster-core' ), 
		'id'	=> $prefix.'header_post_title_desc',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'textarea',
		'default'	=> '',
		'required'	=> array( $prefix.'header_post_title_opt', '1' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Background Parallax', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose post title background parallax.', 'klenster-core' ), 
		'id'	=> $prefix.'header_post_title_parallax',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'1' => esc_html__( 'Enable', 'klenster-core' ),
			'0' => esc_html__( 'Disable', 'klenster-core' )
		),
		'default'	=> 'theme-default',
		'required'	=> array( $prefix.'header_post_title_opt', '1' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Background Video Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose post title background video option.', 'klenster-core' ), 
		'id'	=> $prefix.'header_post_title_video_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'1' => esc_html__( 'Enable', 'klenster-core' ),
			'0' => esc_html__( 'Disable', 'klenster-core' )
		),
		'default'	=> 'theme-default',
		'required'	=> array( $prefix.'header_post_title_opt', '1' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Background Video', 'klenster-core' ),
		'desc'	=> esc_html__( 'Enter youtube video ID. Example: ZSt9tm3RoUU.', 'klenster-core' ), 
		'id'	=> $prefix.'header_post_title_video',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'text',
		'default'	=> '',
		'required'	=> array( $prefix.'header_post_title_video_opt', '1' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Bar Items Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose post title bar items option.', 'klenster-core' ), 
		'id'	=> $prefix.'post_title_items_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default',
		'required'	=> array( $prefix.'header_post_title_opt', '1' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Bar Items', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are post title bar items for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'dragdrop_multi',
		'id'	=> $prefix.'post_title_items',
		'dd_fields' => array ( 
			'Left'  => array(
				'title' => esc_html__( 'Post Title Text', 'klenster-core' ),
			),
			'Center'  => array(
				
			),
			'Right'  => array(
				'breadcrumb'	=> esc_html__( 'Breadcrumb', 'klenster-core' )
			),
			'disabled' => array()
		),
		'required'	=> array( $prefix.'post_title_items_opt', 'custom' )
	),
	array( 
		'label'	=> '',
		'desc'	=> esc_html__( 'These all are post title skin settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'label',
		'required'	=> array( $prefix.'header_post_title_opt', '1' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Skin Settings', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose post title skin settings options.', 'klenster-core' ), 
		'id'	=> $prefix.'post_title_skin_opt',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default',
		'required'	=> array( $prefix.'header_post_title_opt', '1' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are post title font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'post_title_font',
		'required'	=> array( $prefix.'post_title_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Background Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are post title background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'post_title_bg',
		'required'	=> array( $prefix.'post_title_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Background Image', 'klenster-core' ),
		'desc'	=> esc_html__( 'Enter post title background image url.', 'klenster-core' ), 
		'id'	=> $prefix.'post_title_bg_img',
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'url',
		'default'	=> '',
		'required'	=> array( $prefix.'post_title_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are post title link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'post_title_link',
		'required'	=> array( $prefix.'post_title_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are post title border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'post_title_border',
		'required'	=> array( $prefix.'post_title_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are post title padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'post_title_padding',
		'required'	=> array( $prefix.'post_title_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Post Title Overlay', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are post title overlay color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Header', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'post_title_overlay',
		'required'	=> array( $prefix.'post_title_skin_opt', 'custom' )
	),
	//Footer
	array( 
		'label'	=> 'Footer General',
		'desc'	=> esc_html__( 'These all are header footer settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Footer Layout', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer layout for current post.', 'klenster-core' ), 
		'id'	=> $prefix.'footer_layout',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'wide' => esc_html__( 'Wide', 'klenster-core' ),
			'boxed' => esc_html__( 'Boxed', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Hidden Footer', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose hidden footer option.', 'klenster-core' ), 
		'id'	=> $prefix.'hidden_footer',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'1' => esc_html__( 'Enable', 'klenster-core' ),
			'0' => esc_html__( 'Disable', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> '',
		'desc'	=> esc_html__( 'These all are footer skin settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Footer Skin Settings', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer skin settings options.', 'klenster-core' ), 
		'id'	=> $prefix.'footer_skin_opt',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Footer Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'footer_font',
		'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Background Image', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer background image for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'image',
		'id'	=> $prefix.'footer_bg_img',
		'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Background Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'footer_bg',
		'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Background Overlay', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer background overlay color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'footer_bg_overlay',
		'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'footer_link',
		'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'space',
		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'footer_border',
		'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'footer_padding',
		'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Items Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer items enable options.', 'klenster-core' ), 
		'id'	=> $prefix.'footer_items_opt',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Footer Items', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer items for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'dragdrop_multi',
		'id'	=> $prefix.'footer_items',
		'dd_fields' => array ( 
			'Enabled'  => array(
				'footer-bottom'	=> esc_html__( 'Footer Bottom', 'klenster-core' )
			),
			'disabled' => array(
				'footer-top' => esc_html__( 'Footer Top', 'klenster-core' ),
				'footer-middle'	=> esc_html__( 'Footer Middle', 'klenster-core' )
			)
		),
		'required'	=> array( $prefix.'footer_items_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer Top',
		'desc'	=> esc_html__( 'These all are footer top settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Footer Top Skin', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer top skin options.', 'klenster-core' ), 
		'id'	=> $prefix.'footer_top_skin_opt',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Footer Top Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer top font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'footer_top_font',
		'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Top Widget Title color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer top widget title color.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'footer_top_widget_title_color',
		'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Top Background', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'footer_top_bg',
		'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Top Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer top link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'footer_top_link',
		'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Top Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer top border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'space',
		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'footer_top_border',
		'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Top Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer top padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'footer_top_padding',
		'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer Top Columns and Sidebars Settings',
		'desc'	=> esc_html__( 'These all are footer top columns and sidebar settings.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Footer Layout Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer layout option.', 'klenster-core' ), 
		'id'	=> $prefix.'footer_top_layout_opt',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Footer Layout', 'klenster-core' ),
		'id'	=> $prefix.'footer_top_layout',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'image_select',
		'options' => array(
			'3-3-3-3'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-1.png',
			'4-4-4'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-2.png',
			'3-6-3'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-3.png',
			'6-6'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-4.png',
			'9-3'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-5.png',
			'3-9'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-6.png',
			'4-2-2-2-2'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-8.png',
			'6-2-2-2'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-9.png',
			'12'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-7.png'
		),
		'default'	=> '4-4-4',
		'required'	=> array( $prefix.'footer_top_layout_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer First Column',
		'desc'	=> esc_html__( 'Select footer first column widget.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'id'	=> $prefix.'footer_top_sidebar_1',
		'type'	=> 'sidebar',
		'required'	=> array( $prefix.'footer_top_layout_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer Second Column',
		'desc'	=> esc_html__( 'Select footer second column widget.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'id'	=> $prefix.'footer_top_sidebar_2',
		'type'	=> 'sidebar',
		'required'	=> array( $prefix.'footer_top_layout_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer Third Column',
		'desc'	=> esc_html__( 'Select footer third column widget.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'id'	=> $prefix.'footer_top_sidebar_3',
		'type'	=> 'sidebar',
		'required'	=> array( $prefix.'footer_top_layout_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer Fourth Column',
		'desc'	=> esc_html__( 'Select footer fourth column widget.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'id'	=> $prefix.'footer_top_sidebar_4',
		'type'	=> 'sidebar',
		'required'	=> array( $prefix.'footer_top_layout_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer Middle',
		'desc'	=> esc_html__( 'These all are footer middle settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Footer Middle Skin', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer middle skin options.', 'klenster-core' ), 
		'id'	=> $prefix.'footer_middle_skin_opt',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Footer Middle Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer middle font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'footer_middle_font',
		'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Middle Widget Title Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer middle widget title color.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'footer_middle_widget_title_color',
		'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Middle Background', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'footer_middle_bg',
		'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Middle Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer middle link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'footer_middle_link',
		'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Middle Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer middle border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'space',
		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'footer_middle_border',
		'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Middle Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer middle padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'footer_middle_padding',
		'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer Middle Columns and Sidebars Settings',
		'desc'	=> esc_html__( 'These all are footer middle columns and sidebar settings.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Footer Layout Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer layout option.', 'klenster-core' ), 
		'id'	=> $prefix.'footer_middle_layout_opt',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Footer Layout', 'klenster-core' ),
		'id'	=> $prefix.'footer_middle_layout',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'image_select',
		'options' => array(
			'3-3-3-3'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-1.png',
			'4-4-4'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-2.png',
			'3-6-3'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-3.png',
			'6-6'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-4.png',
			'9-3'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-5.png',
			'3-9'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-6.png',
			'4-2-2-2-2'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-8.png',
			'6-2-2-2'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-9.png',
			'12'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-7.png'
		),
		'default'	=> '4-4-4',
		'required'	=> array( $prefix.'footer_middle_layout_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer First Column',
		'desc'	=> esc_html__( 'Select footer first column widget.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'id'	=> $prefix.'footer_middle_sidebar_1',
		'type'	=> 'sidebar',
		'required'	=> array( $prefix.'footer_middle_layout_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer Second Column',
		'desc'	=> esc_html__( 'Select footer second column widget.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'id'	=> $prefix.'footer_middle_sidebar_2',
		'type'	=> 'sidebar',
		'required'	=> array( $prefix.'footer_middle_layout_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer Third Column',
		'desc'	=> esc_html__( 'Select footer third column widget.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'id'	=> $prefix.'footer_middle_sidebar_3',
		'type'	=> 'sidebar',
		'required'	=> array( $prefix.'footer_middle_layout_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer Fourth Column',
		'desc'	=> esc_html__( 'Select footer fourth column widget.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'id'	=> $prefix.'footer_middle_sidebar_4',
		'type'	=> 'sidebar',
		'required'	=> array( $prefix.'footer_middle_layout_opt', 'custom' )
	),
	array( 
		'label'	=> 'Footer Bottom',
		'desc'	=> esc_html__( 'These all are footer bottom settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Footer Bottom Fixed', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer bottom fixed option.', 'klenster-core' ), 
		'id'	=> $prefix.'footer_bottom_fixed',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'1' => esc_html__( 'Enable', 'klenster-core' ),
			'0' => esc_html__( 'Disable', 'klenster-core' )			
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> '',
		'desc'	=> esc_html__( 'These all are footer bottom skin settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Footer Bottom Skin', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer bottom skin options.', 'klenster-core' ), 
		'id'	=> $prefix.'footer_bottom_skin_opt',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Footer Bottom Font Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer bottom font color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'color',
		'id'	=> $prefix.'footer_bottom_font',
		'required'	=> array( $prefix.'footer_bottom_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Bottom Background', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer bottom background color for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'alpha_color',
		'id'	=> $prefix.'footer_bottom_bg',
		'required'	=> array( $prefix.'footer_bottom_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Bottom Link Color', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer bottom link color settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'link_color',
		'id'	=> $prefix.'footer_bottom_link',
		'required'	=> array( $prefix.'footer_bottom_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Bottom Border', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer bottom border settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'space',
		'color' => 1,
		'border_style' => 1,
		'id'	=> $prefix.'footer_bottom_border',
		'required'	=> array( $prefix.'footer_bottom_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Bottom Padding', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer bottom padding settings for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'space',
		'id'	=> $prefix.'footer_bottom_padding',
		'required'	=> array( $prefix.'footer_bottom_skin_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Bottom Widget Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer bottom widget options.', 'klenster-core' ), 
		'id'	=> $prefix.'footer_bottom_widget_opt',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> 'Footer Bottom Widget',
		'desc'	=> esc_html__( 'Select footer bottom widget.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'id'	=> $prefix.'footer_bottom_widget',
		'type'	=> 'sidebar',
		'required'	=> array( $prefix.'footer_bottom_widget_opt', 'custom' )
	),
	array( 
		'label'	=> esc_html__( 'Footer Bottom Items Option', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose footer bottom items options.', 'klenster-core' ), 
		'id'	=> $prefix.'footer_bottom_items_opt',
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'custom' => esc_html__( 'Custom', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Footer Bottom Items', 'klenster-core' ),
		'desc'	=> esc_html__( 'These all are footer bottom items for current post.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
		'type'	=> 'dragdrop_multi',
		'id'	=> $prefix.'footer_bottom_items',
		'dd_fields' => array ( 
			'Left'  => array(
				'copyright' => esc_html__( 'Copyright Text', 'klenster-core' )
			),
			'Center'  => array(
				'menu'	=> esc_html__( 'Footer Menu', 'klenster-core' )
			),
			'Right'  => array(),
			'disabled' => array(
				'social'	=> esc_html__( 'Footer Social Links', 'klenster-core' ),
				'widget'	=> esc_html__( 'Custom Widget', 'klenster-core' )
			)
		),
		'required'	=> array( $prefix.'footer_bottom_items_opt', 'custom' )
	),
	//Header Slider
	array( 
		'label'	=> esc_html__( 'Slider', 'klenster-core' ),
		'desc'	=> esc_html__( 'This header slider settings.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Slider', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Slider Option', 'klenster-core' ),
		'id'	=> $prefix.'header_slider_opt',
		'tab'	=> esc_html__( 'Slider', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'bottom' => esc_html__( 'Below Header', 'klenster-core' ),
			'top' => esc_html__( 'Above Header', 'klenster-core' ),
			'none' => esc_html__( 'None', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Slider Shortcode', 'klenster-core' ),
		'desc'	=> esc_html__( 'This is the place for enter slider shortcode. Example revolution slider shortcodes.', 'klenster-core' ), 
		'id'	=> $prefix.'header_slider',
		'tab'	=> esc_html__( 'Slider', 'klenster-core' ),
		'type'	=> 'textarea',
		'default'	=> ''
	),
	//Post Format
	array( 
		'label'	=> esc_html__( 'Video', 'klenster-core' ),
		'desc'	=> esc_html__( 'This part for if you choosed video format, then you must choose video type and give video id.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Video Modal', 'klenster-core' ),
		'id'	=> $prefix.'video_modal',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'onclick' => esc_html__( 'On Click Run Video', 'klenster-core' ),
			'overlay' => esc_html__( 'Modal Box Video', 'klenster-core' ),
			'direct' => esc_html__( 'Direct Video', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Video Type', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose video type.', 'klenster-core' ), 
		'id'	=> $prefix.'video_type',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'' => esc_html__( 'None', 'klenster-core' ),
			'youtube' => esc_html__( 'Youtube', 'klenster-core' ),
			'vimeo' => esc_html__( 'Vimeo', 'klenster-core' ),
			'custom' => esc_html__( 'Custom Video', 'klenster-core' )
		),
		'default'	=> ''
	),
	array( 
		'label'	=> esc_html__( 'Video ID', 'klenster-core' ),
		'desc'	=> esc_html__( 'Enter Video ID Example: ZSt9tm3RoUU. If you choose custom video type then you enter custom video url and video must be mp4 format.', 'klenster-core' ), 
		'id'	=> $prefix.'video_id',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'text',
		'default'	=> ''
	),
	array( 
		'type'	=> 'line',
		'tab'	=> esc_html__( 'Format', 'klenster-core' )
	),
	array( 
		'label'	=> esc_html__( 'Audio', 'klenster-core' ),
		'desc'	=> esc_html__( 'This part for if you choosed audio format, then you must give audio id.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Audio Type', 'klenster-core' ),
		'desc'	=> esc_html__( 'Choose audio type.', 'klenster-core' ), 
		'id'	=> $prefix.'audio_type',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'' => esc_html__( 'None', 'klenster-core' ),
			'soundcloud' => esc_html__( 'Soundcloud', 'klenster-core' ),
			'custom' => esc_html__( 'Custom Audio', 'klenster-core' )
		),
		'default'	=> ''
	),
	array( 
		'label'	=> esc_html__( 'Audio ID', 'klenster-core' ),
		'desc'	=> esc_html__( 'Enter soundcloud audio ID. Example: 315307209.', 'klenster-core' ), 
		'id'	=> $prefix.'audio_id',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'text',
		'default'	=> ''
	),
	array( 
		'type'	=> 'line',
		'tab'	=> esc_html__( 'Format', 'klenster-core' )
	),
	array( 
		'label'	=> esc_html__( 'Gallery', 'klenster-core' ),
		'desc'	=> esc_html__( 'This part for if you choosed gallery format, then you must choose gallery images here.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Gallery Modal', 'klenster-core' ),
		'id'	=> $prefix.'gallery_modal',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'default' => esc_html__( 'Default Gallery', 'klenster-core' ),
			'popup' => esc_html__( 'Popup Gallery', 'klenster-core' ),
			'grid' => esc_html__( 'Grid Popup Gallery', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Choose Gallery Images', 'klenster-core' ),
		'id'	=> $prefix.'gallery',
		'type'	=> 'gallery',
		'tab'	=> esc_html__( 'Format', 'klenster-core' )
	),
	array( 
		'type'	=> 'line',
		'tab'	=> esc_html__( 'Format', 'klenster-core' )
	),
	array( 
		'label'	=> esc_html__( 'Quote', 'klenster-core' ),
		'desc'	=> esc_html__( 'This part for if you choosed quote format, then you must fill the quote text and author name box.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Quote Modal', 'klenster-core' ),
		'id'	=> $prefix.'quote_modal',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'featured' => esc_html__( 'Dark Overlay', 'klenster-core' ),
			'theme-overlay' => esc_html__( 'Theme Overlay', 'klenster-core' ),
			'theme' => esc_html__( 'Theme Color Background', 'klenster-core' ),
			'none' => esc_html__( 'None', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Quote Text', 'klenster-core' ),
		'desc'	=> esc_html__( 'Enter quote text.', 'klenster-core' ), 
		'id'	=> $prefix.'quote_text',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'textarea',
		'default'	=> ''
	),
	array( 
		'label'	=> esc_html__( 'Quote Author', 'klenster-core' ),
		'desc'	=> esc_html__( 'Enter quote author name.', 'klenster-core' ), 
		'id'	=> $prefix.'quote_author',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'text',
		'default'	=> ''
	),
	array( 
		'type'	=> 'line',
		'tab'	=> esc_html__( 'Format', 'klenster-core' )
	),
	array( 
		'label'	=> esc_html__( 'Link', 'klenster-core' ),
		'desc'	=> esc_html__( 'This part for if you choosed link format, then you must fill the external link box.', 'klenster-core' ), 
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'label'
	),
	array( 
		'label'	=> esc_html__( 'Link Modal', 'klenster-core' ),
		'id'	=> $prefix.'link_modal',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'select',
		'options' => array ( 
			'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
			'featured' => esc_html__( 'Dark Overlay', 'klenster-core' ),
			'theme-overlay' => esc_html__( 'Theme Overlay', 'klenster-core' ),
			'theme' => esc_html__( 'Theme Color Background', 'klenster-core' ),
			'none' => esc_html__( 'None', 'klenster-core' )
		),
		'default'	=> 'theme-default'
	),
	array( 
		'label'	=> esc_html__( 'Link Text', 'klenster-core' ),
		'desc'	=> esc_html__( 'Enter link text to show.', 'klenster-core' ), 
		'id'	=> $prefix.'link_text',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'text',
		'default'	=> ''
	),
	array( 
		'label'	=> esc_html__( 'External Link', 'klenster-core' ),
		'desc'	=> esc_html__( 'Enter external link.', 'klenster-core' ), 
		'id'	=> $prefix.'extrenal_link',
		'tab'	=> esc_html__( 'Format', 'klenster-core' ),
		'type'	=> 'url',
		'default'	=> ''
	),
	array( 
		'type'	=> 'line',
		'tab'	=> esc_html__( 'Format', 'klenster-core' )
	),
	
);
/**
 * Instantiate the class with all variables to create a meta box
 * var $id string meta box id
 * var $title string title
 * var $fields array fields
 * var $page string|array post type to add meta box to
 * var $js bool including javascript or not
 */
 
$post_box = new Custom_Add_Meta_Box( 'klenster_post_metabox', esc_html__( 'Klenster Post Options', 'klenster-core' ), $fields, 'post', true );

/* Klenster Page Options */
function klenster_metabox_fields( $prefix ){
	
	$klenster_menus = get_terms( 'nav_menu', array( 'hide_empty' => true ) );
	$klenster_nav_menus = array( "none" => esc_html__( "None", "klenster" ) );
	foreach( $klenster_menus as $menu ){
		$klenster_nav_menus[$menu->slug] = $menu->name;
	}
			
	$fields = array(
		array( 
			'label'	=> esc_html__( 'Page General Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are page general settings.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'General', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Page Layout', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose page layout for current post single view.', 'klenster-core' ), 
			'id'	=> $prefix.'layout',
			'tab'	=> esc_html__( 'General', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'wide' => esc_html__( 'Wide', 'klenster-core' ),
				'boxed' => esc_html__( 'Boxed', 'klenster-core' )			
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Page Content Padding Option', 'klenster-core' ),
			'id'	=> $prefix.'content_padding_opt',
			'tab'	=> esc_html__( 'General', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'		
		),
		array( 
			'label'	=> esc_html__( 'Page Content Padding', 'klenster-core' ), 
			'desc'	=> esc_html__( 'Set the top/right/bottom/left padding of page content.', 'klenster-core' ),
			'id'	=> $prefix.'content_padding',
			'tab'	=> esc_html__( 'General', 'klenster-core' ),
			'type'	=> 'space',
			'required'	=> array( $prefix.'content_padding_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Page Background Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose color setting for current page background.', 'klenster-core' ),
			'tab'	=> esc_html__( 'General', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'main_bg_color'
		),
		array( 
				'label'	=> esc_html__( 'Page Background Image', 'klenster-core' ),
				'desc'	=> esc_html__( 'Choose custom logo image for current page.', 'klenster-core' ), 
				'tab'	=> esc_html__( 'General', 'klenster-core' ),
				'type'	=> 'image',
				'id'	=> $prefix.'main_bg_image'
			),
		array( 
			'label'	=> esc_html__( 'Page Margin', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are margin settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'General', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'main_margin'
		),
		array( 
			'label'	=> esc_html__( 'Page Template Option', 'klenster-core' ),
			'id'	=> $prefix.'template_opt',
			'tab'	=> esc_html__( 'General', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'		
		),
		array( 
			'label'	=> esc_html__( 'Page Template', 'klenster-core' ),
			'id'	=> $prefix.'template',
			'tab'	=> esc_html__( 'General', 'klenster-core' ),
			'type'	=> 'image_select',
			'options' => array(
				'no-sidebar'	=> get_theme_file_uri( '/assets/images/page-layouts/1.png' ), 
				'right-sidebar'	=> get_theme_file_uri( '/assets/images/page-layouts/2.png' ), 
				'left-sidebar'	=> get_theme_file_uri( '/assets/images/page-layouts/3.png' ), 
				'both-sidebar'	=> get_theme_file_uri( '/assets/images/page-layouts/4.png' ), 
			),
			'default'	=> 'right-sidebar',
			'required'	=> array( $prefix.'template_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Left Sidebar', 'klenster-core' ),
			'id'	=> $prefix.'left_sidebar',
			'tab'	=> esc_html__( 'General', 'klenster-core' ),
			'type'	=> 'sidebar',
			'required'	=> array( $prefix.'template_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Right Sidebar', 'klenster-core' ),
			'id'	=> $prefix.'right_sidebar',
			'tab'	=> esc_html__( 'General', 'klenster-core' ),
			'type'	=> 'sidebar',
			'required'	=> array( $prefix.'template_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Sidebar On Mobile', 'klenster-core' ),
			'id'	=> $prefix.'sidebar_mobile',
			'tab'	=> esc_html__( 'General', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'1' => esc_html__( 'Show', 'klenster-core' ),
				'0' => esc_html__( 'Hide', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header General Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header general settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Header Extra Class', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter extra class name for additional class name for header.', 'klenster-core' ), 
			'id'	=> $prefix.'header_extra_class',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'One Page Menu Offset', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter one page menu offset for desktop menu.', 'klenster-core' ), 
			'id'	=> $prefix.'one_page_menu_offset',
			'tab'	=> esc_html__( 'One Page', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> '60'
		),
		array( 
			'label'	=> esc_html__( 'One Page Mobile Menu Offset', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter one page mobile menu offset for desktop menu.', 'klenster-core' ), 
			'id'	=> $prefix.'one_page_mobmenu_offset',
			'tab'	=> esc_html__( 'One Page', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> '60'
		),
		array( 
			'label'	=> esc_html__( 'Header Layout', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose page layout for current page header layout.', 'klenster-core' ), 
			'id'	=> $prefix.'header_layout',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'wide' => esc_html__( 'Wide', 'klenster-core' ),
				'boxed' => esc_html__( 'Boxed', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Type', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose page layout for current page header type.', 'klenster-core' ), 
			'id'	=> $prefix.'header_type',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'default' => esc_html__( 'Default', 'klenster-core' ),
				'left-sticky' => esc_html__( 'Left Sticky', 'klenster-core' ),
				'right-sticky' => esc_html__( 'Right Sticky', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Background Image', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header background image for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'image',
			'id'	=> $prefix.'header_bg_img',
			'required'	=> array( $prefix.'header_type', 'default' )
		),
		array( 
			'label'	=> esc_html__( 'Header Items Options', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header items options for enable header drag and drop items.', 'klenster-core' ), 
			'id'	=> $prefix.'header_items_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Items', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header general items for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dragdrop_multi',
			'id'	=> $prefix.'header_items',
			'dd_fields' => array ( 
				'Normal' => array( 
					'header-topbar' 	=> esc_html__( 'Topbar', 'klenster-core' ),
					'header-logo'	=> esc_html__( 'Logo Bar', 'klenster-core' )
				),
				'Sticky' => array( 
					'header-nav' 	=> esc_html__( 'Navbar', 'klenster-core' )
				),
				'disabled' => array()
			),
			'required'	=> array( $prefix.'header_items_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Absolute Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header absolute to change header look transparent.', 'klenster-core' ), 
			'id'	=> $prefix.'header_absolute_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'1' => esc_html__( 'Enable', 'klenster-core' ),
				'0' => esc_html__( 'Disable', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header sticky options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_sticky_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'sticky' => esc_html__( 'Header Sticky Part', 'klenster-core' ),
				'sticky-scroll' => esc_html__( 'Sticky Scroll Up', 'klenster-core' ),
				'none' => esc_html__( 'None', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Secondary Space Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose secondary space option for enable secondary menu space for current page.', 'klenster-core' ), 
			'id'	=> $prefix.'header_secondary_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'enable' => esc_html__( 'Enable', 'klenster-core' ),
				'disable' => esc_html__( 'Disable', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Secondary Space Animate Type', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose secondary space option animate type for current page.', 'klenster-core' ), 
			'id'	=> $prefix.'header_secondary_animate',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array(
				'left-push'		=> esc_html__( 'Left Push', 'klenster-core' ),
				'left-overlay'	=> esc_html__( 'Left Overlay', 'klenster-core' ),
				'right-push'	=> esc_html__( 'Right Push', 'klenster-core' ),
				'right-overlay'	=> esc_html__( 'Right Overlay', 'klenster-core' ),
				'full-overlay'	=> esc_html__( 'Full Page Overlay', 'klenster-core' ),
			),
			'default'	=> 'left-push',
			'required'	=> array( $prefix.'header_secondary_opt', 'enable' )
		),
		array( 
			'label'	=> esc_html__( 'Secondary Space Width', 'klenster-core' ),
			'desc'	=> esc_html__( 'Set secondary space width for current page. Example 300', 'klenster-core' ), 
			'id'	=> $prefix.'header_secondary_width',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> '',
			'required'	=> array( $prefix.'header_secondary_opt', 'enable' )
		),
		array( 
			'label'	=> esc_html__( 'Custom Logo', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose custom logo image for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'image',
			'id'	=> $prefix.'custom_logo',
		),
		array( 
			'label'	=> esc_html__( 'Custom Sticky Logo', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose custom sticky logo image for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'image',
			'id'	=> $prefix.'custom_sticky_logo',
		),
		array( 
			'label'	=> esc_html__( 'Select Navigation Menu', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose navigation menu for current page.', 'klenster-core' ), 
			'id'	=> $prefix.'nav_menu',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => $klenster_nav_menus
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header topbar settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Options', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header items options for enable header drag and drop items.', 'klenster-core' ), 
			'id'	=> $prefix.'header_topbar_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Height', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header topbar height for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dimension',
			'id'	=> $prefix.'header_topbar_height',
			'property' => 'height',
			'required'	=> array( $prefix.'header_topbar_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Sticky Height', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header topbar sticky height for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dimension',
			'id'	=> $prefix.'header_topbar_sticky_height',
			'property' => 'height',
			'required'	=> array( $prefix.'header_topbar_opt', 'custom' )
		),
		array( 
			'label'	=> '',
			'desc'	=> esc_html__( 'These all are header topbar skin settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Skin Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header topbar skin settings options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_topbar_skin_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header topbar font color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'header_topbar_font',
			'required'	=> array( $prefix.'header_topbar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Background', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header topbar background color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'header_topbar_bg',
			'required'	=> array( $prefix.'header_topbar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header topbar link color settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'header_topbar_link',
			'required'	=> array( $prefix.'header_topbar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header topbar border settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'header_topbar_border',
			'required'	=> array( $prefix.'header_topbar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header topbar padding settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'header_topbar_padding',
			'required'	=> array( $prefix.'header_topbar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Sticky Skin Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header top bar sticky skin settings options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_topbar_sticky_skin_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Sticky Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header top bar sticky font color for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'header_topbar_sticky_font',
			'required'	=> array( $prefix.'header_topbar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Sticky Background', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header top bar sticky background color for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'header_topbar_sticky_bg',
			'required'	=> array( $prefix.'header_topbar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Sticky Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header top bar sticky link color settings for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'header_topbar_sticky_link',
			'required'	=> array( $prefix.'header_topbar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Sticky Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header top bar sticky border settings for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'header_topbar_sticky_border',
			'required'	=> array( $prefix.'header_topbar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Sticky Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header top bar sticky padding settings for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'header_topbar_sticky_padding',
			'required'	=> array( $prefix.'header_topbar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Items Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header topbar items enable options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_topbar_items_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Top Bar Items', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header topbar items for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dragdrop_multi',
			'id'	=> $prefix.'header_topbar_items',
			'dd_fields' => array ( 
				'Left'  => array(
					'header-topbar-date' => esc_html__( 'Date', 'klenster-core' ),						
				),
				'Center' => array(),
				'Right' => array(),
				'disabled' => array(
					'header-topbar-text-1'	=> esc_html__( 'Custom Text 1', 'klenster-core' ),
					'header-topbar-text-2'	=> esc_html__( 'Custom Text 2', 'klenster-core' ),
					'header-topbar-text-3'	=> esc_html__( 'Custom Text 3', 'klenster-core' ),
					'header-topbar-menu'    => esc_html__( 'Top Bar Menu', 'klenster-core' ),
					'header-topbar-social'	=> esc_html__( 'Social', 'klenster-core' ),
					'header-topbar-search'	=> esc_html__( 'Search', 'klenster-core' ),
					'header-topbar-search-toggle'	=> esc_html__( 'Search Toggle', 'klenster-core' ),
					'header-cart'   		=> esc_html__( 'Cart', 'klenster-core' )
				)
			),
			'required'	=> array( $prefix.'header_topbar_items_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Options', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header items options for enable header drag and drop items.', 'klenster-core' ), 
			'id'	=> $prefix.'header_logo_bar_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Height', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar height for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dimension',
			'id'	=> $prefix.'header_logo_bar_height',
			'property' => 'height',
			'required'	=> array( $prefix.'header_logo_bar_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Sticky Height', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar sticky height for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dimension',
			'id'	=> $prefix.'header_logo_bar_sticky_height',
			'property' => 'height',
			'required'	=> array( $prefix.'header_logo_bar_opt', 'custom' )
		),
		array( 
			'label'	=> '',
			'desc'	=> esc_html__( 'These all are header logo bar skin settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Skin Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header logo bar skin settings options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_logo_bar_skin_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar font color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'header_logo_bar_font',
			'required'	=> array( $prefix.'header_logo_bar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Background', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar background color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'header_logo_bar_bg',
			'required'	=> array( $prefix.'header_logo_bar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar link color settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'header_logo_bar_link',
			'required'	=> array( $prefix.'header_logo_bar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar border settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'header_logo_bar_border',
			'required'	=> array( $prefix.'header_logo_bar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar padding settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'header_logo_bar_padding',
			'required'	=> array( $prefix.'header_logo_bar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Sticky Skin Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header logo bar sticky skin settings options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_logobar_sticky_skin_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Sticky Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar sticky font color for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'header_logobar_sticky_font',
			'required'	=> array( $prefix.'header_logobar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Sticky Background', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar sticky background color for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'header_logobar_sticky_bg',
			'required'	=> array( $prefix.'header_logobar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Sticky Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar sticky link color settings for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'header_logobar_sticky_link',
			'required'	=> array( $prefix.'header_logobar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Sticky Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar sticky border settings for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'header_logobar_sticky_border',
			'required'	=> array( $prefix.'header_logobar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Sticky Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar sticky padding settings for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'header_logobar_sticky_padding',
			'required'	=> array( $prefix.'header_logobar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Items Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header logo bar items enable options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_logo_bar_items_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Logo Bar Items', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header logo bar items for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dragdrop_multi',
			'id'	=> $prefix.'header_logo_bar_items',
			'dd_fields' => array ( 
				'Left'  => array(
					'header-logobar-logo'		=> esc_html__( 'Logo', 'klenster-core' ),
					'header-logobar-sticky-logo' => esc_html__( 'Sticky Logo', 'klenster-core' )											
				),
				'Center' => array(),
				'Right' => array(),
				'disabled' => array(
					'header-logobar-social'		=> esc_html__( 'Social', 'klenster-core' ),
					'header-logobar-search'		=> esc_html__( 'Search', 'klenster-core' ),
					'header-logobar-secondary-toggle'	=> esc_html__( 'Secondary Toggle', 'klenster-core' ),	
					'header-phone'   			=> esc_html__( 'Phone Number', 'klenster-core' ),
					'header-address'  			=> esc_html__( 'Address Text', 'klenster-core' ),
					'header-email'   			=> esc_html__( 'Email', 'klenster-core' ),
					'header-logobar-menu'   	=> esc_html__( 'Main Menu', 'klenster-core' ),
					'header-logobar-search-toggle'	=> esc_html__( 'Search Toggle', 'klenster-core' ),
					'header-logobar-text-1'		=> esc_html__( 'Custom Text 1', 'klenster-core' ),
					'header-logobar-text-2'		=> esc_html__( 'Custom Text 2', 'klenster-core' ),
					'header-logobar-text-3'		=> esc_html__( 'Custom Text 3', 'klenster-core' ),	
					'header-cart'   			=> esc_html__( 'Cart', 'klenster-core' ),
					'header-wishlist'   		=> esc_html__( 'Wishlist', 'klenster-core' ),
					'multi-info'   				=> esc_html__( 'Address, Phone, Email', 'klenster-core' )
				)
			),
			'required'	=> array( $prefix.'header_logo_bar_items_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Options', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header items options for enable header drag and drop items.', 'klenster-core' ), 
			'id'	=> $prefix.'header_navbar_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Height', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar height for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dimension',
			'id'	=> $prefix.'header_navbar_height',
			'property' => 'height',
			'required'	=> array( $prefix.'header_navbar_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Sticky Height', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar sticky height for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dimension',
			'id'	=> $prefix.'header_navbar_sticky_height',
			'property' => 'height',
			'required'	=> array( $prefix.'header_navbar_opt', 'custom' )
		),
		array( 
			'label'	=> '',
			'desc'	=> esc_html__( 'These all are header navbar skin settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Skin Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header navbar skin settings options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_navbar_skin_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar font color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'header_navbar_font',
			'required'	=> array( $prefix.'header_navbar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Background', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar background color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'header_navbar_bg',
			'required'	=> array( $prefix.'header_navbar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar link color settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'header_navbar_link',
			'required'	=> array( $prefix.'header_navbar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar border settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'header_navbar_border',
			'required'	=> array( $prefix.'header_navbar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar padding settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'header_navbar_padding',
			'required'	=> array( $prefix.'header_navbar_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Sticky Skin Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header navbar sticky skin settings options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_navbar_sticky_skin_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Sticky Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar sticky font color for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'header_navbar_sticky_font',
			'required'	=> array( $prefix.'header_navbar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Sticky Background', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar sticky background color for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'header_navbar_sticky_bg',
			'required'	=> array( $prefix.'header_navbar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Sticky Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar sticky link color settings for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'header_navbar_sticky_link',
			'required'	=> array( $prefix.'header_navbar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Sticky Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar sticky border settings for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'header_navbar_sticky_border',
			'required'	=> array( $prefix.'header_navbar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Sticky Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar sticky padding settings for current post.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'header_navbar_sticky_padding',
			'required'	=> array( $prefix.'header_navbar_sticky_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Items Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header navbar items enable options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_navbar_items_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Navbar Items', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header navbar items for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dragdrop_multi',
			'id'	=> $prefix.'header_navbar_items',
			'dd_fields' => array ( 
				'Left'  => array(
					'header-navbar-logo'		=> esc_html__( 'Logo', 'klenster' ),
					'header-navbar-sticky-logo'	=> esc_html__( 'Stikcy Logo', 'klenster' ),
					'header-navbar-menu'    	=> esc_html__( 'Main Menu', 'klenster' )										
				),
				'Center' => array(),
				'Right' => array(),
				'disabled' => array(					
					'header-navbar-text-1'		=> esc_html__( 'Custom Text 1', 'klenster' ),
					'header-navbar-text-2'		=> esc_html__( 'Custom Text 2', 'klenster' ),
					'header-navbar-text-3'		=> esc_html__( 'Custom Text 3', 'klenster' ),					
					'header-navbar-social'		=> esc_html__( 'Social', 'klenster' ),
					'header-navbar-secondary-toggle'	=> esc_html__( 'Secondary Toggle', 'klenster' ),					
					'header-navbar-search'		=> esc_html__( 'Search', 'klenster' ),
					'header-phone'   			=> esc_html__( 'Phone Number', 'klenster' ),
					'header-address'  			=> esc_html__( 'Address Text', 'klenster' ),
					'header-email'   			=> esc_html__( 'Email', 'klenster' ),
					'header-navbar-search-toggle'	=> esc_html__( 'Search Toggle', 'klenster' ),
					'header-cart'   			=> esc_html__( 'Cart', 'klenster' ),
					'header-wishlist'   		=> esc_html__( 'Wishlist', 'klenster' )
				)
			),
			'required'	=> array( $prefix.'header_navbar_items_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky/Fixed Part', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header sticky settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky/Fixed Part Options', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header sticky part option.', 'klenster-core' ), 
			'id'	=> $prefix.'header_stikcy_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky/Fixed Part Width', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header sticky part width for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dimension',
			'id'	=> $prefix.'header_stikcy_width',
			'property' => 'width',
			'required'	=> array( $prefix.'header_stikcy_opt', 'custom' )
		),
		array( 
			'label'	=> '',
			'desc'	=> esc_html__( 'These all are header sticky skin settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky/Fixed Part Skin Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header sticky skin settings options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_stikcy_skin_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky/Fixed Part Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header sticky font color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'header_stikcy_font',
			'required'	=> array( $prefix.'header_stikcy_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky/Fixed Part Background', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header sticky background color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'header_stikcy_bg',
			'required'	=> array( $prefix.'header_stikcy_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky/Fixed Part Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header Sticky link color settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'header_stikcy_link',
			'required'	=> array( $prefix.'header_stikcy_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky/Fixed Part Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header sticky border settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'header_stikcy_border',
			'required'	=> array( $prefix.'header_stikcy_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky/Fixed Part Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header sticky padding settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'header_stikcy_padding',
			'required'	=> array( $prefix.'header_stikcy_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky/Fixed Part Items Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose header sticky items enable options.', 'klenster-core' ), 
			'id'	=> $prefix.'header_stikcy_items_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Header Sticky/Fixed Part Items', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are header sticky items for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dragdrop_multi',
			'id'	=> $prefix.'header_stikcy_items',
			'dd_fields' => array ( 
				'Top'  => array(
					'header-fixed-logo' => esc_html__( 'Logo', 'klenster-core' )
				),
				'Middle'  => array(
					'header-fixed-menu'	=> esc_html__( 'Menu', 'klenster-core' )					
				),
				'Bottom'  => array(
					'header-fixed-social'	=> esc_html__( 'Social', 'klenster-core' )					
				),
				'disabled' => array(
					'header-fixed-text-1'	=> esc_html__( 'Custom Text 1', 'klenster-core' ),
					'header-fixed-text-2'	=> esc_html__( 'Custom Text 2', 'klenster-core' ),					
					'header-fixed-search'	=> esc_html__( 'Search Form', 'klenster-core' )
				)
			),
			'required'	=> array( $prefix.'header_stikcy_items_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Bar', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are page title bar settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Page Title Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose page title enable or disable.', 'klenster-core' ), 
			'id'	=> $prefix.'header_page_title_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'1' => esc_html__( 'Enable', 'klenster-core' ),
				'0' => esc_html__( 'Disable', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Page Title Text', 'klenster-core' ),
			'desc'	=> esc_html__( 'If this page title is empty, then showing current page default title.', 'klenster-core' ), 
			'id'	=> $prefix.'header_page_title_text',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> '',
			'required'	=> array( $prefix.'header_page_title_opt', '1' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Description', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter page title description.', 'klenster-core' ), 
			'id'	=> $prefix.'header_page_title_desc',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'textarea',
			'default'	=> '',
			'required'	=> array( $prefix.'header_page_title_opt', '1' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Background Parallax', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose page title background parallax.', 'klenster-core' ), 
			'id'	=> $prefix.'header_page_title_parallax',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'1' => esc_html__( 'Enable', 'klenster-core' ),
				'0' => esc_html__( 'Disable', 'klenster-core' )
			),
			'default'	=> 'theme-default',
			'required'	=> array( $prefix.'header_page_title_opt', '1' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Background Video Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose page title background video option.', 'klenster-core' ), 
			'id'	=> $prefix.'header_page_title_video_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'1' => esc_html__( 'Enable', 'klenster-core' ),
				'0' => esc_html__( 'Disable', 'klenster-core' )
			),
			'default'	=> 'theme-default',
			'required'	=> array( $prefix.'header_page_title_opt', '1' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Background Video', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter youtube video ID. Example: ZSt9tm3RoUU.', 'klenster-core' ), 
			'id'	=> $prefix.'header_page_title_video',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> '',
			'required'	=> array( $prefix.'header_page_title_video_opt', '1' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Bar Items Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose page title bar items option.', 'klenster-core' ), 
			'id'	=> $prefix.'page_title_items_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default',
			'required'	=> array( $prefix.'header_page_title_opt', '1' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Bar Items', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are page title bar items for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'dragdrop_multi',
			'id'	=> $prefix.'page_title_items',
			'dd_fields' => array ( 
				'Left'  => array(
					'title' => esc_html__( 'Page Title Text', 'klenster-core' ),
				),
				'Center'  => array(
					
				),
				'Right'  => array(
					'breadcrumb'	=> esc_html__( 'Breadcrumb', 'klenster-core' )
				),
				'disabled' => array(
					'description' => esc_html__( 'Page Title Description', 'klenster-core' )
				)
			),
			'required'	=> array( $prefix.'page_title_items_opt', 'custom' )
		),
		array( 
			'label'	=> '',
			'desc'	=> esc_html__( 'These all are page title skin settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'label',
			'required'	=> array( $prefix.'header_page_title_opt', '1' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Skin Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose page title skin settings options.', 'klenster-core' ), 
			'id'	=> $prefix.'page_title_skin_opt',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default',
			'required'	=> array( $prefix.'header_page_title_opt', '1' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are page title font color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'page_title_font',
			'required'	=> array( $prefix.'page_title_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Description Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'This is page title description color.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'page_title_desc_color',
			'required'	=> array( $prefix.'page_title_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Background', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are page title background color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'page_title_bg',
			'required'	=> array( $prefix.'page_title_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Background Image', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter page title background image url.', 'klenster-core' ), 
			'id'	=> $prefix.'page_title_bg_img',
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> '',
			'required'	=> array( $prefix.'page_title_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are page title link color settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'page_title_link',
			'required'	=> array( $prefix.'page_title_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are page title border settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'page_title_border',
			'required'	=> array( $prefix.'page_title_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are page title padding settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'page_title_padding',
			'required'	=> array( $prefix.'page_title_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Page Title Overlay', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are page title overlay color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Header', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'page_title_overlay',
			'required'	=> array( $prefix.'page_title_skin_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer General',
			'desc'	=> esc_html__( 'These all are header footer settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Footer Layout', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer layout for current page.', 'klenster-core' ), 
			'id'	=> $prefix.'footer_layout',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'wide' => esc_html__( 'Wide', 'klenster-core' ),
				'boxed' => esc_html__( 'Boxed', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Hidden Footer', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose hidden footer option.', 'klenster-core' ), 
			'id'	=> $prefix.'hidden_footer',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'1' => esc_html__( 'Enable', 'klenster-core' ),
				'0' => esc_html__( 'Disable', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> '',
			'desc'	=> esc_html__( 'These all are footer skin settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Footer Skin Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer skin settings options.', 'klenster-core' ), 
			'id'	=> $prefix.'footer_skin_opt',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Footer Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer font color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'footer_font',
			'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Background Image', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer background image for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'image',
			'id'	=> $prefix.'footer_bg_img',
			'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Background Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer background color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'footer_bg',
			'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Background Overlay', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer background overlay color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'footer_bg_overlay',
			'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer link color settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'footer_link',
			'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer border settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'footer_border',
			'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer padding settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'footer_padding',
			'required'	=> array( $prefix.'footer_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Items Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer items enable options.', 'klenster-core' ), 
			'id'	=> $prefix.'footer_items_opt',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Footer Items', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer items for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'dragdrop_multi',
			'id'	=> $prefix.'footer_items',
			'dd_fields' => array ( 
				'Enabled'  => array(
					'footer-bottom'	=> esc_html__( 'Footer Bottom', 'klenster-core' )
				),
				'disabled' => array(
					'footer-top' => esc_html__( 'Footer Top', 'klenster-core' ),
					'footer-middle'	=> esc_html__( 'Footer Middle', 'klenster-core' )
				)
			),
			'required'	=> array( $prefix.'footer_items_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer Top',
			'desc'	=> esc_html__( 'These all are footer top settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Footer Top Skin', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer top skin options.', 'klenster-core' ), 
			'id'	=> $prefix.'footer_top_skin_opt',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Footer Top Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer top font color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'footer_top_font',
			'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Top Widget Title color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer top widget title color.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'footer_top_widget_title_color',
			'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Top Background', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer background color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'footer_top_bg',
			'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Top Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer top link color settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'footer_top_link',
			'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Top Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer top border settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'footer_top_border',
			'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Top Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer top padding settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'footer_top_padding',
			'required'	=> array( $prefix.'footer_top_skin_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer Top Columns and Sidebars Settings',
			'desc'	=> esc_html__( 'These all are footer top columns and sidebar settings.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Footer Layout Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer layout option.', 'klenster-core' ), 
			'id'	=> $prefix.'footer_top_layout_opt',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Footer Layout', 'klenster-core' ),
			'id'	=> $prefix.'footer_top_layout',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'image_select',
			'options' => array(
				'3-3-3-3'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-1.png',
				'4-4-4'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-2.png',
				'3-6-3'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-3.png',
				'6-6'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-4.png',
				'9-3'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-5.png',
				'3-9'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-6.png',
				'4-2-2-2-2'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-8.png',
				'6-2-2-2'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-9.png',
				'12'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-7.png'
			),
			'default'	=> '4-4-4',
			'required'	=> array( $prefix.'footer_top_layout_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer First Column',
			'desc'	=> esc_html__( 'Select footer first column widget.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'id'	=> $prefix.'footer_top_sidebar_1',
			'type'	=> 'sidebar',
			'required'	=> array( $prefix.'footer_top_layout_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer Second Column',
			'desc'	=> esc_html__( 'Select footer second column widget.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'id'	=> $prefix.'footer_top_sidebar_2',
			'type'	=> 'sidebar',
			'required'	=> array( $prefix.'footer_top_layout_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer Third Column',
			'desc'	=> esc_html__( 'Select footer third column widget.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'id'	=> $prefix.'footer_top_sidebar_3',
			'type'	=> 'sidebar',
			'required'	=> array( $prefix.'footer_top_layout_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer Fourth Column',
			'desc'	=> esc_html__( 'Select footer fourth column widget.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'id'	=> $prefix.'footer_top_sidebar_4',
			'type'	=> 'sidebar',
			'required'	=> array( $prefix.'footer_top_layout_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer Middle',
			'desc'	=> esc_html__( 'These all are footer middle settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Footer Middle Skin', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer middle skin options.', 'klenster-core' ), 
			'id'	=> $prefix.'footer_middle_skin_opt',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Footer Middle Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer middle font color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'footer_middle_font',
			'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Middle Widget Title Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer middle widget title color.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'footer_middle_widget_title_color',
			'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Middle Background', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer background color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'footer_middle_bg',
			'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Middle Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer middle link color settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'footer_middle_link',
			'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Middle Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer middle border settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'footer_middle_border',
			'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Middle Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer middle padding settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'footer_middle_padding',
			'required'	=> array( $prefix.'footer_middle_skin_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer Middle Columns and Sidebars Settings',
			'desc'	=> esc_html__( 'These all are footer middle columns and sidebar settings.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Footer Layout Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer layout option.', 'klenster-core' ), 
			'id'	=> $prefix.'footer_middle_layout_opt',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Footer Layout', 'klenster-core' ),
			'id'	=> $prefix.'footer_middle_layout',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'image_select',
			'options' => array(
				'3-3-3-3'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-1.png',
				'4-4-4'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-2.png',
				'3-6-3'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-3.png',
				'6-6'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-4.png',
				'9-3'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-5.png',
				'3-9'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-6.png',
				'4-2-2-2-2'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-8.png',
				'6-2-2-2'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-9.png',
				'12'		=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/footer/footer-7.png'
			),
			'default'	=> '4-4-4',
			'required'	=> array( $prefix.'footer_middle_layout_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer First Column',
			'desc'	=> esc_html__( 'Select footer first column widget.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'id'	=> $prefix.'footer_middle_sidebar_1',
			'type'	=> 'sidebar',
			'required'	=> array( $prefix.'footer_middle_layout_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer Second Column',
			'desc'	=> esc_html__( 'Select footer second column widget.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'id'	=> $prefix.'footer_middle_sidebar_2',
			'type'	=> 'sidebar',
			'required'	=> array( $prefix.'footer_middle_layout_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer Third Column',
			'desc'	=> esc_html__( 'Select footer third column widget.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'id'	=> $prefix.'footer_middle_sidebar_3',
			'type'	=> 'sidebar',
			'required'	=> array( $prefix.'footer_middle_layout_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer Fourth Column',
			'desc'	=> esc_html__( 'Select footer fourth column widget.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'id'	=> $prefix.'footer_middle_sidebar_4',
			'type'	=> 'sidebar',
			'required'	=> array( $prefix.'footer_middle_layout_opt', 'custom' )
		),
		array( 
			'label'	=> 'Footer Bottom',
			'desc'	=> esc_html__( 'These all are footer bottom settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Footer Bottom Fixed', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer bottom fixed option.', 'klenster-core' ), 
			'id'	=> $prefix.'footer_bottom_fixed',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'1' => esc_html__( 'Enable', 'klenster-core' ),
				'0' => esc_html__( 'Disable', 'klenster-core' )			
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> '',
			'desc'	=> esc_html__( 'These all are footer bottom skin settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Footer Bottom Skin', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer bottom skin options.', 'klenster-core' ), 
			'id'	=> $prefix.'footer_bottom_skin_opt',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Footer Bottom Font Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer bottom font color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'color',
			'id'	=> $prefix.'footer_bottom_font',
			'required'	=> array( $prefix.'footer_bottom_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Bottom Background', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer bottom background color for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'alpha_color',
			'id'	=> $prefix.'footer_bottom_bg',
			'required'	=> array( $prefix.'footer_bottom_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Bottom Link Color', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer bottom link color settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'link_color',
			'id'	=> $prefix.'footer_bottom_link',
			'required'	=> array( $prefix.'footer_bottom_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Bottom Border', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer bottom border settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'space',
			'color' => 1,
			'border_style' => 1,
			'id'	=> $prefix.'footer_bottom_border',
			'required'	=> array( $prefix.'footer_bottom_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Bottom Padding', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer bottom padding settings for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'space',
			'id'	=> $prefix.'footer_bottom_padding',
			'required'	=> array( $prefix.'footer_bottom_skin_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Bottom Widget Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer bottom widget options.', 'klenster-core' ), 
			'id'	=> $prefix.'footer_bottom_widget_opt',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> 'Footer Bottom Widget',
			'desc'	=> esc_html__( 'Select footer bottom widget.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'id'	=> $prefix.'footer_bottom_widget',
			'type'	=> 'sidebar',
			'required'	=> array( $prefix.'footer_bottom_widget_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Footer Bottom Items Option', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose footer bottom items options.', 'klenster-core' ), 
			'id'	=> $prefix.'footer_bottom_items_opt',
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Footer Bottom Items', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are footer bottom items for current page.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Footer', 'klenster-core' ),
			'type'	=> 'dragdrop_multi',
			'id'	=> $prefix.'footer_bottom_items',
			'dd_fields' => array ( 
				'Left'  => array(
					'copyright' => esc_html__( 'Copyright Text', 'klenster-core' )
				),
				'Center'  => array(
					'menu'	=> esc_html__( 'Footer Menu', 'klenster-core' )
				),
				'Right'  => array(),
				'disabled' => array(
					'social'	=> esc_html__( 'Footer Social Links', 'klenster-core' ),
					'widget'	=> esc_html__( 'Custom Widget', 'klenster-core' )
				)
			),
			'required'	=> array( $prefix.'footer_bottom_items_opt', 'custom' )
		),
		//Header Slider
		array( 
			'label'	=> esc_html__( 'Slider', 'klenster-core' ),
			'desc'	=> esc_html__( 'This header slider settings.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Slider', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Slider Option', 'klenster-core' ),
			'id'	=> $prefix.'header_slider_opt',
			'tab'	=> esc_html__( 'Slider', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'bottom' => esc_html__( 'Below Header', 'klenster-core' ),
				'top' => esc_html__( 'Above Header', 'klenster-core' ),
				'none' => esc_html__( 'None', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Slider Shortcode', 'klenster-core' ),
			'desc'	=> esc_html__( 'This is the place for enter slider shortcode. Example revolution slider shortcodes.', 'klenster-core' ), 
			'id'	=> $prefix.'header_slider',
			'tab'	=> esc_html__( 'Slider', 'klenster-core' ),
			'type'	=> 'textarea',
			'default'	=> ''
		),
	);
	return $fields;
}
$page_fields = klenster_metabox_fields( 'klenster_page_' );
$page_box = new Custom_Add_Meta_Box( 'klenster_page_metabox', esc_html__( 'Klenster Page Options', 'klenster-core' ), $page_fields, 'page', true );

/* Custom Post Type Options */
$klenster_cpt = KlensterFamework::klenster_static_theme_mod( 'cpt-opts' );

// Portfolio Options
if( is_array( $klenster_cpt ) && in_array( "portfolio", $klenster_cpt ) ){
	
	// CPT Portfolio Metabox
	$prefix = 'klenster_portfolio_';
	$portfolio_fields = array(
		array( 
			'label'	=> esc_html__( 'Portfolio General Settings', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are single portfolio general settings.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Portfolio', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Portfolio Layout Option', 'klenster-core' ),
			'id'	=> $prefix.'layout_opt',
			'tab'	=> esc_html__( 'Portfolio', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'		
		),
		array( 
			'label'	=> esc_html__( 'Portfolio Layout', 'klenster-core' ),
			'id'	=> $prefix.'layout',
			'tab'	=> esc_html__( 'Portfolio', 'klenster-core' ),
			'type'	=> 'image_select',
			'options' => array(
				'1'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/portfolio-layouts/1.png', 
				'2'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/portfolio-layouts/2.png',
				'3'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/portfolio-layouts/3.png',
				'4'	=> KLENSTER_THEME_ADMIN_URL . '/customizer/assets/images/portfolio-layouts/4.png'
	
			),
			'default'	=> '1',
			'required'	=> array( $prefix.'layout_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Sticky Column', 'klenster-core' ),
			'id'	=> $prefix.'sticky',
			'tab'	=> esc_html__( 'Portfolio', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'none' => esc_html__( 'None', 'klenster-core' ),
				'right' => esc_html__( 'Right Column', 'klenster-core' ),
				'left' => esc_html__( 'Left Column', 'klenster-core' )
			),
			'default'	=> 'none'		
		),
		array( 
			'label'	=> esc_html__( 'Portfolio Format', 'klenster-core' ),
			'id'	=> $prefix.'format',
			'tab'	=> esc_html__( 'Portfolio', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'standard' => esc_html__( 'Standard', 'klenster-core' ),
				'video' => esc_html__( 'Video', 'klenster-core' ),
				'audio' => esc_html__( 'Audio', 'klenster-core' ),
				'gallery' => esc_html__( 'Gallery', 'klenster-core' ),
				'gmap' => esc_html__( 'Google Map', 'klenster-core' )
			),
			'default'	=> 'standard'		
		),
		array( 
			'label'	=> esc_html__( 'Portfolio Meta Items Options', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose portfolio meta items option.', 'klenster-core' ), 
			'id'	=> $prefix.'items_opt',
			'tab'	=> esc_html__( 'Portfolio', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'theme-default' => esc_html__( 'Theme Default', 'klenster-core' ),
				'custom' => esc_html__( 'Custom', 'klenster-core' )
			),
			'default'	=> 'theme-default'
		),
		array( 
			'label'	=> esc_html__( 'Portfolio Meta Items', 'klenster-core' ),
			'desc'	=> esc_html__( 'These all are meta items for portfolio. drag and drop needed items from disabled part to enabled.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Portfolio', 'klenster-core' ),
			'type'	=> 'dragdrop_multi',
			'id'	=> $prefix.'items',
			'dd_fields' => array ( 
				'Enabled'  => array(
					'date'		=> esc_html__( 'Date', 'klenster-core' ),
					'client'	=> esc_html__( 'Client', 'klenster-core' ),
					'category'	=> esc_html__( 'Category', 'klenster-core' ),
					'share'		=> esc_html__( 'Share', 'klenster-core' ),
				),
				'disabled' => array(
					'tag'		=> esc_html__( 'Tags', 'klenster-core' ),
					'duration'	=> esc_html__( 'Duration', 'klenster-core' ),
					'url'		=> esc_html__( 'URL', 'klenster-core' ),
					'place'		=> esc_html__( 'Place', 'klenster-core' ),
					'estimation'=> esc_html__( 'Estimation', 'klenster-core' ),
				)
			),
			'required'	=> array( $prefix.'items_opt', 'custom' )
		),
		array( 
			'label'	=> esc_html__( 'Custom Redirect URL', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter url for custom webpage redirection. This link only for portfolio archive layout not for single portfolio.', 'klenster-core' ), 
			'id'	=> $prefix.'custom_url',
			'tab'	=> esc_html__( 'Portfolio', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Custom Redirect URL Target', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose custom url page navigate to blank or same page.', 'klenster-core' ), 
			'id'	=> $prefix.'custom_url_target',
			'tab'	=> esc_html__( 'Portfolio', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'_blank' => esc_html__( 'Blank', 'klenster-core' ),
				'_self' => esc_html__( 'Self', 'klenster-core' )
			),
			'default'	=> '_blank'
		),
		array( 
			'label'	=> esc_html__( 'Portfolio Date', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose/Enter portfolio date.', 'klenster-core' ), 
			'id'	=> $prefix.'date',
			'tab'	=> esc_html__( 'Info', 'klenster-core' ),
			'type'	=> 'date',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Date Format', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter date format to show selcted portfolio date. Example: F j, Y', 'klenster-core' ), 
			'id'	=> $prefix.'date_format',
			'tab'	=> esc_html__( 'Info', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> 'F j, Y'
		),
		array( 
			'label'	=> esc_html__( 'Client Name', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter client name.', 'klenster-core' ), 
			'id'	=> $prefix.'client_name',
			'tab'	=> esc_html__( 'Info', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Duration', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter duration years or months.', 'klenster-core' ), 
			'id'	=> $prefix.'duration',
			'tab'	=> esc_html__( 'Info', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Estimation', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter project estimation.', 'klenster-core' ), 
			'id'	=> $prefix.'estimation',
			'tab'	=> esc_html__( 'Info', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Place', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter project place.', 'klenster-core' ), 
			'id'	=> $prefix.'place',
			'tab'	=> esc_html__( 'Info', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'URL', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter project URL.', 'klenster-core' ), 
			'id'	=> $prefix.'url',
			'tab'	=> esc_html__( 'Info', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		//Portfolio Format
		array( 
			'label'	=> esc_html__( 'Video', 'klenster-core' ),
			'desc'	=> esc_html__( 'This part for if you choosed video format, then you must choose video type and give video id.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Video Modal', 'klenster-core' ),
			'id'	=> $prefix.'video_modal',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'onclick' => esc_html__( 'On Click Run Video', 'klenster-core' ),
				'overlay' => esc_html__( 'Modal Box Video', 'klenster-core' ),
				'direct' => esc_html__( 'Direct Video', 'klenster-core' )
			),
			'default'	=> 'direct'
		),
		array( 
			'label'	=> esc_html__( 'Video Type', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose video type.', 'klenster-core' ), 
			'id'	=> $prefix.'video_type',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'' => esc_html__( 'None', 'klenster-core' ),
				'youtube' => esc_html__( 'Youtube', 'klenster-core' ),
				'vimeo' => esc_html__( 'Vimeo', 'klenster-core' ),
				'custom' => esc_html__( 'Custom Video', 'klenster-core' )
			),
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Video ID', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter Video ID Example: ZSt9tm3RoUU. If you choose custom video type then you enter custom video url and video must be mp4 format.', 'klenster-core' ), 
			'id'	=> $prefix.'video_id',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'type'	=> 'line',
			'tab'	=> esc_html__( 'Format', 'klenster-core' )
		),
		array( 
			'label'	=> esc_html__( 'Audio', 'klenster-core' ),
			'desc'	=> esc_html__( 'This part for if you choosed audio format, then you must give audio id.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Audio Type', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose audio type.', 'klenster-core' ), 
			'id'	=> $prefix.'audio_type',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'' => esc_html__( 'None', 'klenster-core' ),
				'soundcloud' => esc_html__( 'Soundcloud', 'klenster-core' ),
				'custom' => esc_html__( 'Custom Audio', 'klenster-core' )
			),
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Audio ID', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter soundcloud audio ID. Example: 315307209.', 'klenster-core' ), 
			'id'	=> $prefix.'audio_id',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'type'	=> 'line',
			'tab'	=> esc_html__( 'Format', 'klenster-core' )
		),
		array( 
			'label'	=> esc_html__( 'Gallery', 'klenster-core' ),
			'desc'	=> esc_html__( 'This part for if you choosed gallery format, then you must choose gallery images here.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Gallery Modal', 'klenster-core' ),
			'id'	=> $prefix.'gallery_modal',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'default' => esc_html__( 'Default Gallery', 'klenster-core' ),
				'normal' => esc_html__( 'Normal Gallery', 'klenster-core' ),
				'grid' => esc_html__( 'Grid/Masonry Gallery', 'klenster-core' )
			),
			'default'	=> 'default'
		),
		array( 
			'label'	=> esc_html__( 'Grid Gutter Size', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter gallery grid gutter size. Example 20', 'klenster-core' ), 
			'id'	=> $prefix.'grid_gutter',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> '',
			'required'	=> array( $prefix.'gallery_modal', 'grid' )
		),
		array( 
			'label'	=> esc_html__( 'Grid Columns', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter gallery grid columns count. Example 2', 'klenster-core' ), 
			'id'	=> $prefix.'grid_cols',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> '',
			'required'	=> array( $prefix.'gallery_modal', 'grid' )
		),
		array( 
			'label'	=> esc_html__( 'Choose Gallery Images', 'klenster-core' ),
			'id'	=> $prefix.'gallery',
			'type'	=> 'gallery',
			'tab'	=> esc_html__( 'Format', 'klenster-core' )
		),
		array( 
			'type'	=> 'line',
			'tab'	=> esc_html__( 'Format', 'klenster-core' )
		),
		array( 
			'label'	=> esc_html__( 'Google Map', 'klenster-core' ),
			'desc'	=> esc_html__( 'This part for if you choosed google map format, then you must give google map lat, lang and map style.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'label'
		),
		array( 
			'label'	=> esc_html__( 'Google Map Latitude', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter google latitude.', 'klenster-core' ), 
			'id'	=> $prefix.'gmap_latitude',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Google Map Longitude', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter google longitude.', 'klenster-core' ), 
			'id'	=> $prefix.'gmap_longitude',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Google Map Marker URL', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter google map custom marker url.', 'klenster-core' ), 
			'id'	=> $prefix.'gmap_marker',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Google Map Style', 'klenster-core' ),
			'id'	=> $prefix.'gmap_style',
			'tab'	=> esc_html__( 'Format', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'standard' => esc_html__( 'Standard', 'klenster-core' ),
				'silver' => esc_html__( 'Silver', 'klenster-core' ),
				'retro' => esc_html__( 'Retro', 'klenster-core' ),
				'dark' => esc_html__( 'Dark', 'klenster-core' ),
				'night' => esc_html__( 'Night', 'klenster-core' ),
				'aubergine' => esc_html__( 'Aubergine', 'klenster-core' )
			),
			'default'	=> 'standard'
		),
		array( 
			'type'	=> 'line',
			'tab'	=> esc_html__( 'Format', 'klenster-core' )
		),
	);
	// CPT Portfolio Options
	$portfolio_box = new Custom_Add_Meta_Box( 'klenster_portfolio_metabox', esc_html__( 'Klenster Portfolio Options', 'klenster-core' ), $portfolio_fields, 'klenster-portfolio', true );
	
	// CPT Portfolio Page Options
	$portfolio_page_box = new Custom_Add_Meta_Box( 'klenster_portfolio_page_metabox', esc_html__( 'Klenster Page Options', 'klenster-core' ), $page_fields, 'klenster-portfolio', true );
} // In theme option CPT option if portfolio exists
// Testimonial Options
if( is_array( $klenster_cpt ) && in_array( "testimonial", $klenster_cpt ) ){
	
	$prefix = 'klenster_testimonial_';
	$testimonial_fields = array(	
		array( 
			'label'	=> esc_html__( 'Author Designation', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter author designation.', 'klenster-core' ), 
			'id'	=> $prefix.'designation',
			'tab'	=> esc_html__( 'Testimonial', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Company Name', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter company name.', 'klenster-core' ), 
			'id'	=> $prefix.'company_name',
			'tab'	=> esc_html__( 'Testimonial', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Company URL', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter company URL.', 'klenster-core' ), 
			'id'	=> $prefix.'company_url',
			'tab'	=> esc_html__( 'Testimonial', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Rating', 'klenster-core' ),
			'desc'	=> esc_html__( 'Set user rating.', 'klenster-core' ), 
			'id'	=> $prefix.'rating',
			'tab'	=> esc_html__( 'Testimonial', 'klenster-core' ),
			'type'	=> 'rating',
			'default'	=> ''
		)
	);
	
	// CPT Testimonial Options
	$testimonial_box = new Custom_Add_Meta_Box( 'klenster_testimonial_metabox', esc_html__( 'Klenster Testimonial Options', 'klenster-core' ), $testimonial_fields, 'klenster-testimonial', true );
	
	// CPT Testimonial Page Options
	$testimonial_page_box = new Custom_Add_Meta_Box( 'klenster_testimonial_page_metabox', esc_html__( 'Klenster Page Options', 'klenster-core' ), $page_fields, 'klenster-testimonial', true );
	
} // In theme option CPT option if testimonial exists
// Team Options
if( is_array( $klenster_cpt ) && in_array( "team", $klenster_cpt ) ){
	
	$prefix = 'klenster_team_';
	$team_fields = array(	
		array( 
			'label'	=> esc_html__( 'Member Designation', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter member designation.', 'klenster-core' ), 
			'id'	=> $prefix.'designation',
			'tab'	=> esc_html__( 'Team', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Member Email', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter member email.', 'klenster-core' ), 
			'id'	=> $prefix.'email',
			'tab'	=> esc_html__( 'Team', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Link Target', 'klenster-core' ),
			'id'	=> $prefix.'link_target',
			'tab'	=> esc_html__( 'Social', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'_blank' => esc_html__( 'New Window', 'klenster-core' ),
				'_self' => esc_html__( 'Self Window', 'klenster-core' )
			),
			'default'	=> '_blank'
		),
		array( 
			'label'	=> esc_html__( 'Facebook', 'klenster-core' ),
			'desc'	=> esc_html__( 'Facebook profile link.', 'klenster-core' ), 
			'id'	=> $prefix.'facebook',
			'tab'	=> esc_html__( 'Social', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Twitter', 'klenster-core' ),
			'desc'	=> esc_html__( 'Twitter profile link.', 'klenster-core' ), 
			'id'	=> $prefix.'twitter',
			'tab'	=> esc_html__( 'Social', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Instagram', 'klenster-core' ),
			'desc'	=> esc_html__( 'Instagram profile link.', 'klenster-core' ), 
			'id'	=> $prefix.'instagram',
			'tab'	=> esc_html__( 'Social', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Linkedin', 'klenster-core' ),
			'desc'	=> esc_html__( 'Linkedin profile link.', 'klenster-core' ), 
			'id'	=> $prefix.'linkedin',
			'tab'	=> esc_html__( 'Social', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Pinterest', 'klenster-core' ),
			'desc'	=> esc_html__( 'Pinterest profile link.', 'klenster-core' ), 
			'id'	=> $prefix.'pinterest',
			'tab'	=> esc_html__( 'Social', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Dribbble', 'klenster-core' ),
			'desc'	=> esc_html__( 'Dribbble profile link.', 'klenster-core' ), 
			'id'	=> $prefix.'dribbble',
			'tab'	=> esc_html__( 'Social', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Flickr', 'klenster-core' ),
			'desc'	=> esc_html__( 'Flickr profile link.', 'klenster-core' ), 
			'id'	=> $prefix.'flickr',
			'tab'	=> esc_html__( 'Social', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Youtube', 'klenster-core' ),
			'desc'	=> esc_html__( 'Youtube profile link.', 'klenster-core' ), 
			'id'	=> $prefix.'youtube',
			'tab'	=> esc_html__( 'Social', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Vimeo', 'klenster-core' ),
			'desc'	=> esc_html__( 'Vimeo profile link.', 'klenster-core' ), 
			'id'	=> $prefix.'vimeo',
			'tab'	=> esc_html__( 'Social', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		)
	);
	
	// CPT Team Options
	$team_box = new Custom_Add_Meta_Box( 'klenster_team_metabox', esc_html__( 'Klenster Team Options', 'klenster-core' ), $team_fields, 'klenster-team', true );
	
	// CPT Team Page Options
	$team_page_box = new Custom_Add_Meta_Box( 'klenster_team_page_metabox', esc_html__( 'Klenster Page Options', 'klenster-core' ), $page_fields, 'klenster-team', true );
	
} // In theme option CPT option if team exists
// Event Options
if( is_array( $klenster_cpt ) && in_array( "events", $klenster_cpt ) ){
	
	$prefix = 'klenster_event_';
	$event_fields = array(	
		array( 
			'label'	=> esc_html__( 'Event Organiser Name', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter event organiser name.', 'klenster-core' ), 
			'id'	=> $prefix.'organiser_name',
			'tab'	=> esc_html__( 'Events', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Event Organiser Designation', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter event organiser designation.', 'klenster-core' ), 
			'id'	=> $prefix.'organiser_designation',
			'tab'	=> esc_html__( 'Events', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Event Start Date', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter event start date.', 'klenster-core' ), 
			'id'	=> $prefix.'start_date',
			'tab'	=> esc_html__( 'Events', 'klenster-core' ),
			'type'	=> 'date',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Event End Date', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter event end date.', 'klenster-core' ), 
			'id'	=> $prefix.'end_date',
			'tab'	=> esc_html__( 'Events', 'klenster-core' ),
			'type'	=> 'date',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Date Format', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter date format to show selcted event date. Example: F j, Y', 'klenster-core' ), 
			'id'	=> $prefix.'date_format',
			'tab'	=> esc_html__( 'Events', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> 'F j, Y'
		),
		array( 
			'label'	=> esc_html__( 'Event Start Time', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter event start time.', 'klenster-core' ), 
			'id'	=> $prefix.'time',
			'tab'	=> esc_html__( 'Events', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Event Cost', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter event cost.', 'klenster-core' ), 
			'id'	=> $prefix.'cost',
			'tab'	=> esc_html__( 'Events', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Custom Link for Event Item', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter custom link to redirect custom event page.', 'klenster-core' ), 
			'id'	=> $prefix.'link',
			'tab'	=> esc_html__( 'Events', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Custom Link Target', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose custom link target to new window or self window.', 'klenster-core' ), 
			'id'	=> $prefix.'link_target',
			'tab'	=> esc_html__( 'Events', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'_blank' => esc_html__( 'New Window', 'klenster-core' ),
				'_self' => esc_html__( 'Self Window', 'klenster-core' )
			),
			'default'	=> '_blank'
		),
		array( 
			'label'	=> esc_html__( 'Custom Link Button Text', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter custom link buttom text: Example More About Event.', 'klenster-core' ), 
			'id'	=> $prefix.'link_text',
			'tab'	=> esc_html__( 'Events', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Event Schedule Content', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter event schedule content. You can place here Shortcodes.', 'klenster-core' ), 
			'id'	=> $prefix.'schedule_content',
			'tab'	=> esc_html__( 'Events', 'klenster-core' ),
			'type'	=> 'textarea',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Venue Name', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter event venue name.', 'klenster-core' ), 
			'id'	=> $prefix.'venue_name',
			'tab'	=> esc_html__( 'Address', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Venue Address', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter event venue address.', 'klenster-core' ), 
			'id'	=> $prefix.'venue_address',
			'tab'	=> esc_html__( 'Address', 'klenster-core' ),
			'type'	=> 'textarea',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'E-mail', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter email id for clarification about event.', 'klenster-core' ), 
			'id'	=> $prefix.'email',
			'tab'	=> esc_html__( 'Address', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Phone', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter phone number for contact about event.', 'klenster-core' ), 
			'id'	=> $prefix.'phone',
			'tab'	=> esc_html__( 'Address', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Website', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter event website.', 'klenster-core' ), 
			'id'	=> $prefix.'website',
			'tab'	=> esc_html__( 'Address', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Latitude', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter map latitude.', 'klenster-core' ), 
			'id'	=> $prefix.'gmap_latitude',
			'tab'	=> esc_html__( 'GMap', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Longitude', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter map longitude.', 'klenster-core' ), 
			'id'	=> $prefix.'gmap_longitude',
			'tab'	=> esc_html__( 'GMap', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Google Map Marker URL', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter google map custom marker url.', 'klenster-core' ), 
			'id'	=> $prefix.'gmap_marker',
			'tab'	=> esc_html__( 'GMap', 'klenster-core' ),
			'type'	=> 'url',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Google Map Style', 'klenster-core' ),
			'id'	=> $prefix.'gmap_style',
			'tab'	=> esc_html__( 'GMap', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'standard' => esc_html__( 'Standard', 'klenster-core' ),
				'silver' => esc_html__( 'Silver', 'klenster-core' ),
				'retro' => esc_html__( 'Retro', 'klenster-core' ),
				'dark' => esc_html__( 'Dark', 'klenster-core' ),
				'night' => esc_html__( 'Night', 'klenster-core' ),
				'aubergine' => esc_html__( 'Aubergine', 'klenster-core' )
			),
			'default'	=> 'standard'
		),
		array( 
			'label'	=> esc_html__( 'Google Map Height', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter map height in values. Example 400', 'klenster-core' ), 
			'id'	=> $prefix.'gmap_height',
			'tab'	=> esc_html__( 'GMap', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> '400'
		),
		array( 
			'label'	=> esc_html__( 'Contact Form', 'klenster-core' ),
			'desc'	=> esc_html__( 'Contact form shortcode here.', 'klenster-core' ), 
			'id'	=> $prefix.'contact_form',
			'tab'	=> esc_html__( 'Contact', 'klenster-core' ),
			'type'	=> 'textarea',
			'default'	=> ''
		),
		array( 
			'label'	=> esc_html__( 'Event Info Columns', 'klenster-core' ),
			'desc'	=> esc_html__( 'Enter column division values like given format. Example 3-3-6', 'klenster-core' ), 
			'id'	=> $prefix.'col_layout',
			'tab'	=> esc_html__( 'Layout', 'klenster-core' ),
			'type'	=> 'text',
			'default'	=> '3-3-6'
		),
		array( 
			'label'	=> esc_html__( 'Event Detail Items', 'klenster-core' ),
			'desc'	=> esc_html__( 'This is layout settings for event.', 'klenster-core' ), 
			'tab'	=> esc_html__( 'Layout', 'klenster-core' ),
			'type'	=> 'dragdrop_multi',
			'id'	=> $prefix.'event_info_items',
			'dd_fields' => array ( 
				'Enable'  => array(
					'event-details' => esc_html__( 'Event Details', 'klenster-core' ),
					'event-venue' => esc_html__( 'Event Venue', 'klenster-core' ),
					'event-map' => esc_html__( 'Event Map', 'klenster-core' )
				),
				'disabled' => array(
					'event-form'	=> esc_html__( 'Event Form', 'klenster-core' ),
				)
			),
		),
		array( 
			'label'	=> esc_html__( 'Navigation', 'klenster-core' ),
			'id'	=> $prefix.'nav_position',
			'tab'	=> esc_html__( 'Layout', 'klenster-core' ),
			'type'	=> 'select',
			'options' => array ( 
				'top' => esc_html__( 'Top', 'klenster-core' ),
				'bottom' => esc_html__( 'Bottom', 'klenster-core' )
			),
			'default'	=> 'top'
		),
	);
	
	// CPT Events Options
	$event_box = new Custom_Add_Meta_Box( 'klenster_event_metabox', esc_html__( 'Klenster Event Options', 'klenster-core' ), $event_fields, 'klenster-events', true );
	
	// CPT Events Page Options
	$event_page_box = new Custom_Add_Meta_Box( 'klenster_event_page_metabox', esc_html__( 'Klenster Page Options', 'klenster-core' ), $page_fields, 'klenster-events', true );
	
} // In theme option CPT option if event exists
// Service Options
if( is_array( $klenster_cpt ) && in_array( "services", $klenster_cpt ) ){
	
	$prefix = 'klenster_service_';
	
	$service_fields = array(	
		array( 
			'label'	=> esc_html__( 'Service Image', 'klenster-core' ),
			'desc'	=> esc_html__( 'Choose service image for show front.', 'klenster-core' ), 
			'id'	=> $prefix.'title_img',
			'tab'	=> esc_html__( 'Service', 'klenster-core' ),
			'type'	=> 'image',
			'default'	=> ''
		)
	);
	
	// CPT Service Options
	$service_box = new Custom_Add_Meta_Box( 'klenster_service_metabox', esc_html__( 'Klenster Service Options', 'klenster-core' ), $service_fields, 'klenster-services', true );
	
	// CPT Events Page Options
	$service_page_box = new Custom_Add_Meta_Box( 'klenster_service_page_metabox', esc_html__( 'Klenster Page Options', 'klenster-core' ), $page_fields, 'klenster-services', true );
	
}