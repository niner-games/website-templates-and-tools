<?php
/**
 * The template for displaying the footer
 *
 */
$afe = new KlensterFooterElements;
$footer_template = KlensterThemeOpt::klenster_static_theme_mod( 'footer-template' );

$footer_class = $afe->klenster_footer_layout();
$footer_class .= $footer_template ? ' footer-template-'. $footer_template : '';
?>
	</div><!-- .klenster-content-wrapper -->
	<footer class="site-footer<?php echo esc_attr( $footer_class ); ?>">

		<?php $afe->klenster_footer_elements(); ?>
		
		<?php $afe->klenster_footer_backto_top(); ?>
	</footer><!-- #colophon -->
</div><!-- #page -->
<?php
	/*
	 * Full Search - klenster_full_search_wrap - 10
	 */
	echo apply_filters( 'klenster_footer_filters', '' );
	
	/*
	 * Google Fonts - klensterGoogleFontsCon - 10
	 */
	echo do_action( 'klenster_footer_actions' );
?>

<?php 
	do_action( 'klenster_body_end_action' );
?>

<?php wp_footer(); ?>
</body>
</html>