<?php
/**
 * The template for displaying 404 pages (not found)
 *
 */
get_header();

$ahe = new KlensterHeaderElements;
$aps = new KlensterPostSettings;
$template = 'page'; // template id
$aps->klenster_set_post_template( $template );
$template_class = $aps->klenster_template_content_class();
?>
<div class="wrap">
	<div id="primary" class="content-area error-404-area klenster-page">
		<main id="main" class="site-main">
		
			<?php $ahe->klenster_page_title( $template ); ?>
		
			<section class="error-404 not-found text-center">
				<div class="container">
					<header class="page-header">
						
						<div class="image-wrap-404">
							<img src="<?php echo esc_url( KLENSTER_ASSETS . '/images/404.png' ); ?>" alt="image-404">
							
						</div>	
						
						<div class="relative mb-2">
							<h3 class="page-title"><?php esc_html_e( 'Page Not Found', 'klenster' ); ?></h3>
						</div>
						<?php 
							$home_url = home_url( '/' ); 
						?>
							<p class="error-description">
								<?php esc_html_e( 'Sorry we cannot find that page!', 'klenster' ); ?>
								<?php esc_html_e( 'Go back to home', 'klenster' ); ?>
							</p>							
							<a class="home-link" href="<?php echo esc_url( $home_url ); ?>">
								<?php esc_html_e( 'Home Page', 'klenster' ); ?>
							</a>
					</header><!-- .page-header -->
				</div><!-- .container -->
			</section><!-- .error-404 -->
		</main><!-- #main -->
	</div><!-- #primary -->
</div><!-- .wrap -->
<?php get_footer();