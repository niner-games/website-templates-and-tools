<?php
/**
 * The template for displaying all custom post types
 */
 
get_header(); 
$ahe = new KlensterHeaderElements;
$aps = new KlensterPostSettings;
$post_type = get_post_type();
$template = str_replace( "klenster-", "", $post_type ); // template id
$aps->klenster_set_post_template( $template );
$template_class = $aps->klenster_template_content_class();
$full_width_class = '';
$acpt = new KlensterCPT;
?>
<div class="klenster-content <?php echo esc_attr( 'klenster-' . $template ); ?> klenster-page">
		
		<?php $ahe->klenster_header_slider('bottom'); ?>
		
		<?php $ahe->klenster_page_title( 'page' ); ?>
		<div class="klenster-content-inner">
			<div class="container">
	
				<div class="row">
					
					<div class="<?php echo esc_attr( $template_class['content_class'] ); ?>">
						<div id="primary" class="content-area">
							<?php
								$acpt->klenster_cpt_call_template( $post_type );
							?>				
						</div><!-- #primary -->
					</div><!-- main col -->
					
					<?php if( $template_class['lsidebar_class'] != '' ) : ?>
					<div class="<?php echo esc_attr( $template_class['lsidebar_class'] ); ?>">
						<aside class="widget-area left-widget-area<?php echo esc_attr( $template_class['sticky_class'] ); ?>">
							<?php dynamic_sidebar( $template_class['left_sidebar'] ); ?>
						</aside>
					</div><!-- sidebar col -->
					<?php endif; ?>
					
					<?php if( $template_class['rsidebar_class'] != '' ) : ?>
					<div class="<?php echo esc_attr( $template_class['rsidebar_class'] ); ?>">
						<aside class="widget-area right-widget-area<?php echo esc_attr( $template_class['sticky_class'] ); ?>">
							<?php dynamic_sidebar( $template_class['right_sidebar'] ); ?>
						</aside>
					</div><!-- sidebar col -->
					<?php endif; ?>
					
				</div><!-- row -->
			
		</div><!-- .container -->
	</div><!-- .klenster-content-inner -->
</div><!-- .klenster-content -->
<?php get_footer();