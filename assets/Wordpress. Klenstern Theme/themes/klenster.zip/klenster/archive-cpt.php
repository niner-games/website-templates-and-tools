<?php
/**
 * The arcihve template for displaying all custom post types
 */
 
get_header(); 
$ahe = new KlensterHeaderElements;
$aps = new KlensterPostSettings;
$template = 'blog'; // template id
if( $aps->klenster_check_template_exists( 'archive' ) ){
	$template = 'archive';
}
$aps->klenster_set_post_template( $template );
$template_class = $aps->klenster_template_content_class();
$full_width_class = '';
$acpt = new KlensterCPT;

?>
<div class="klenster-content <?php echo esc_attr( 'klenster-' . $template ); ?>">
		
		<?php $ahe->klenster_header_slider('bottom'); ?>
		
		<?php $ahe->klenster_page_title( $template ); ?>
		<div class="klenster-content-inner">
			<div class="container">
	
				<div class="row">
					
					<div class="<?php echo esc_attr( $template_class['content_class'] ); ?>">
						<div id="primary" class="content-area">
							<?php
								$q_object = get_queried_object();
								$cpt = '';
								if( isset($q_object->name) )
									$cpt = $q_object->name;

								if( $cpt == 'klenster-portfolio' ){
									$acpt->klenster_cpt_call_tax_template( 'portfolio-archive' );
								}elseif( $cpt == 'klenster-team' ){
									$acpt->klenster_cpt_call_tax_template( 'team-archive' );
								}elseif( $cpt == 'klenster-services' ){
									$acpt->klenster_cpt_call_tax_template( 'services-archive' );
								}elseif( $cpt == 'klenster-events' ){
									$acpt->klenster_cpt_call_tax_template( 'events-archive' );
								}elseif( $cpt == 'klenster-testimonial' ){
									$acpt->klenster_cpt_call_tax_template( 'testimonial-archive' );
								}else{
									require_once get_template_directory() . '/template-parts/post/content-none.php';
								}
							?>				
						</div><!-- #primary -->
					</div><!-- main col -->
					
					<?php if( $template_class['lsidebar_class'] != '' ) : ?>
					<div class="<?php echo esc_attr( $template_class['lsidebar_class'] ); ?>">
						<aside class="widget-area left-widget-area<?php echo esc_attr( $template_class['sticky_class'] ); ?>">
							<?php dynamic_sidebar( $template_class['left_sidebar'] ); ?>
						</aside>
					</div><!-- sidebar col -->
					<?php endif; ?>
					
					<?php if( $template_class['rsidebar_class'] != '' ) : ?>
					<div class="<?php echo esc_attr( $template_class['rsidebar_class'] ); ?>">
						<aside class="widget-area right-widget-area<?php echo esc_attr( $template_class['sticky_class'] ); ?>">
							<?php dynamic_sidebar( $template_class['right_sidebar'] ); ?>
						</aside>
					</div><!-- sidebar col -->
					<?php endif; ?>
					
				</div><!-- row -->
			
		</div><!-- .container -->
	</div><!-- .klenster-content-inner -->
</div><!-- .klenster-content -->
<?php get_footer();