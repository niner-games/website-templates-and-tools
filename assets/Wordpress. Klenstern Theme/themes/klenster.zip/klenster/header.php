<?php
/*
 * The header for klenster theme
 */
$ahe = new KlensterHeaderElements;
$protocal = is_ssl() ? 'https' : 'http';

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="<?php echo esc_attr( $protocal ); ?>://gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>
<?php		
	/*
	 * Sttaic Template Options - klenster_demo_header - 10
	 */
	do_action('klenster_before_body_action');	
?>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php if( $ahe->klenster_page_loader() ) : ?>
	<div class="page-loader"></div>
<?php endif; ?>
<?php
	/*
	 * Mobile Header - klenster_mobile_header - 10
	 * Mobile Bar - klenster_mobile_bar - 20
	 * Secondary Menu Space - klenster_header_secondary_space - 30
	 * Top Sliding Bar - klenster_header_top_sliding - 40
	 */
	do_action('klenster_body_action');
	
?>

<div id="page" class="klenster-wrapper<?php $ahe->klenster_theme_layout(); ?>">
	<?php $ahe->klenster_header_slider('top'); ?>
	<header class="klenster-header<?php $ahe->klenster_header_layout(); ?>">
		
			<?php $ahe->klenster_header_bar(); ?>
		
	</header>
	<div class="klenster-content-wrapper">