<?php

/**
 * Klenster Theme Customizer Functionalities  
 *
 */
final class Klenster_Theme_Customize {
	
	private static $_instance = null;
	
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	public function __construct() {
		$this->init();
	}
	
	public function init() {
		//Register doctors directory post type
		$this->initiate_customize_fields();
		
		//Call doctors directory shortcodes
		$this->customize_config();
	}
	
	public function initiate_customize_fields(){
		//Panel and Section
		require_once KLENSTER_ADMIN .'/customizer/klenster-customizer-setting.php';

		//Trigger
		require_once KLENSTER_ADMIN .'/customizer/customizer-trigger/class-customize-trigger.php';
	}
	
	public function customize_config(){
		require_once KLENSTER_ADMIN .'/customizer/customize-config.php';
	}

}

Klenster_Theme_Customize::instance();