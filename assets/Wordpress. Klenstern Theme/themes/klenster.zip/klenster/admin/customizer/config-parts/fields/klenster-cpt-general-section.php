<?php

//Custom Post Types
$settings = array(
	'id'			=> 'cpt-opts',
	'type'			=> 'multicheck',
	'title'			=> esc_html__( 'Custom Post Types', 'klenster' ),
	'description'	=> esc_html__( 'Enable the custom post types which are need, once done save theme options button. Then refresh page, you can see the enabled CPT options are showing sub level.', 'klenster' ),
	'default'		=> '',
	'items' 		=> array(
		'portfolio'	    => esc_html__( 'Portfolio', 'klenster' ),
		'team'	        => esc_html__( 'Team', 'klenster' ),
		'testimonial'	=> esc_html__( 'Testimonial', 'klenster' ),
		'events'	    => esc_html__( 'Events', 'klenster' ),
		'services'	    => esc_html__( 'Services', 'klenster' ),
	),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );