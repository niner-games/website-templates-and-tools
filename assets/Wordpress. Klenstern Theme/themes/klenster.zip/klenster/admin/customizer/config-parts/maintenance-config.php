<?php

//Theme Option -> Maintenance
$theme_maintenance_panel = new Klenster_WP_Customize_Panel( $wp_customize, 'theme_maintenance_panel', array(
	'title'			=> esc_html__( 'Maintenance', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for maintenance of current site.', 'klenster' ),
	'priority'		=> 11,
	'panel'			=> 'klenster_theme_panel'
));
$wp_customize->add_panel( $theme_maintenance_panel );

//Maintenance -> General Maintenance
$klenster_maintenance_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_maintenance_section', array(
	'title'			=> esc_html__( 'General Maintenance', 'klenster' ),
	'description'	=> esc_html__( 'This is the general setting for maintenance of current site.', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'theme_maintenance_panel'
));
$wp_customize->add_section( $klenster_maintenance_section );

//General Maintenance
$wp_customize->add_setting('ajax_trigger_klenster_maintenance_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_maintenance_section', array(
	'section'		=> 'klenster_maintenance_section'
)));