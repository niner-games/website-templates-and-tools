<?php

//Mailchimp API Key
$settings = array(
	'id'			=> 'mailchimp-api',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Mailchimp API Key', 'klenster' ),
	'description'	=> esc_html__( 'Place here your registered mailchimp API key.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Google Map API Key
$settings = array(
	'id'			=> 'google-api',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Google Map API Key', 'klenster' ),
	'description'	=> esc_html__( 'Place here your registered google map API key.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );