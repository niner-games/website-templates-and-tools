<?php

//Header Layout Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Layout', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Top Bar Items
$settings = array(
	'id'			=> 'header-topbar-items',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Header Top Bar Items', 'klenster' ),
	'description'	=> esc_html__( 'Needed header topbar items drag from disabled and put enabled.', 'klenster' ),
	'default' 		=> array(
		'disabled' => array(
			'header-topbar-text-2'	=> esc_html__( 'Custom Text 2', 'klenster' ),
			'header-topbar-text-3'	=> esc_html__( 'Custom Text 3', 'klenster' ),
			'header-topbar-social'	=> esc_html__( 'Social', 'klenster' ),
			'header-topbar-search'	=> esc_html__( 'Search', 'klenster' ),
			'header-topbar-date' 	=> esc_html__( 'Date', 'klenster' ),
			'header-phone'   		=> esc_html__( 'Phone Number', 'klenster' ),
			'header-address'  		=> esc_html__( 'Address Text', 'klenster' ),
			'header-email'   		=> esc_html__( 'Email', 'klenster' )					
		),
		'Left'  => array(
			'header-topbar-menu'    => esc_html__( 'Top Bar Menu', 'klenster' )												
		),
		'Center' => array(),
		'Right' => array(
			'header-topbar-text-1'	=> esc_html__( 'Custom Text 1', 'klenster' ),
			'header-cart'   		=> esc_html__( 'Cart', 'klenster' ),
			'header-topbar-search-toggle'	=> esc_html__( 'Search Toggle', 'klenster' )
		)
	),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Clik and Edit Header Layouts End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Style Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Style', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Top Bar Height
$settings = array(
	'id'			=> 'header-topbar-height',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Header Top Bar Height', 'klenster' ),
	'description'	=> esc_html__( 'Increase or decrease header topbar height. Here no need to put dimension units like px, em etc. Example 50', 'klenster' ),
	'default'		=> '50',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Top Bar Sticky Height
$settings = array(
	'id'			=> 'header-topbar-sticky-height',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Header Top Bar Sticky Height', 'klenster' ),
	'description'	=> esc_html__( 'Increase or decrease header topbar sticky height. Here no need to put dimension units like px, em etc. Example 50', 'klenster' ),
	'default'		=> '50',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Topbar Background
$settings = array(
	'id'			=> 'header-topbar-background',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Header Topbar Background', 'klenster' ),
	'description'	=> esc_html__( 'Choose topbar background color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Topbar Color
$settings = array(
	'id'			=> 'header-topbar-link-color',
	'type'			=> 'link',
	'title'			=> esc_html__( 'Header Topbar Link Color', 'klenster' ),
	'description'	=> esc_html__( 'Choose topbar link color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Topbar Border
$settings = array(
	'id'			=> 'header-topbar-border',
	'type'			=> 'border',
	'title'			=> esc_html__( 'Header Topbar Border', 'klenster' ),
	'description'	=> esc_html__( 'Here you can set border. No need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Topbar Padding Option
$settings = array(
	'id'			=> 'header-topbar-padding',
	'type'			=> 'dimension',
	'title'			=> esc_html__( 'Header Topbar Padding Option', 'klenster' ),
	'description'	=> esc_html__( 'Here no need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Style End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Custom Text
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Custom Text', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Topbar Custom Text 1
$settings = array(
	'id'			=> 'header-topbar-text-1',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Topbar Custom Text 1', 'klenster' ),
	'description'	=> esc_html__( 'Custom text shows header topbar. Here, you can place shortcode.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Topbar Custom Text 2
$settings = array(
	'id'			=> 'header-topbar-text-2',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Topbar Custom Text 2', 'klenster' ),
	'description'	=> esc_html__( 'Custom text shows header topbar. Here, you can place shortcode.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Topbar Custom Text 3
$settings = array(
	'id'			=> 'header-topbar-text-3',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Topbar Custom Text 3', 'klenster' ),
	'description'	=> esc_html__( 'Custom text shows header topbar. Here, you can place shortcode.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Date Format
$settings = array(
	'id'			=> 'header-topbar-date',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Date Format', 'klenster' ),
	'description'	=> esc_html__( 'Enter date format like: l, F j, Y', 'klenster' ),
	'default'		=> 'l, F j, Y',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Custom Text End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );