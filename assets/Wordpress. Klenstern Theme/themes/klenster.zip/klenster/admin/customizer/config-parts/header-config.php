<?php

//Theme Option -> Header
$theme_header_panel = new Klenster_WP_Customize_Panel( $wp_customize, 'theme_header_panel', array(
	'title'			=> esc_html__( 'Header', 'klenster' ),
	'description'	=> esc_html__( 'These are header general settings of klenster theme', 'klenster' ),
	'priority'		=> 5,
	'panel'			=> 'klenster_theme_panel'
));
$wp_customize->add_panel( $theme_header_panel );

//Header -> Header General
$klenster_header_general_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_header_general_section', array(
	'title'			=> esc_html__( 'Header General', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for general header.', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'theme_header_panel'
));
$wp_customize->add_section( $klenster_header_general_section );

//Header General
$wp_customize->add_setting('ajax_trigger_klenster_header_general_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_header_general_section', array(
	'section'		=> 'klenster_header_general_section'
)));

//Header -> Header Top Section
$klenster_header_topbar_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_header_topbar_section', array(
	'title'			=> esc_html__( 'Header Top', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for header top.', 'klenster' ),
	'priority'		=> 2,
	'panel'			=> 'theme_header_panel'
));
$wp_customize->add_section( $klenster_header_topbar_section );

//Header Top
$wp_customize->add_setting('ajax_trigger_klenster_header_topbar_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_header_topbar_section', array(
	'section'		=> 'klenster_header_topbar_section'
)));

//Header -> Header Middle Section
$klenster_header_logobar_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_header_logobar_section', array(
	'title'			=> esc_html__( 'Header Middle', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for header middle(logo section).', 'klenster' ),
	'priority'		=> 3,
	'panel'			=> 'theme_header_panel'
));
$wp_customize->add_section( $klenster_header_logobar_section );

//Header Middle
$wp_customize->add_setting('ajax_trigger_klenster_header_logobar_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_header_logobar_section', array(
	'section'		=> 'klenster_header_logobar_section'
)));

//Header -> Header Navbar Section
$klenster_header_navbar_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_header_navbar_section', array(
	'title'			=> esc_html__( 'Header Bottom', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for header bottom(navbar).', 'klenster' ),
	'priority'		=> 4,
	'panel'			=> 'theme_header_panel'
));
$wp_customize->add_section( $klenster_header_navbar_section );

//Header Navbar
$wp_customize->add_setting('ajax_trigger_klenster_header_navbar_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_header_navbar_section', array(
	'section'		=> 'klenster_header_navbar_section'
)));

//Header -> Header Left/Right Navbar
$klenster_header_fixed_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_header_fixed_section', array(
	'title'			=> esc_html__( 'Left/Right Navbar', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for header left/right navbar.', 'klenster' ),
	'priority'		=> 5,
	'panel'			=> 'theme_header_panel'
));
$wp_customize->add_section( $klenster_header_fixed_section );

//Header Left/Right
$wp_customize->add_setting('ajax_trigger_klenster_header_fixed_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_header_fixed_section', array(
	'section'		=> 'klenster_header_fixed_section'
)));

//Header -> Mobile Menu
$klenster_mobile_menu_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_mobile_menu_section', array(
	'title'			=> esc_html__( 'Mobile Menu', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for mobile header and mobile menu.', 'klenster' ),
	'priority'		=> 6,
	'panel'			=> 'theme_header_panel'
));
$wp_customize->add_section( $klenster_mobile_menu_section );

//Mobile Menu
$wp_customize->add_setting('ajax_trigger_klenster_mobile_menu_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_mobile_menu_section', array(
	'section'		=> 'klenster_mobile_menu_section'
)));

//Header -> Top Sliding Bar
$klenster_header_topslidingbar_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_header_topslidingbar_section', array(
	'title'			=> esc_html__( 'Top Sliding Bar', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for top sliding bar.', 'klenster' ),
	'priority'		=> 7,
	'panel'			=> 'theme_header_panel'
));
$wp_customize->add_section( $klenster_header_topslidingbar_section );

//Top Sliding Bar
$wp_customize->add_setting('ajax_trigger_klenster_header_topslidingbar_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_header_topslidingbar_section', array(
	'section'		=> 'klenster_header_topslidingbar_section'
)));