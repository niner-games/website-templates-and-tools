<?php

//Layout Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Layout', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Page Title Option
$settings = array(
	'id'			=> 'single-post-page-title-opt',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Page Title Option', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable page title.', 'klenster' ),
	'default'		=> 1,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Page Title Items
$settings = array(
	'id'			=> 'template-single-post-pagetitle-items',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Page Title Items', 'klenster' ),
	'description'	=> esc_html__( 'Needed items for page title wrap, drag from disabled and put enabled.', 'klenster' ),
	'default' 		=> array(
		'disabled' => array(),
		'Left'  => array(
			'title' => esc_html__( 'Page Title Text', 'klenster' ),
		),
		'Center' => array(),
		'Right'  => array(
			'breadcrumb'	=> esc_html__( 'Breadcrumb', 'klenster' )
		)
	),
	'required'		=> array( 'single-post-page-title-opt', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Archive Settings
$settings = array(
	'type'			=> 'section',
	'label'			=> esc_html__( 'Archive Settings', 'klenster' ),
	'description'	=> esc_html__( 'This is settings for single post page layout, sidebar sticky and etc.', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Archive Template
$settings = array(
	'id'			=> 'single-post-page-template',
	'type'			=> 'radioimage',
	'title'			=> esc_html__( 'Archive Template', 'klenster' ),
	'description'	=> esc_html__( 'Choose your current single post page template.', 'klenster' ),
	'default'		=> 'right-sidebar',
	'items' 		=> array(
		'no-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/1.png',
		'right-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/2.png',
		'left-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/3.png',
		'both-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/4.png'		
	),
	'cols'			=> '4',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Left Sidebar
$settings = array(
	'id'			=> 'single-post-left-sidebar',
	'type'			=> 'sidebars',
	'title'			=> esc_html__( 'Left Sidebar', 'klenster' ),
	'description'	=> esc_html__( 'Select widget area for showing on left side.', 'klenster' ),
	'default'		=> 'sidebar-1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Right Sidebar
$settings = array(
	'id'			=> 'single-post-right-sidebar',
	'type'			=> 'sidebars',
	'title'			=> esc_html__( 'Right Sidebar', 'klenster' ),
	'description'	=> esc_html__( 'Select widget area for showing on right side.', 'klenster' ),
	'default'		=> 'sidebar-1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Full Width Wrap
$settings = array(
	'id'			=> 'single-post-full-wrap',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Full Width Wrap', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable to show or hide full width post wrapper.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Article Top Meta Items
$settings = array(
	'id'			=> 'single-post-topmeta-items',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Single Post Article Top Meta Items', 'klenster' ),
	'description'	=> esc_html__( 'Needed single post article top meta items drag from disabled and put enabled part. ie: Left or Right.', 'klenster' ),
	'default' 		=> array(
		'Left'  => array(
			'author'	=> esc_html__( 'Author', 'klenster' )						
		),
		'Right'  => array(
			'date'		=> esc_html__( 'Date', 'klenster' )
		),
		'disabled' => array(
			'social'	=> esc_html__( 'Social Share', 'klenster' ),						
			'likes'		=> esc_html__( 'Likes', 'klenster' ),
			'author'	=> esc_html__( 'Author', 'klenster' ),
			'views'		=> esc_html__( 'Views', 'klenster' ),
			'tag'		=> esc_html__( 'Tags', 'klenster' ),
			'favourite'	=> esc_html__( 'Favourite', 'klenster' ),						
			'comments'	=> esc_html__( 'Comments', 'klenster' ),
			'category'	=> esc_html__( 'Category', 'klenster' )
		)
	),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Article Bottom Meta Items
$settings = array(
	'id'			=> 'single-post-bottommeta-items',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Single Post Article Bottom Meta Items', 'klenster' ),
	'description'	=> esc_html__( 'Needed single post article bottom meta items drag from disabled and put enabled part. ie: Left or Right.', 'klenster' ),
	'default' 		=> array(
		'Left'  => array(
			'category'	=> esc_html__( 'Category', 'klenster' ),
		),
		'Right'  => array(),
		'disabled' => array(
			'social'	=> esc_html__( 'Social Share', 'klenster' ),
			'date'		=> esc_html__( 'Date', 'klenster' ),						
			'social'	=> esc_html__( 'Social Share', 'klenster' ),						
			'likes'		=> esc_html__( 'Likes', 'klenster' ),
			'author'	=> esc_html__( 'Author', 'klenster' ),
			'views'		=> esc_html__( 'Views', 'klenster' ),
			'favourite'	=> esc_html__( 'Favourite', 'klenster' ),
			'comments'	=> esc_html__( 'Comments', 'klenster' ),
			'tag'		=> esc_html__( 'Tags', 'klenster' )
		)
	),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Article Items
$settings = array(
	'id'			=> 'single-post-items',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Single Post Article Items', 'klenster' ),
	'description'	=> esc_html__( 'Needed single post article items drag from disabled and put enabled part. Thumbnail part covers the post format either image/audio/video/gallery/quote/link.', 'klenster' ),
	'default' 		=> array(
		'Enabled'  => array(
			'title'	=> esc_html__( 'Title', 'klenster' ),
			'top-meta'	=> esc_html__( 'Top Meta', 'klenster' ),
			'thumb'	=> esc_html__( 'Thumbnail', 'klenster' ),
			'content'	=> esc_html__( 'Content', 'klenster' ),
			'bottom-meta'	=> esc_html__( 'Bottom Meta', 'klenster' ),
		),
		'disabled' => array()
	),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Article Overlay
$settings = array(
	'id'			=> 'single-post-overlay-opt',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Single Post Article Overlay', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable single post article overlay.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Article Overlay Items
$settings = array(
	'id'			=> 'single-post-overlay-items',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Single Post Article Overlay Items', 'klenster' ),
	'description'	=> esc_html__( 'Needed single post article overlay items drag from disabled and put enabled part.', 'klenster' ),
	'default' 		=> array(
		'Enabled'  => array(
			'title'			=> esc_html__( 'Title', 'klenster' ),
		),
		'disabled' => array(
			'top-meta'		=> esc_html__( 'Top Meta', 'klenster' ),
			'bottom-meta'	=> esc_html__( 'Bottom Meta', 'klenster' )
		)
	),
	'required'		=> array( 'single-post-overlay-opt', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Page Items
$settings = array(
	'id'			=> 'single-post-page-items',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Single Post Page Items', 'klenster' ),
	'description'	=> esc_html__( 'Needed single post items drag from disabled and put enabled part.', 'klenster' ),
	'default' 		=> array(
		'Enabled'  => array(
			'post-items'	=> esc_html__( 'Post Items', 'klenster' ),
			'author-info'	=> esc_html__( 'Author Info', 'klenster' ),
			'post-nav'		=> esc_html__( 'Post Navigation', 'klenster' ),
			'related-slider'=> esc_html__( 'Related Slider', 'klenster' ),
			'comment'		=> esc_html__( 'Comment', 'klenster' )
		),
		'disabled' => array()
	),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Settings End
$settings = array(
	'type'			=> 'section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Layout End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Style Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Style', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Page Title Settings
$settings = array(
	'type'			=> 'section',
	'label'			=> esc_html__( 'Page Title Settings', 'klenster' ),
	'description'	=> esc_html__( 'This is page title style settings shows only when page title option active.', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Font Color
$settings = array(
	'id'			=> 'template-single-post-color',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Font Color', 'klenster' ),
	'description'	=> esc_html__( 'This is font color for current field.', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'single-post-page-title-opt', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Template  Link Color
$settings = array(
	'id'			=> 'template-single-post-link-color',
	'type'			=> 'link',
	'title'			=> esc_html__( 'Single Post Template  Link Color', 'klenster' ),
	'description'	=> esc_html__( 'Choose Single post title bar link color.', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'single-post-page-title-opt', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Template  Border
$settings = array(
	'id'			=> 'template-single-post-border',
	'type'			=> 'border',
	'title'			=> esc_html__( 'Single Post Template  Border', 'klenster' ),
	'description'	=> esc_html__( 'Here you can set border. No need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'single-post-page-title-opt', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Template  Padding Option
$settings = array(
	'id'			=> 'template-single-post-padding',
	'type'			=> 'dimension',
	'title'			=> esc_html__( 'Single Post Template  Padding Option', 'klenster' ),
	'description'	=> esc_html__( 'Here no need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'single-post-page-title-opt', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Template  Background
$settings = array(
	'id'			=> 'template-single-post-background-all',
	'type'			=> 'background',
	'title'			=> esc_html__( 'Single Post Template  Background', 'klenster' ),
	'description'	=> esc_html__( 'This is settings for footer background.', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'single-post-page-title-opt', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Background Parallax
$settings = array(
	'id'			=> 'single-post-page-title-parallax',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Background Parallax', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable page title background parallax.', 'klenster' ),
	'default'		=> 0,
	'required'		=> array( 'single-post-page-title-opt', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Background Video
$settings = array(
	'id'			=> 'single-post-page-title-bg',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Background Video', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable page title background video.', 'klenster' ),
	'default'		=> 0,
	'required'		=> array( 'single-post-page-title-opt', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Page Title Background Video
$settings = array(
	'id'			=> 'single-post-page-title-video',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Page Title Background Video', 'klenster' ),
	'description'	=> esc_html__( 'Set page title background video for page. Only allowed youtube video id. Example: UWF7dZTLW4c', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'single-post-page-title-bg', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Page Title Overlay
$settings = array(
	'id'			=> 'single-post-page-title-overlay',
	'type'			=> 'alpha',
	'title'			=> esc_html__( 'Page Title Overlay', 'klenster' ),
	'description'	=> esc_html__( 'Choose page title overlay rgba color.', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'single-post-page-title-opt', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Page Title Items Option
$settings = array(
	'id'			=> 'template-single-post-page-title-items-opt',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Page Title Items Option', 'klenster' ),
	'description'	=> esc_html__( 'Enable to make page title items custom layout.', 'klenster' ),
	'default'		=> 0,
	'required'		=> array( 'single-post-page-title-opt', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Page Title Settings End
$settings = array(
	'type'			=> 'section',
	'section_stat'	=> false,
	'required'		=> array( 'single-post-page-title-opt', '=', 1 )
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Article Skin Settings
$settings = array(
	'type'			=> 'section',
	'label'			=> esc_html__( 'Single Post Article Skin Settings', 'klenster' ),
	'description'	=> esc_html__( 'This is skin settings for each single post article.', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Article Font Color
$settings = array(
	'id'			=> 'single-post-article-color',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Article Font Color', 'klenster' ),
	'description'	=> esc_html__( 'This is font color for single post article.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Article Link Color
$settings = array(
	'id'			=> 'single-post-article-link-color',
	'type'			=> 'link',
	'title'			=> esc_html__( 'Article Link Color', 'klenster' ),
	'description'	=> esc_html__( 'Choose single post article link color for single post article.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Article Border
$settings = array(
	'id'			=> 'single-post-article-border',
	'type'			=> 'border',
	'title'			=> esc_html__( 'Article Border', 'klenster' ),
	'description'	=> esc_html__( 'Here you can set border. No need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Article Padding Option
$settings = array(
	'id'			=> 'single-post-article-padding',
	'type'			=> 'dimension',
	'title'			=> esc_html__( 'Article Padding Option', 'klenster' ),
	'description'	=> esc_html__( 'Here no need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Article Background
$settings = array(
	'id'			=> 'single-post-article-background',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Article Background Color', 'klenster' ),
	'description'	=> esc_html__( 'This is background color for single post article.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Article Skin Settings End
$settings = array(
	'type'			=> 'section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Article Overlay Skin Settings
$settings = array(
	'type'			=> 'section',
	'label'			=> esc_html__( 'Single Post Article Overlay Skin Settings', 'klenster' ),
	'description'	=> esc_html__( 'This is overlay skin settings for each single post article.', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Article Font Color
$settings = array(
	'id'			=> 'single-post-article-overlay-color',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Article Font Color', 'klenster' ),
	'description'	=> esc_html__( 'This is font color for single post article.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Article Link Color
$settings = array(
	'id'			=> 'single-post-article-overlay-link-color',
	'type'			=> 'link',
	'title'			=> esc_html__( 'Article Link Color', 'klenster' ),
	'description'	=> esc_html__( 'Choose single post article overlay link color for single post article.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Article Border
$settings = array(
	'id'			=> 'single-post-article-overlay-border',
	'type'			=> 'border',
	'title'			=> esc_html__( 'Article Border', 'klenster' ),
	'description'	=> esc_html__( 'Here you can set border. No need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Article Padding Option
$settings = array(
	'id'			=> 'single-post-article-overlay-padding',
	'type'			=> 'dimension',
	'title'			=> esc_html__( 'Article Padding Option', 'klenster' ),
	'description'	=> esc_html__( 'Here no need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Article Background
$settings = array(
	'id'			=> 'single-post-article-overlay-background',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Article Background Color', 'klenster' ),
	'description'	=> esc_html__( 'This is background color for single post article.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Article Overlay Skin Settings End
$settings = array(
	'type'			=> 'section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Style End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Advanced Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Advanced', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Post Format Settings Start
$settings = array(
	'type'			=> 'section',
	'label'			=> esc_html__( 'Post Format Settings', 'klenster' ),
	'description'	=> esc_html__( 'This is post format settings for single post.', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Video Format
$settings = array(
	'id'			=> 'single-post-video-format',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Video Format', 'klenster' ),
	'description'	=> esc_html__( 'Choose single post page video post format settings.', 'klenster' ),
	'choices'		=> array(
		'onclick' 	=> esc_html__( 'On Click Run Video', 'klenster' ),
		'overlay' 	=> esc_html__( 'Modal Box Video', 'klenster' ),
		'direct' 	=> esc_html__( 'Direct Video', 'klenster' )
	),
	'default'		=> 'onclick',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Quote Format
$settings = array(
	'id'			=> 'single-post-quote-format',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Quote Format', 'klenster' ),
	'description'	=> esc_html__( 'Choose single post page quote post format settings.', 'klenster' ),
	'choices'		=> array(
		'featured' 		=> esc_html__( 'Dark Overlay', 'klenster' ),
		'theme-overlay' => esc_html__( 'Theme Overlay', 'klenster' ),
		'theme' 		=> esc_html__( 'Theme Color Background', 'klenster' ),
		'none' 			=> esc_html__( 'None', 'klenster' )
	),
	'default'		=> 'featured',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Link Format
$settings = array(
	'id'			=> 'single-post-link-format',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Link Format', 'klenster' ),
	'description'	=> esc_html__( 'Choose single post page link post format settings.', 'klenster' ),
	'choices'		=> array(
		'featured' 		=> esc_html__( 'Dark Overlay', 'klenster' ),
		'theme-overlay' => esc_html__( 'Theme Overlay', 'klenster' ),
		'theme' 		=> esc_html__( 'Theme Color Background', 'klenster' ),
		'none' 			=> esc_html__( 'None', 'klenster' )
	),
	'default'		=> 'featured',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Gallery Format
$settings = array(
	'id'			=> 'single-post-gallery-format',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Gallery Format', 'klenster' ),
	'description'	=> esc_html__( 'Choose single post page gallery post format settings.', 'klenster' ),
	'choices'		=> array(
		'default'	=> esc_html__( 'Default Gallery', 'klenster' ),
		'popup' 	=> esc_html__( 'Popup Gallery', 'klenster' ),
		'grid' 		=> esc_html__( 'Grid Popup Gallery', 'klenster' )
	),
	'default'		=> 'default',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Post Format Settings End
$settings = array(
	'type'			=> 'section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Single Post Featured Slider
$settings = array(
	'id'			=> 'single-post-featured-slider',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Single Post Featured Slider', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable single post featured slider.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Sidebar Sticky
$settings = array(
	'id'			=> 'single-post-sidebar-sticky',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Sidebar Sticky', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable sidebar sticky.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Sidebar on Mobile
$settings = array(
	'id'			=> 'single-post-page-hide-sidebar',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Sidebar on Mobile', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable to show or hide sidebar on mobile.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Related Post Max Limit
$settings = array(
	'id'			=> 'related-max-posts',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Related Post Max Limit', 'klenster' ),
	'description'	=> esc_html__( 'Enter related post maximum limit for get from posts query. Example 5', 'klenster' ),
	'default'		=> '5',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Related Posts From
$settings = array(
	'id'			=> 'related-posts-filter',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Related Posts From', 'klenster' ),
	'description'	=> esc_html__( 'Select related posts gets from category or tag.', 'klenster' ),
	'choices'		=> array(
		'category'	=> esc_html__( 'Category', 'klenster' ),
		'tag'		=> esc_html__( 'Tag', 'klenster' )
	),
	'default'		=> 'category',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Advanced End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );