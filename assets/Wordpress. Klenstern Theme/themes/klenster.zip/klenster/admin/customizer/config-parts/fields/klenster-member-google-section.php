<?php

//Google Client ID
$settings = array(
	'id'			=> 'social-google-client-id',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Google Client ID', 'klenster' ),
	'description'	=> esc_html__( 'Set google login client id for login via google. You can refer here: ', 'klenster' ) . 'https://console.developers.google.com/',
	'default'		=> ''
);
KlensterCustomizerConfig::buildFields( $settings );

//Google Client Secret
$settings = array(
	'id'			=> 'social-google-client-secret',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Google Client Secret', 'klenster' ),
	'description'	=> esc_html__( 'Set google login client secret for login via google.', 'klenster' ),
	'default'		=> ''
);
KlensterCustomizerConfig::buildFields( $settings );

//Google Redirect
$settings = array(
	'id'			=> 'social-google-redirect',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Google Login Redirect URL', 'klenster' ),
	'description'	=> esc_html__( 'Set google login redirect url.', 'klenster' ),
	'default'		=> ''
);
KlensterCustomizerConfig::buildFields( $settings );