<?php

//Woocommerce Shop Template
$settings = array(
	'id'			=> 'woo-page-template',
	'type'			=> 'radioimage',
	'title'			=> esc_html__( 'Woocommerce Shop Template', 'klenster' ),
	'description'	=> esc_html__( 'Choose your current archive page template.', 'klenster' ),
	'default'		=> 'right-sidebar',
	'items' 		=> array(
		'no-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/1.png',
		'right-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/2.png',
		'left-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/3.png',
		'both-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/4.png'		
	),
	'cols'			=> '4',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Left Sidebar
$settings = array(
	'id'			=> 'woo-left-sidebar',
	'type'			=> 'sidebars',
	'title'			=> esc_html__( 'Left Sidebar', 'klenster' ),
	'description'	=> esc_html__( 'Select widget area for showing on left side.', 'klenster' ),
	'default'		=> 'sidebar-1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Right Sidebar
$settings = array(
	'id'			=> 'woo-right-sidebar',
	'type'			=> 'sidebars',
	'title'			=> esc_html__( 'Right Sidebar', 'klenster' ),
	'description'	=> esc_html__( 'Select widget area for showing on right side.', 'klenster' ),
	'default'		=> 'sidebar-1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Shop Columns
$settings = array(
	'id'			=> 'woo-shop-columns',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Shop Columns', 'klenster' ),
	'description'	=> esc_html__( 'This is column settings woocommerce shop page products.', 'klenster' ),
	'choices'		=> array(
		'2'		=> esc_html__( '2 Columns', 'klenster' ),
		'3'		=> esc_html__( '3 Columns', 'klenster' ),
		'4'		=> esc_html__( '4 Columns', 'klenster' ),
		'5'		=> esc_html__( '5 Columns', 'klenster' ),
		'6'		=> esc_html__( '6 Columns', 'klenster' ),
	),
	'default'		=> '3',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Shop Product Per Page
$settings = array(
	'id'			=> 'woo-shop-ppp',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Shop Product Per Page', 'klenster' ),
	'description'	=> esc_html__( 'This is column settings woocommerce related products per page', 'klenster' ),
	'default'		=> '12',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Related Product Per Page
$settings = array(
	'id'			=> 'woo-related-ppp',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Related Product Per Page', 'klenster' ),
	'description'	=> esc_html__( 'This is column settings woocommerce related products per page', 'klenster' ),
	'default'		=> '3',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );