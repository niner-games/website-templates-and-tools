<?php

//Search Content
$settings = array(
	'id'			=> 'search-content',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Search Content', 'klenster' ),
	'description'	=> esc_html__( 'Choose this option for search content from site.', 'klenster' ),
	'choices'		=> array(
		'all'		=> esc_html__( 'All', 'klenster' ),
		'post'		=> esc_html__( 'Post Content Only', 'klenster' ),
		'page'		=> esc_html__( 'Page Content Only', 'klenster' )
	),
	'default'		=> 'all',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );