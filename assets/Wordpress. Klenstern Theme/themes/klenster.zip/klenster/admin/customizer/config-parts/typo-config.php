<?php

//Theme Option -> Typography
$theme_typography_panel = new Klenster_WP_Customize_Panel( $wp_customize, 'theme_typography_panel', array(
	'title'			=> esc_html__( 'Typography', 'klenster' ),
	'description'	=> esc_html__( 'These are the theme typography options', 'klenster' ),
	'priority'		=> 4,
	'panel'			=> 'klenster_theme_panel'
));
$wp_customize->add_panel( $theme_typography_panel );

//Typography -> General Typography
$klenster_general_typography_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_general_typography_section', array(
	'title'			=> esc_html__( 'General Typography', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for theme general typography', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'theme_typography_panel'
));
$wp_customize->add_section( $klenster_general_typography_section );

//General Typography
$wp_customize->add_setting('ajax_trigger_klenster_general_typography_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_general_typography_section', array(
	'section'		=> 'klenster_general_typography_section'
)));

//Typography -> Widgets Typography
$klenster_widget_typography_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_widget_typography_section', array(
	'title'			=> esc_html__( 'Widgets Typography', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for theme widgets typography', 'klenster' ),
	'priority'		=> 2,
	'panel'			=> 'theme_typography_panel'
));
$wp_customize->add_section( $klenster_widget_typography_section );

//Widgets Typography
$wp_customize->add_setting('ajax_trigger_klenster_widget_typography_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_widget_typography_section', array(
	'section'		=> 'klenster_widget_typography_section'
)));

//Typography -> Menu Typography
$klenster_menu_typography_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_menu_typography_section', array(
	'title'			=> esc_html__( 'Menu Typography', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for theme menu typography', 'klenster' ),
	'priority'		=> 3,
	'panel'			=> 'theme_typography_panel'
));
$wp_customize->add_section( $klenster_menu_typography_section );

//Menu Typography
$wp_customize->add_setting('ajax_trigger_klenster_menu_typography_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_menu_typography_section', array(
	'section'		=> 'klenster_menu_typography_section'
)));


//Typography -> Other Typography
$klenster_menu_other_typography_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_menu_other_typography_section', array(
	'title'			=> esc_html__( 'Other Typography', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for other typography', 'klenster' ),
	'priority'		=> 4,
	'panel'			=> 'theme_typography_panel'
));
$wp_customize->add_section( $klenster_menu_other_typography_section );

//Other Typography
$wp_customize->add_setting('ajax_trigger_klenster_menu_other_typography_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_menu_other_typography_section', array(
	'section'		=> 'klenster_menu_other_typography_section'
)));