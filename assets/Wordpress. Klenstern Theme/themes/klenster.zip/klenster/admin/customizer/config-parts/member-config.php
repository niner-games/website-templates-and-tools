<?php

//Theme Option -> Member
$theme_member_panel = new Klenster_WP_Customize_Panel( $wp_customize, 'theme_member_panel', array(
	'title'			=> esc_html__( 'Klenster Member Settings', 'klenster' ),
	'description'	=> esc_html__( 'These are the klenster member addon settings of klenster Theme.', 'klenster' ),
	'priority'		=> 12,
	'panel'			=> 'klenster_theme_panel'
));
$wp_customize->add_panel( $theme_member_panel );

//Member -> Member General
$klenster_member_general_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_member_general_section', array(
	'title'			=> esc_html__( 'Member General', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for member general details.', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'theme_member_panel'
));
$wp_customize->add_section( $klenster_member_general_section );

//General
$wp_customize->add_setting('ajax_trigger_klenster_member_general_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_member_general_section', array(
	'section'		=> 'klenster_member_general_section'
)));


//Member -> Member Google
$klenster_member_google_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_member_google_section', array(
	'title'			=> esc_html__( 'Login via Google', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for google member.', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'theme_member_panel'
));
$wp_customize->add_section( $klenster_member_google_section );

//Google
$wp_customize->add_setting('ajax_trigger_klenster_member_google_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_member_google_section', array(
	'section'		=> 'klenster_member_google_section'
)));

//Member -> Member Facebook
$klenster_member_facebook_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_member_facebook_section', array(
	'title'			=> esc_html__( 'Login via Facebook', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for facebook member.', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'theme_member_panel'
));
$wp_customize->add_section( $klenster_member_facebook_section );

//Facebook
$wp_customize->add_setting('ajax_trigger_klenster_member_facebook_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_member_facebook_section', array(
	'section'		=> 'klenster_member_facebook_section'
)));

