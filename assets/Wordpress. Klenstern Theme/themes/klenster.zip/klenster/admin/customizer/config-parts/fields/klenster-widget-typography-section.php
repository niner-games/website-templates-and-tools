<?php

//Widgets Title Typography
$settings = array(
	'id'			=> 'widgets-title',
	'type'			=> 'fonts',
	'title'			=> esc_html__( 'Widgets Title Typography', 'klenster' ),
	'description'	=> esc_html__( 'Specify the widget title typography properties.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Widgets Content Typography
$settings = array(
	'id'			=> 'widgets-content',
	'type'			=> 'fonts',
	'title'			=> esc_html__( 'Widgets Content Typography', 'klenster' ),
	'description'	=> esc_html__( 'Specify the widget content typography properties.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );