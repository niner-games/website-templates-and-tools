<?php

//Theme Option -> General
$theme_general_panel = new Klenster_WP_Customize_Panel( $wp_customize, 'theme_general_panel', array(
	'title'			=> esc_html__( 'General', 'klenster' ),
	'description'	=> esc_html__( 'These are the general settings of Klenster theme', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'klenster_theme_panel'
));
$wp_customize->add_panel( $theme_general_panel );

//General -> Layout
$klenster_layout_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_layout_section', array(
	'title'			=> esc_html__( 'Layout', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for theme layouts', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'theme_general_panel'
));
$wp_customize->add_section( $klenster_layout_section );

//Layout
$wp_customize->add_setting('ajax_trigger_klenster_layout_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_layout_section', array(
	'section'		=> 'klenster_layout_section'
)));

//General -> Loaders
$klenster_loader_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_loader_section', array(
	'title'			=> esc_html__('Loaders', 'klenster'),
	'description'	=> esc_html__( 'This is the setting for theme loader images.', 'klenster' ),
	'priority'		=> 2,
	'panel'			=> 'theme_general_panel'
));
$wp_customize->add_section( $klenster_loader_section );

//Loaders
$wp_customize->add_setting('ajax_trigger_klenster_loader_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_loader_section', array(
	'section'		=> 'klenster_loader_section'
)));

//General -> Theme Logo
$klenster_logo_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_logo_section', array(
	'title'			=> esc_html__('Site Logo\'s', 'klenster'),
	'description'	=> esc_html__( 'This is the setting for all the site logo\'s.', 'klenster' ),
	'priority'		=> 3,
	'panel'			=> 'theme_general_panel'
));
$wp_customize->add_section( $klenster_logo_section );

//Theme Logo
$wp_customize->add_setting('ajax_trigger_klenster_logo_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_logo_section', array(
	'section'		=> 'klenster_logo_section'
)));

//General -> API's
$klenster_api_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_api_section', array(
	'title'			=> esc_html__('API', 'klenster'),
	'description'	=> esc_html__( 'This is the setting for all the api\'s where used in this site.', 'klenster' ),
	'priority'		=> 4,
	'panel'			=> 'theme_general_panel'
));
$wp_customize->add_section( $klenster_api_section );

//API's
$wp_customize->add_setting('ajax_trigger_klenster_api_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_api_section', array(
	'section'		=> 'klenster_api_section'
)));

//General -> Comments
$klenster_comments_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_comments_section', array(
	'title'			=> esc_html__('Comments', 'klenster'),
	'description'	=> esc_html__( 'This is the setting for comments.', 'klenster' ),
	'priority'		=> 5,
	'panel'			=> 'theme_general_panel'
));
$wp_customize->add_section( $klenster_comments_section );

//Comments
$wp_customize->add_setting('ajax_trigger_klenster_comments_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_comments_section', array(
	'section'		=> 'klenster_comments_section'
)));

//General -> Smooth Scroll
$klenster_smooth_scroll_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_smooth_scroll_section', array(
	'title'			=> esc_html__('Smooth Scroll', 'klenster'),
	'description'	=> esc_html__( 'This is the setting for page smooth scroll.', 'klenster' ),
	'priority'		=> 6,
	'panel'			=> 'theme_general_panel'
));
$wp_customize->add_section( $klenster_smooth_scroll_section );

//Smooth Scroll
$wp_customize->add_setting('ajax_trigger_klenster_smooth_scroll_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_smooth_scroll_section', array(
	'section'		=> 'klenster_smooth_scroll_section'
)));

//General -> Media Settings
$klenster_media_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_media_section', array(
	'title'			=> esc_html__('Media Settings', 'klenster'),
	'description'	=> esc_html__( 'This is the setting for media sizes', 'klenster' ),
	'priority'		=> 7,
	'panel'			=> 'theme_general_panel'
));
$wp_customize->add_section( $klenster_media_section );

//Media Settings
$wp_customize->add_setting('ajax_trigger_klenster_media_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_media_section', array(
	'section'		=> 'klenster_media_section'
)));

//General -> RTL
$klenster_rtl_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_rtl_section', array(
	'title'			=> esc_html__('RTL', 'klenster'),
	'description'	=> esc_html__( 'This is the setting for theme view RTL', 'klenster' ),
	'priority'		=> 8,
	'panel'			=> 'theme_general_panel'
));
$wp_customize->add_section( $klenster_rtl_section );

//RTL
$wp_customize->add_setting('ajax_trigger_klenster_rtl_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_rtl_section', array(
	'section'		=> 'klenster_rtl_section'
)));