<?php

//Theme Option -> Footer
$theme_footer_panel = new Klenster_WP_Customize_Panel( $wp_customize, 'theme_footer_panel', array(
	'title'			=> esc_html__( 'Footer', 'klenster' ),
	'description'	=> esc_html__( 'These are header general settings of klenster theme', 'klenster' ),
	'priority'		=> 6,
	'panel'			=> 'klenster_theme_panel'
));
$wp_customize->add_panel( $theme_footer_panel );

//Footer -> Footer General
$klenster_footer_general_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_footer_general_section', array(
	'title'			=> esc_html__( 'Footer General', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for general footer.', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'theme_footer_panel'
));
$wp_customize->add_section( $klenster_footer_general_section );

//Footer General
$wp_customize->add_setting('ajax_trigger_klenster_footer_general_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_footer_general_section', array(
	'section'		=> 'klenster_footer_general_section'
)));

//Footer -> Footer Top
$klenster_footer_top_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_footer_top_section', array(
	'title'			=> esc_html__( 'Footer Top', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for footer top section.', 'klenster' ),
	'priority'		=> 2,
	'panel'			=> 'theme_footer_panel'
));
$wp_customize->add_section( $klenster_footer_top_section );

//Footer Top
$wp_customize->add_setting('ajax_trigger_klenster_footer_top_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_footer_top_section', array(
	'section'		=> 'klenster_footer_top_section'
)));

//Footer -> Footer Middle
$klenster_footer_middle_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_footer_middle_section', array(
	'title'			=> esc_html__( 'Footer Middle', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for footer middle section.', 'klenster' ),
	'priority'		=> 3,
	'panel'			=> 'theme_footer_panel'
));
$wp_customize->add_section( $klenster_footer_middle_section );

//Footer Middle
$wp_customize->add_setting('ajax_trigger_klenster_footer_middle_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_footer_middle_section', array(
	'section'		=> 'klenster_footer_middle_section'
)));

//Footer -> Footer Bottom
$klenster_footer_bottom_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_footer_bottom_section', array(
	'title'			=> esc_html__( 'Footer Bottom', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for footer bottom section.', 'klenster' ),
	'priority'		=> 4,
	'panel'			=> 'theme_footer_panel'
));
$wp_customize->add_section( $klenster_footer_bottom_section );

//Footer Bottom
$wp_customize->add_setting('ajax_trigger_klenster_footer_bottom_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_footer_bottom_section', array(
	'section'		=> 'klenster_footer_bottom_section'
)));