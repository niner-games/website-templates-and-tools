<?php

//Main Menu Typography
$settings = array(
	'id'			=> 'main-menu-typography',
	'type'			=> 'fonts',
	'title'			=> esc_html__( 'Main Menu Typography', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for main menu typography', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Dropdown Menu Typography
$settings = array(
	'id'			=> 'dropdown-menu-typography',
	'type'			=> 'fonts',
	'title'			=> esc_html__( 'Dropdown Menu Typography', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for dropdown menu typography', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );