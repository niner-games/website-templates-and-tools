<?php

//Layout Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Layout', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Bottom Inner Layout
$settings = array(
	'id'			=> 'footer-bottom-container',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Footer Bottom Inner Layout', 'klenster' ),
	'description'	=> esc_html__( 'Choose footer bottom layout boxed or wide.', 'klenster' ),
	'choices'		=> array(
		'boxed'		=> esc_html__( 'Boxed', 'klenster' ),
		'wide'		=> esc_html__( 'Wide', 'klenster' )
	),
	'default'		=> 'wide',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Bottom Fixed
$settings = array(
	'id'			=> 'footer-bottom-fixed',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Footer Bottom Fixed', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable footer bottom to fixed at bottom of page.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Sidebars
$settings = array(
	'id'			=> 'footer-bottom-widget',
	'type'			=> 'sidebars',
	'title'			=> esc_html__( 'Footer Bottom Widget', 'klenster' ),
	'description'	=> esc_html__( 'Select widget area for showing on footer copyright section.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Bottom Items
$settings = array(
	'id'			=> 'footer-bottom-items',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Footer Bottom Items', 'klenster' ),
	'description'	=> esc_html__( 'Needed footer bottom items drag from disabled and put enabled.', 'klenster' ),
	'default' 		=> array(
		'disabled' => array(
			'social'	=> esc_html__( 'Footer Social Links', 'klenster' ),
			'widget'	=> esc_html__( 'Custom Widget', 'klenster' ),
			'menu'		=> esc_html__( 'Footer Menu', 'klenster' )
		),
		'Left'  => array(),
		'Center'  => array(
			'copyright' => esc_html__( 'Copyright Text', 'klenster' )
		),
		'Right'  => array()
	),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Layout End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Style Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Style', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Bottom Link Color
$settings = array(
	'id'			=> 'footer-bottom-link-color',
	'type'			=> 'link',
	'title'			=> esc_html__( 'Footer Bottom Link Color', 'klenster' ),
	'description'	=> esc_html__( 'Choose footer bottomlink color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Bottom Border
$settings = array(
	'id'			=> 'footer-bottom-border',
	'type'			=> 'border',
	'title'			=> esc_html__( 'Footer Bottom Border', 'klenster' ),
	'description'	=> esc_html__( 'Here you can set border. No need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Bottom Padding Option
$settings = array(
	'id'			=> 'footer-bottom-padding',
	'type'			=> 'dimension',
	'title'			=> esc_html__( 'Footer Bottom Padding Option', 'klenster' ),
	'description'	=> esc_html__( 'Here no need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Bottom Margin Option
$settings = array(
	'id'			=> 'footer-bottom-margin',
	'type'			=> 'dimension',
	'title'			=> esc_html__( 'Footer Bottom Margin Option', 'klenster' ),
	'description'	=> esc_html__( 'Here no need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Bottom Background
$settings = array(
	'id'			=> 'footer-bottom-background',
	'type'			=> 'background',
	'title'			=> esc_html__( 'Footer Bottom Background', 'klenster' ),
	'description'	=> esc_html__( 'This is settings for footer background.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Bottom Background Overlay
$settings = array(
	'id'			=> 'footer-bottom-background-overlay',
	'type'			=> 'alpha',
	'title'			=> esc_html__( 'Footer Bottom Background Overlay', 'klenster' ),
	'description'	=> esc_html__( 'Choose footer bottom background overlay color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Widget Title Color
$settings = array(
	'id'			=> 'footer-bottom-title-color',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Widget Title Color', 'klenster' ),
	'description'	=> esc_html__( 'Choose footer bottom widgets title color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Style End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Custom Text Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Custom Text', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Copyright Text
$settings = array(
	'id'			=> 'copyright-text',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Copyright Text', 'klenster' ),
	'description'	=> esc_html__( 'This is the copyright text. Shown on footer bottom if enable footer bottom in footer items', 'klenster' ),
	'default'		=> esc_html( 'Copyright 2022 Theme by zozothemes' ),
	'refresh'		=> 0,
	'instant'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Custom Text End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );