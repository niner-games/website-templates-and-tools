<?php

//Login/Signin Text
$settings = array(
	'id'			=> 'login-text',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Login/Signin Text', 'klenster' ),
	'description'	=> esc_html__( 'Enter sign in text as per you choice.', 'klenster' ),
	'default'		=> esc_html__( 'Login/Signin', 'klenster' ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Logged Prefix Text
$settings = array(
	'id'			=> 'logged-text',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Logged Prefix Text', 'klenster' ),
	'description'	=> esc_html__( 'Enter logged prefix text.', 'klenster' ),
	'default'		=> esc_html__( 'Hello!', 'klenster' ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Signout Prefix Text
$settings = array(
	'id'			=> 'signout-text',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Signout Text', 'klenster' ),
	'description'	=> esc_html__( 'Enter signout text.', 'klenster' ),
	'default'		=> esc_html__( 'Signout', 'klenster' ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Google Login Option
$settings = array(
	'id'			=> 'google-logins-opt',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Google Login Option', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable google login option.', 'klenster' ),
	'default'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Facebook Login Option
$settings = array(
	'id'			=> 'facebook-logins-opt',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Facebook Login Option', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable facebook login option.', 'klenster' ),
	'default'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Admin Email Id
$settings = array(
	'id'			=> 'admin-email-id',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Admin Email Id', 'klenster' ),
	'description'	=> esc_html__( 'Enter valid admin email for sending update emails of every process. If any user change their password, Then this will send a copy with this email too.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Login Form Description
$settings = array(
	'id'			=> 'login-description',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Login Form Description', 'klenster' ),
	'description'	=> esc_html__( 'You can paste shortcode here. Just display the description on login form.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );