<?php

//Theme Option -> Social
$theme_social_panel = new Klenster_WP_Customize_Panel( $wp_customize, 'theme_social_panel', array(
	'title'			=> esc_html__( 'Social', 'klenster' ),
	'description'	=> esc_html__( 'These are the social settings of klenster Theme', 'klenster' ),
	'priority'		=> 9,
	'panel'			=> 'klenster_theme_panel'
));
$wp_customize->add_panel( $theme_social_panel );

//Header -> Social Links
$klenster_social_links_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_social_links_section', array(
	'title'			=> esc_html__( 'Social Links', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for social links.', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'theme_social_panel'
));
$wp_customize->add_section( $klenster_social_links_section );

//Social Links
$wp_customize->add_setting('ajax_trigger_klenster_social_links_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_social_links_section', array(
	'section'		=> 'klenster_social_links_section'
)));

//Header -> Social Share
$klenster_social_share_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_social_share_section', array(
	'title'			=> esc_html__( 'Social Share', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for social share.', 'klenster' ),
	'priority'		=> 2,
	'panel'			=> 'theme_social_panel'
));
$wp_customize->add_section( $klenster_social_share_section );

//Social Share
$wp_customize->add_setting('ajax_trigger_klenster_social_share_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_social_share_section', array(
	'section'		=> 'klenster_social_share_section'
)));