<?php

//Theme Option -> WooCommerce
$theme_woo_panel = new Klenster_WP_Customize_Panel( $wp_customize, 'theme_woo_panel', array(
	'title'			=> esc_html__( 'WooCommerce', 'klenster' ),
	'description'	=> esc_html__( 'These are the WooCommerce settings of klenster Theme.', 'klenster' ),
	'priority'		=> 12,
	'panel'			=> 'klenster_theme_panel'
));
$wp_customize->add_panel( $theme_woo_panel );

//WooCommerce -> Woo General
$klenster_woo_general_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_woo_general_section', array(
	'title'			=> esc_html__( 'Woo General', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for woocommerce general options.', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'theme_woo_panel'
));
$wp_customize->add_section( $klenster_woo_general_section );

//Woo General
$wp_customize->add_setting('ajax_trigger_klenster_woo_general_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_woo_general_section', array(
	'section'		=> 'klenster_woo_general_section'
)));

//WooCommerce -> Archive Template
$klenster_woo_archive_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_woo_archive_section', array(
	'title'			=> esc_html__( 'Archive Template', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for woocommerce archive page template.', 'klenster' ),
	'priority'		=> 2,
	'panel'			=> 'theme_woo_panel'
));
$wp_customize->add_section( $klenster_woo_archive_section );

//Archive Template
$wp_customize->add_setting('ajax_trigger_klenster_woo_archive_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_woo_archive_section', array(
	'section'		=> 'klenster_woo_archive_section'
)));

//WooCommerce -> Single Product Template
$klenster_woo_single_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_woo_single_section', array(
	'title'			=> esc_html__( 'Single Product Template', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for woocommerce single product template.', 'klenster' ),
	'priority'		=> 3,
	'panel'			=> 'theme_woo_panel'
));
$wp_customize->add_section( $klenster_woo_single_section );

//Single Product Template
$wp_customize->add_setting('ajax_trigger_klenster_woo_single_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_woo_single_section', array(
	'section'		=> 'klenster_woo_single_section'
)));

//WooCommerce -> Woo Related Slider
$klenster_general_woo_slide_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_general_woo_slide_section', array(
	'title'			=> esc_html__( 'Woo Related Slider', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for woo related products slider', 'klenster' ),
	'priority'		=> 4,
	'panel'			=> 'theme_woo_panel'
));
$wp_customize->add_section( $klenster_general_woo_slide_section );

//Woo Related Slider
$wp_customize->add_setting('ajax_trigger_klenster_general_woo_slide_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_general_woo_slide_section', array(
	'section'		=> 'klenster_general_woo_slide_section'
)));