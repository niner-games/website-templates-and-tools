<?php

//Layout Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Layout', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Layout
$settings = array(
	'id'			=> 'footer-layout',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Footer Layout', 'klenster' ),
	'description'	=> esc_html__( 'Choose footer layout boxed or wide.', 'klenster' ),
	'choices'		=> array(
		'boxed'		=> esc_html__( 'Boxed', 'klenster' ),
		'wide'		=> esc_html__( 'Wide', 'klenster' )
	),
	'default'		=> 'wide',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Template
$settings = array(
	'id'			=> 'footer-template',
	'type'			=> 'radioimage',
	'title'			=> esc_html__( 'Footer Template', 'klenster' ),
	'description'	=> esc_html__( 'Choose footer template. Current footer layout needed option values you can see after refresh this customizer page.', 'klenster' ),
	'default'		=> '1',
	'items' 		=> array(
		'1'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/footer-layouts/1.jpg',
		'2'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/footer-layouts/2.jpg',
		'3'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/footer-layouts/3.jpg',
		'4'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/footer-layouts/4.jpg',
		'5'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/footer-layouts/5.jpg',
		'6'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/footer-layouts/6.jpg',
		'7'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/footer-layouts/7.jpg',
		'8'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/footer-layouts/8.jpg',
		'custom'=> KLENSTER_ADMIN_URL . '/customizer/assets/images/footer-layouts/custom.jpg'
	),
	'cols'			=> '1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Items
$settings = array(
	'id'			=> 'footer-items',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Footer Items', 'klenster' ),
	'description'	=> esc_html__( 'Needed footer items drag from disabled and put enabled.', 'klenster' ),
	'default' 		=> array(
		'Enabled'  => array(
			'footer-middle'	=> esc_html__( 'Footer Middle', 'klenster' ),
			'footer-bottom'	=> esc_html__( 'Footer Bottom', 'klenster' )
		),
		'disabled' => array(
			'footer-top' 	=> esc_html__( 'Footer Top', 'klenster' )
		)
	),
	'required'		=> array( 'footer-template', '=', 'custom' ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Layout End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Style Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Style', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Back to Top
$settings = array(
	'id'			=> 'back-to-top',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Back to Top', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable back to top icon.', 'klenster' ),
	'default'		=> 1,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Back to Top Button Position
$settings = array(
	'id'			=> 'back-to-top-position',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Back to Top Button Position', 'klenster' ),
	'description'	=> esc_html__( 'Choose position right/left for back to top button.', 'klenster' ),
	'choices'		=> array(
		'right'		=> esc_html__( 'Right', 'klenster' ),
		'left'		=> esc_html__( 'Left', 'klenster' )
	),
	'default'		=> 'right',
	'required'		=> array( 'back-to-top', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Hidden Footer
$settings = array(
	'id'			=> 'hidden-footer',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Hidden Footer', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable hidden footer.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Link Color
$settings = array(
	'id'			=> 'footer-link-color',
	'type'			=> 'link',
	'title'			=> esc_html__( 'Footer Link Color', 'klenster' ),
	'description'	=> esc_html__( 'Choose footer general link color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Border
$settings = array(
	'id'			=> 'footer-border',
	'type'			=> 'border',
	'title'			=> esc_html__( 'Footer Border', 'klenster' ),
	'description'	=> esc_html__( 'Here you can set border. No need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Padding Option
$settings = array(
	'id'			=> 'footer-padding',
	'type'			=> 'dimension',
	'title'			=> esc_html__( 'Footer Padding Option', 'klenster' ),
	'description'	=> esc_html__( 'Here no need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Background
$settings = array(
	'id'			=> 'footer-background',
	'type'			=> 'background',
	'title'			=> esc_html__( 'Footer Background', 'klenster' ),
	'description'	=> esc_html__( 'This is settings for footer background.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Background Overlay
$settings = array(
	'id'			=> 'footer-background-overlay',
	'type'			=> 'alpha',
	'title'			=> esc_html__( 'Footer Background Overlay', 'klenster' ),
	'description'	=> esc_html__( 'Choose footer background overlay color and opacity.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Style End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );