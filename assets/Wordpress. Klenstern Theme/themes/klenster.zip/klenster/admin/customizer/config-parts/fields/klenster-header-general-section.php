<?php

//Header Layout Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Layout', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Layout
$settings = array(
	'id'			=> 'header-layout',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Header Width', 'klenster' ),
	'description'	=> esc_html__( 'Choose header width boxed or wide.', 'klenster' ),
	'choices'		=> array(
		'boxed'		=> esc_html__( 'Boxed', 'klenster' ),
		'wide'		=> esc_html__( 'Wide', 'klenster' ),
		'full'		=> esc_html__( 'Full Width', 'klenster' )
	),
	'default'		=> 'wide',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Template
$settings = array(
	'id'			=> 'header-template',
	'type'			=> 'radioimage',
	'title'			=> esc_html__( 'Header Template', 'klenster' ),
	'description'	=> esc_html__( 'Choose header template. Current header layout needed option values you can see after refresh this customizer page.', 'klenster' ),
	'default'		=> '1',
	'items' 		=> array(
		'1'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/1.jpg',
		'2'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/2.jpg',
		'3'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/3.jpg',
		'4'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/4.jpg',
		'5'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/5.jpg',
		'6'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/6.jpg',
		'7'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/7.jpg',
		'8'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/8.jpg',
		'9'		=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/9.jpg',
		'10'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/10.jpg',
		'11'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/11.jpg',
		'12'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/12.jpg',
		'13'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/13.jpg',
		'vertical'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/14.jpg',
		'custom'=> KLENSTER_ADMIN_URL . '/customizer/assets/images/header-layouts/custom.jpg'
	),
	'cols'			=> '1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Type
$settings = array(
	'id'			=> 'header-type',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Header Type', 'klenster' ),
	'description'	=> esc_html__( 'Select header type for matching your site. If you choose left/right header type, manage under "Header -> Left/Right Navbar"', 'klenster' ),
	'choices'		=> array(
		'default'		=> esc_html__( 'Default', 'klenster' ),
		'left-sticky'	=> esc_html__( 'Left Nav', 'klenster' ),
		'right-sticky'	=> esc_html__( 'Right Nav', 'klenster' ),
	),
	'default'		=> 'default',
	'required'		=> array( 'header-template', '=', 'custom' ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Items
$settings = array(
	'id'			=> 'header-items',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Header Items', 'klenster' ),
	'description'	=> esc_html__( 'Needed items for header, drag from disabled and put enabled.', 'klenster' ),
	'default' 		=> array(
		'Normal' 	=> array(
			'header-nav'	=> esc_html__( 'Nav Bar', 'klenster' )
		),
		'Sticky' 	=> array(),
		'disabled' 	=> array(
			'header-topbar'	=> esc_html__( 'Top Bar', 'klenster' ),
			'header-logo'	=> esc_html__( 'Logo Section', 'klenster' )
		)
	),
	'required'		=> array( 'header-type', '=', 'default' ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Clik and Edit Header Layouts End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Clik and Edit Header Style
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Style', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Background Settings
$settings = array(
	'id'			=> 'header-background',
	'type'			=> 'background',
	'title'			=> esc_html__( 'Header Background Settings', 'klenster' ),
	'description'	=> esc_html__( 'This is settings for header background with image, color, etc.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Dropdown Menu Background
$settings = array(
	'id'			=> 'dropdown-menu-background',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Dropdown Menu Background', 'klenster' ),
	'description'	=> esc_html__( 'Choose dropdown menu background color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Dropdown Menu Color
$settings = array(
	'id'			=> 'dropdown-menu-link-color',
	'type'			=> 'link',
	'title'			=> esc_html__( 'Dropdown Menu Color', 'klenster' ),
	'description'	=> esc_html__( 'Choose dropdown menu link color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Dropdown Menu Border
$settings = array(
	'id'			=> 'dropdown-menu-border',
	'type'			=> 'border',
	'title'			=> esc_html__( 'Dropdown Menu Border', 'klenster' ),
	'description'	=> esc_html__( 'Here you can set border. No need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Clik and Edit Header Style End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Label Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Custom Text', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Address Label
$settings = array(
	'id'			=> 'header-address-label',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Address Label', 'klenster' ),
	'description'	=> esc_html__( 'This is the address label field, you can assign here any label custom text.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Address Custom Text
$settings = array(
	'id'			=> 'header-address-text',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Address Custom Text', 'klenster' ),
	'description'	=> esc_html__( 'This is the address field, you can assign here any custom text. Few HTML allowed here.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Phone Number Label
$settings = array(
	'id'			=> 'header-phone-label',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Phone Number Label', 'klenster' ),
	'description'	=> esc_html__( 'This is the phone number label field, you can assign here any phone label custom text.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Phone Number Custom Text
$settings = array(
	'id'			=> 'header-phone-text',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Phone Number Custom Text', 'klenster' ),
	'description'	=> esc_html__( 'This is the phone number field, you can assign here any custom text. Few HTML allowed here.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Email Label
$settings = array(
	'id'			=> 'header-email-label',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Email Label', 'klenster' ),
	'description'	=> esc_html__( 'This is the email label field, you can assign here any email custom label text.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Email Custom Text
$settings = array(
	'id'			=> 'header-email-text',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Email Custom Text', 'klenster' ),
	'description'	=> esc_html__( 'This is the email field, you can assign here any email id. Example companyname@yourdomain.com', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Label End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Advanced Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Advanced', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Absolute
$settings = array(
	'id'			=> 'header-absolute',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Header Absolute', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable header absolute option to show transparent header for page.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Sticky Part
$settings = array(
	'id'			=> 'sticky-part',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Header Sticky Part', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable stciky part to sticky which items are placed in sticky part at header items.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Sticky Scroll Up
$settings = array(
	'id'			=> 'sticky-part-scrollup',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Sticky Scroll Up', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable stciky part to sticky only scroll up. This also only sticky which items are placed in Sticky Part at Header Items.', 'klenster' ),
	'default'		=> 0,
	'required'		=> array( 'sticky-part', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Main Menu Type
$settings = array(
	'id'			=> 'mainmenu-menutype',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Main Menu Type', 'klenster' ),
	'description'	=> esc_html__( 'This is settings for mainmenu.', 'klenster' ),
	'choices'		=> array(
		'advanced' => esc_html__( 'Advanced Menu', 'klenster' ),
		'normal' => esc_html__( 'Normal Menu', 'klenster' ),
	),
	'default'		=> 'normal',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Menu Tag
$settings = array(
	'id'			=> 'menu-tag',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Menu Tag', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable menu tag for menu items like Hot, Trend, New.', 'klenster' ),
	'default'		=> 0,
	'required'		=> array( 'mainmenu-menutype', '=', 'advanced' ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Hot Menu Tag Text
$settings = array(
	'id'			=> 'menu-tag-hot-text',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Hot Menu Tag Text', 'klenster' ),
	'description'	=> esc_html__( 'Set this text to show hot menu tag.', 'klenster' ),
	'default'		=> esc_html__( 'Hot', 'klenster' ),
	'required'		=> array( 'menu-tag', '=', 1 ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Hot Menu Tag Background
$settings = array(
	'id'			=> 'menu-tag-hot-bg',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Hot Menu Tag Background', 'klenster' ),
	'description'	=> esc_html__( 'Set this text to show hot menu tag.', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'menu-tag', '=', 1 ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//New Menu Tag Text
$settings = array(
	'id'			=> 'menu-tag-new-text',
	'type'			=> 'text',
	'title'			=> esc_html__( 'New Menu Tag Text', 'klenster' ),
	'description'	=> esc_html__( 'Set this text to show new menu tag.', 'klenster' ),
	'default'		=> esc_html__( 'New', 'klenster' ),
	'required'		=> array( 'menu-tag', '=', 1 ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//New Menu Tag Background
$settings = array(
	'id'			=> 'menu-tag-new-bg',
	'type'			=> 'color',
	'title'			=> esc_html__( 'New Menu Tag Background', 'klenster' ),
	'description'	=> esc_html__( 'Set new menu tag background color.', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'menu-tag', '=', 1 ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Trend Menu Tag Text
$settings = array(
	'id'			=> 'menu-tag-trend-text',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Trend Menu Tag Text', 'klenster' ),
	'description'	=> esc_html__( 'Set this text to show trend menu tag.', 'klenster' ),
	'default'		=> esc_html__( 'Trend', 'klenster' ),
	'required'		=> array( 'menu-tag', '=', 1 ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Trend Menu Tag Background
$settings = array(
	'id'			=> 'menu-tag-trend-bg',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Trend Menu Tag Background', 'klenster' ),
	'description'	=> esc_html__( 'Set trend menu tag background color.', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'menu-tag', '=', 1 ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Secondary Menu
$settings = array(
	'id'			=> 'secondary-menu',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Secondary Menu', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable secondary menu.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Secondary Menu Type
$settings = array(
	'id'			=> 'secondary-menu-type',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Secondary Menu Type', 'klenster' ),
	'description'	=> esc_html__( 'Choose secondary menu type.', 'klenster' ),
	'choices'		=> array(
		'left-push'		=> esc_html__( 'Left Push', 'klenster' ),
		'left-overlay'	=> esc_html__( 'Left Overlay', 'klenster' ),
		'right-push'	=> esc_html__( 'Right Push', 'klenster' ),
		'right-overlay'	=> esc_html__( 'Right Overlay', 'klenster' ),
		'full-overlay'	=> esc_html__( 'Full Page Overlay', 'klenster' )
	),
	'default'		=> 'right-overlay',
	'required'		=> array( 'secondary-menu', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Secondary Menu Space Width
$settings = array(
	'id'			=> 'secondary-menu-space-width',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Secondary Menu Space Width', 'klenster' ),
	'description'	=> esc_html__( 'Increase or decrease secondary menu space width. this options only use if you enable secondary menu. Here no need to specify dimensions like px, em, etc.. Example 350', 'klenster' ),
	'default'		=> '350',
	'required'		=> array( 'secondary-menu', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Slider Position
$settings = array(
	'id'			=> 'header-slider-position',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Header Slider Position', 'klenster' ),
	'description'	=> esc_html__( 'Select header slider position matching your page.', 'klenster' ),
	'choices'		=> array(
		'bottom'	=> esc_html__( 'Below Header', 'klenster' ),
		'top'		=> esc_html__( 'Above Header', 'klenster' ),
		'none'		=> esc_html__( 'None', 'klenster' )
	),
	'default'		=> 'none',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Search Toggle Modal
$settings = array(
	'id'			=> 'search-toggle-form',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Search Toggle Modal', 'klenster' ),
	'description'	=> esc_html__( 'Select serach box toggle modal.', 'klenster' ),
	'choices'		=> array(
		'1'	=> esc_html__( 'Full Screen Search', 'klenster' ),
		'2' => esc_html__( 'Text Box Toggle Search', 'klenster' ),
		'3' => esc_html__( 'Full Bar Toggle Search', 'klenster' ),
		'4' => esc_html__( 'Bottom Seach Box Toggle', 'klenster' ),
	),
	'default'		=> '1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Advanced End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );