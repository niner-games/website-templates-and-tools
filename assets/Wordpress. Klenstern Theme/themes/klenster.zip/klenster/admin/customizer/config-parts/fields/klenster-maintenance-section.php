<?php

//Maintenance Mode Option
$settings = array(
	'id'			=> 'maintenance-mode',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Maintenance Mode Option', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable maintenance mode.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Maintenance Type
$settings = array(
	'id'			=> 'maintenance-type',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Maintenance Type', 'klenster' ),
	'description'	=> esc_html__( 'Select maintenance mode page coming soon or maintenance.', 'klenster' ),
	'choices'		=> array(
		'cs'		=> esc_html__( 'Coming Soon', 'klenster' ),
		'mn'		=> esc_html__( 'Maintenance', 'klenster' ),
		'cus'		=> esc_html__( 'Custom', 'klenster' )
	),
	'default'		=> 'cs',
	'required'		=> array( 'maintenance-mode', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Maintenance Custom Page
$settings = array(
	'id'			=> 'maintenance-custom',
	'type'			=> 'pages',
	'title'			=> esc_html__( 'Maintenance Custom Page', 'klenster' ),
	'description'	=> esc_html__( 'Enter service slug for register custom post type.', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'maintenance-mode', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Phone Number
$settings = array(
	'id'			=> 'maintenance-phone',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Phone Number', 'klenster' ),
	'description'	=> esc_html__( 'Enter phone number shown on when maintenance mode actived', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'maintenance-mode', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Email Id
$settings = array(
	'id'			=> 'maintenance-email',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Email Id', 'klenster' ),
	'description'	=> esc_html__( 'Enter email id shown on when maintenance mode actived', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'maintenance-mode', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Address
$settings = array(
	'id'			=> 'maintenance-address',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Address', 'klenster' ),
	'description'	=> esc_html__( 'Place here your address and info', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'maintenance-mode', '=', 1 ),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );