<?php

//Comments Type
$settings = array(
	'id'			=> 'comments-type',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Comments Type', 'klenster' ),
	'description'	=> esc_html__( 'This option will be showing comment like facebook or default wordpress.', 'klenster' ),
	'choices'		=> array(
		'wp' 	=> esc_html__( 'WordPress Comment', 'klenster' ),
		'fb'  	=> esc_html__( 'Facebook Comment', 'klenster' )
	),
	'default'		=> 'wp',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Comments Like
$settings = array(
	'id'			=> 'comments-like',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Comments Like', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable to show or hide comments likes to single post comments.', 'klenster' ),
	'default'		=> 0,
	'required'		=> array( 'comments-type', '=', 'wp' ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Comments Share
$settings = array(
	'id'			=> 'comments-share',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Comments Share', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable to show or hide comments share to single post comments.', 'klenster' ),
	'default'		=> 0,
	'required'		=> array( 'comments-type', '=', 'wp' ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Facebook Developer API
$settings = array(
	'id'			=> 'fb-developer-key',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Facebook Developer API', 'klenster' ),
	'description'	=> esc_html__( 'Enter facebook developer API key.', 'klenster' ),
	'default'		=> '',
	'required'		=> array( 'comments-type', '=', 'fb' ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Number of Comments
$settings = array(
	'id'			=> 'fb-comments-number',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Number of Comments', 'klenster' ),
	'description'	=> esc_html__( 'Enter number of comments to display.', 'klenster' ),
	'default'		=> '5',
	'required'		=> array( 'comments-type', '=', 'fb' ),
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );