<?php

//Page Loader
$settings = array(
	'id'			=> 'page-loader',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Page Loader', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable page loader', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Page Loader Image
$settings = array(
	'id'			=> 'page-loader-img',
	'type'			=> 'image',
	'title'			=> esc_html__( 'Page Loader Image', 'klenster' ),
	'description'	=> esc_html__( 'Upload Page Loader Image', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1,
	'required'		=> array( 'page-loader', '=', 1 )
);
KlensterCustomizerConfig::buildFields( $settings );

//Infinite Scroll Image
$settings = array(
	'id'			=> 'infinite-loader-img',
	'type'			=> 'image',
	'title'			=> esc_html__( 'Infinite Scroll Image', 'klenster' ),
	'description'	=> esc_html__( 'Upload Infinite Scroll Image', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );