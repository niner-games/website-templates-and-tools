<?php

//Layout Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Layout', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Testimonial Template
$settings = array(
	'id'			=> 'testimonial-page-template',
	'type'			=> 'radioimage',
	'title'			=> esc_html__( 'Testimonial Template', 'klenster' ),
	'description'	=> esc_html__( 'Choose your current testimonial single outer template.', 'klenster' ),
	'default'		=> 'no-sidebar',
	'items' 		=> array(
		'no-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/1.png',
		'right-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/2.png',
		'left-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/3.png',
		'both-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/4.png'		
	),
	'cols'			=> '4',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Left Sidebar
$settings = array(
	'id'			=> 'testimonial-left-sidebar',
	'type'			=> 'sidebars',
	'title'			=> esc_html__( 'Left Sidebar', 'klenster' ),
	'description'	=> esc_html__( 'Select widget area for showing on left side.', 'klenster' ),
	'default'		=> 'sidebar-1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Right Sidebar
$settings = array(
	'id'			=> 'testimonial-right-sidebar',
	'type'			=> 'sidebars',
	'title'			=> esc_html__( 'Right Sidebar', 'klenster' ),
	'description'	=> esc_html__( 'Select widget area for showing on right side.', 'klenster' ),
	'default'		=> 'sidebar-1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Custom Post Type Testimonial Settings
$settings = array(
	'id'			=> 'testimonial-title-opt',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Testimonial Title', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable page title on single testimonial page.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Layout End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Advanced Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Advanced', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Custom Post Type Testimonial Slug
$settings = array(
	'id'			=> 'cpt-testimonial-slug',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Testimonial Slug', 'klenster' ),
	'description'	=> esc_html__( 'Enter testimonial slug for register custom post type, after entered new slug click Publish button. Then go to WordPress Settings -> Permalinks -> Click save changes button to regenerate the permalinks.', 'klenster' ),
	'default'		=> 'testimonial',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Sidebar on Mobile
$settings = array(
	'id'			=> 'testimonial-page-hide-sidebar',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Sidebar on Mobile', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable to show or hide sidebar on mobile.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Advanced End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );