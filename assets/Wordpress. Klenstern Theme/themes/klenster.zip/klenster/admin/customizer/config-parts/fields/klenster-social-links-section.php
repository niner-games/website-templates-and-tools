<?php

//Social Iocns Type
$settings = array(
	'id'			=> 'social-icons-type',
	'type'			=> 'radioimage',
	'title'			=> esc_html__( 'Social Iocns Type', 'klenster' ),
	'description'	=> esc_html__( 'Choose your social icons type.', 'klenster' ),
	'default'		=> 'circled',
	'items' 		=> array(
		'squared'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/social-icons/1.png',
		'rounded'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/social-icons/2.png',
		'circled'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/social-icons/3.png'		
	),
	'cols'			=> '1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Footer Bottom Social Iocns Type
$settings = array(
	'id'			=> 'social-icons-type-footer',
	'type'			=> 'radioimage',
	'title'			=> esc_html__( 'Footer Bottom Social Iocns Type', 'klenster' ),
	'description'	=> esc_html__( 'Choose footer bottom social icons type.', 'klenster' ),
	'default'		=> 'circled',
	'items' 		=> array(
		'squared'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/social-icons/1.png',
		'rounded'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/social-icons/2.png',
		'circled'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/social-icons/3.png'		
	),
	'cols'			=> '1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Social Link Target
$settings = array(
	'id'			=> 'social-link-target',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Social Link Target', 'klenster' ),
	'description'	=> esc_html__( 'Social link target like _blank, _self or _parent.', 'klenster' ),
	'choices'		=> array(
		'_blank'		=> esc_html__( 'Blank', 'klenster' ),
		'_self'			=> esc_html__( 'Self', 'klenster' ),
		'_parent'		=> esc_html__( 'Parent', 'klenster' )
	),
	'default'		=> '_self',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Social Icons Fore
$settings = array(
	'id'			=> 'social-icons-fore',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Social Icons Fore', 'klenster' ),
	'description'	=> esc_html__( 'Social icons fore color settings.', 'klenster' ),
	'choices'		=> array(
		'black'		=> esc_html__( 'Black', 'klenster' ),
		'white'		=> esc_html__( 'White', 'klenster' ),
		'own'		=> esc_html__( 'Own Color', 'klenster' )
	),
	'default'		=> 'white',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Social Icons Fore
$settings = array(
	'id'			=> 'social-icons-hfore',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Social Icons Fore Hover', 'klenster' ),
	'description'	=> esc_html__( 'Social icons fore hover color settings.', 'klenster' ),
	'choices'		=> array(
		'h-black'	=> esc_html__( 'Black', 'klenster' ),
		'h-white'	=> esc_html__( 'White', 'klenster' ),
		'h-own'		=> esc_html__( 'Own Color', 'klenster' )
	),
	'default'		=> 'h-own',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Social Icons Background
$settings = array(
	'id'			=> 'social-icons-bg',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Social Icons Background', 'klenster' ),
	'description'	=> esc_html__( 'Social icons background color settings.', 'klenster' ),
	'choices'		=> array(
		'bg-black'		=> esc_html__( 'Black', 'klenster' ),
		'bg-white'		=> esc_html__( 'White', 'klenster' ),
		'bg-light'		=> esc_html__( 'RGBA Light', 'klenster' ),
		'bg-dark'		=> esc_html__( 'RGBA Dark', 'klenster' ),
		'bg-own'		=> esc_html__( 'Own Color', 'klenster' ),
		'bg-transparent'=> esc_html__( 'Transparent', 'klenster' )
	),
	'default'		=> 'bg-own',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Social Icons Background Hover
$settings = array(
	'id'			=> 'social-icons-hbg',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Social Icons Background Hover', 'klenster' ),
	'description'	=> esc_html__( 'Social icons background hover color settings.', 'klenster' ),
	'choices'		=> array(
		'hbg-black'		=> esc_html__( 'Black', 'klenster' ),
		'hbg-white'		=> esc_html__( 'White', 'klenster' ),
		'hbg-light'		=> esc_html__( 'RGBA Light', 'klenster' ),
		'hbg-dark'		=> esc_html__( 'RGBA Dark', 'klenster' ),
		'hbg-own'		=> esc_html__( 'Own Color', 'klenster' ),
		'hbg-theme'		=> esc_html__( 'Theme Color', 'klenster' ),
		'hbg-transparent'		=> esc_html__( 'Transparent', 'klenster' )
	),
	'default'		=> 'hbg-white',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Facebook
$settings = array(
	'id'			=> 'social-fb',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Facebook', 'klenster' ),
	'description'	=> esc_html__( 'Enter the facebook link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Twitter
$settings = array(
	'id'			=> 'social-twitter',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Twitter', 'klenster' ),
	'description'	=> esc_html__( 'Enter the twitter link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Instagram
$settings = array(
	'id'			=> 'social-instagram',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Instagram', 'klenster' ),
	'description'	=> esc_html__( 'Enter the instagram link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Pinterest
$settings = array(
	'id'			=> 'social-pinterest',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Pinterest', 'klenster' ),
	'description'	=> esc_html__( 'Enter the pinterest link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Youtube
$settings = array(
	'id'			=> 'social-youtube',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Youtube', 'klenster' ),
	'description'	=> esc_html__( 'Enter the youtube link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Vimeo
$settings = array(
	'id'			=> 'social-vimeo',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Vimeo', 'klenster' ),
	'description'	=> esc_html__( 'Enter the vimeo link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Soundcloud
$settings = array(
	'id'			=> 'social-soundcloud',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Soundcloud', 'klenster' ),
	'description'	=> esc_html__( 'Enter the soundcloud link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Yahoo
$settings = array(
	'id'			=> 'social-yahoo',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Yahoo', 'klenster' ),
	'description'	=> esc_html__( 'Enter the yahoo link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Tumblr
$settings = array(
	'id'			=> 'social-tumblr',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Tumblr', 'klenster' ),
	'description'	=> esc_html__( 'Enter the tumblr link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Mailto
$settings = array(
	'id'			=> 'social-mailto',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Mailto', 'klenster' ),
	'description'	=> esc_html__( 'Enter the mailto link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Flickr
$settings = array(
	'id'			=> 'social-flickr',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Flickr', 'klenster' ),
	'description'	=> esc_html__( 'Enter the flickr link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Dribbble
$settings = array(
	'id'			=> 'social-dribbble',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Dribbble', 'klenster' ),
	'description'	=> esc_html__( 'Enter the dribbble link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//LinkedIn
$settings = array(
	'id'			=> 'social-linkedin',
	'type'			=> 'text',
	'title'			=> esc_html__( 'LinkedIn', 'klenster' ),
	'description'	=> esc_html__( 'Enter the linkedin link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//RSS
$settings = array(
	'id'			=> 'social-rss',
	'type'			=> 'text',
	'title'			=> esc_html__( 'RSS', 'klenster' ),
	'description'	=> esc_html__( 'Enter the rss link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );
//Tiktok
$settings = array(
	'id'			=> 'social-tiktok',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Tiktok', 'klenster' ),
	'description'	=> esc_html__( 'Enter the Tiktok link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );
//whatsapp
$settings = array(
	'id'			=> 'social-whatsapp',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Whatsapp', 'klenster' ),
	'description'	=> esc_html__( 'Enter the Whatsapp link. If no link means just leave it blank', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );