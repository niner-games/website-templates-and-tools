<?php

//Layout Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Layout', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Events Template
$settings = array(
	'id'			=> 'events-page-template',
	'type'			=> 'radioimage',
	'title'			=> esc_html__( 'Events Template', 'klenster' ),
	'description'	=> esc_html__( 'Choose your current events single outer template.', 'klenster' ),
	'default'		=> 'no-sidebar',
	'items' 		=> array(
		'no-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/1.png',
		'right-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/2.png',
		'left-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/3.png',
		'both-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/4.png'		
	),
	'cols'			=> '4',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Left Sidebar
$settings = array(
	'id'			=> 'events-left-sidebar',
	'type'			=> 'sidebars',
	'title'			=> esc_html__( 'Left Sidebar', 'klenster' ),
	'description'	=> esc_html__( 'Select widget area for showing on left side.', 'klenster' ),
	'default'		=> 'sidebar-1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Right Sidebar
$settings = array(
	'id'			=> 'events-right-sidebar',
	'type'			=> 'sidebars',
	'title'			=> esc_html__( 'Right Sidebar', 'klenster' ),
	'description'	=> esc_html__( 'Select widget area for showing on right side.', 'klenster' ),
	'default'		=> 'sidebar-1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Custom Post Type Events Layout
$settings = array(
	'id'			=> 'cpt-event-layout',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Events Layout', 'klenster' ),
	'description'	=> esc_html__( 'Select single event layout model.', 'klenster' ),
	'choices'		=> array(
			'1' 		=> esc_html__( 'Model 1', 'klenster' ),
			'2' 		=> esc_html__( 'Model 2', 'klenster' )
	),
	'default'		=> '1',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Custom Post Type Events Settings
$settings = array(
	'id'			=> 'event-title-opt',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Events Title', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable page title on single event page.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Layout End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Advanced Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Advanced', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Custom Post Type Events Slug
$settings = array(
	'id'			=> 'cpt-events-slug',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Events Slug', 'klenster' ),
	'description'	=> esc_html__( 'Enter events slug for register custom post type, after entered new slug click Publish button. Then go to WordPress Settings -> Permalinks -> Click save changes button to regenerate the permalinks.', 'klenster' ),
	'default'		=> 'event',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Sidebar on Mobile
$settings = array(
	'id'			=> 'events-page-hide-sidebar',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Sidebar on Mobile', 'klenster' ),
	'description'	=> esc_html__( 'Enable/Disable to show or hide sidebar on mobile.', 'klenster' ),
	'default'		=> 0,
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Advanced End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );