<?php

//Theme Option -> Skin
$theme_skin_panel = new Klenster_WP_Customize_Panel( $wp_customize, 'theme_skin_panel', array(
	'title'			=> esc_html__( 'Skin', 'klenster' ),
	'description'	=> esc_html__( 'These are theme skin/color options', 'klenster' ),
	'priority'		=> 3,
	'panel'			=> 'klenster_theme_panel'
));
$wp_customize->add_panel( $theme_skin_panel );

//General -> Theme Skin
$klenster_theme_skin_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_theme_skin_section', array(
	'title'			=> esc_html__( 'Theme Skin', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for theme skin', 'klenster' ),
	'priority'		=> 1,
	'panel'			=> 'theme_skin_panel'
));
$wp_customize->add_section( $klenster_theme_skin_section );

//Theme Skin
$wp_customize->add_setting('ajax_trigger_klenster_theme_skin_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_theme_skin_section', array(
	'section'		=> 'klenster_theme_skin_section'
)));

//General -> Body Background
$klenster_body_skin_section = new Klenster_WP_Customize_Section( $wp_customize, 'klenster_body_skin_section', array(
	'title'			=> esc_html__( 'Body Background', 'klenster' ),
	'description'	=> esc_html__( 'This is the setting for theme body background.', 'klenster' ),
	'priority'		=> 2,
	'panel'			=> 'theme_skin_panel'
));
$wp_customize->add_section( $klenster_body_skin_section );

//Body Background
$wp_customize->add_setting('ajax_trigger_klenster_body_skin_section', array(
	'default'           => '',
	'sanitize_callback' 	=> 'esc_attr'
));
$wp_customize->add_control( new Trigger_Custom_control( $wp_customize, 'ajax_trigger_klenster_body_skin_section', array(
	'section'		=> 'klenster_body_skin_section'
)));