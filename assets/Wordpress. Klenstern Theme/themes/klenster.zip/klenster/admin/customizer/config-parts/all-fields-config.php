<?php

//Text
$settings = array(
	'id'			=> 'ajax-trigger-text-test',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Text Field', 'klenster' ),
	'description'	=> esc_html__( 'This is text field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0,
	'instant'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Textarea
$settings = array(
	'id'			=> 'ajax-trigger-textarea-test',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Textarea Field', 'klenster' ),
	'description'	=> esc_html__( 'This is textarea field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0,
	'instant'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Select
$settings = array(
	'id'			=> 'ajax-trigger-select-test',
	'type'			=> 'select',
	'title'			=> esc_html__( 'Select Field', 'klenster' ),
	'description'	=> esc_html__( 'This is select field', 'klenster' ),
	'choices'		=> array(
		'boxed'		=> esc_html__( 'Boxed', 'klenster' ),
		'wide'		=> esc_html__( 'Wide', 'klenster' )
	),
	'default'		=> 'wide',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Color
$settings = array(
	'id'			=> 'ajax-trigger-color-test',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Color Field', 'klenster' ),
	'description'	=> esc_html__( 'This is color field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Image
$settings = array(
	'id'			=> 'ajax-trigger-image-test',
	'type'			=> 'image',
	'title'			=> esc_html__( 'Image Field', 'klenster' ),
	'description'	=> esc_html__( 'This is image field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Alpha Color
$settings = array(
	'id'			=> 'ajax-trigger-alpha-test',
	'type'			=> 'alpha',
	'title'			=> esc_html__( 'Alpha Field', 'klenster' ),
	'description'	=> esc_html__( 'This is alpha field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Background
$settings = array(
	'id'			=> 'ajax-trigger-bg-test',
	'type'			=> 'background',
	'title'			=> esc_html__( 'Background Field', 'klenster' ),
	'description'	=> esc_html__( 'This is background field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Border
$settings = array(
	'id'			=> 'ajax-trigger-border-test',
	'type'			=> 'border',
	'title'			=> esc_html__( 'Border Field', 'klenster' ),
	'description'	=> esc_html__( 'This is border field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Dimension
$settings = array(
	'id'			=> 'ajax-trigger-dimension-test',
	'type'			=> 'dimension',
	'title'			=> esc_html__( 'Dimension Field', 'klenster' ),
	'description'	=> esc_html__( 'This is dimension field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Links
$settings = array(
	'id'			=> 'ajax-trigger-link-color-test',
	'type'			=> 'link',
	'title'			=> esc_html__( 'Link Color Field', 'klenster' ),
	'description'	=> esc_html__( 'This is link color field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Multi Check
$settings = array(
	'id'			=> 'ajax-trigger-multi-check-test',
	'type'			=> 'multicheck',
	'title'			=> esc_html__( 'Multi Check Field', 'klenster' ),
	'description'	=> esc_html__( 'This is multi check field', 'klenster' ),
	'default'		=> '',
	'items' 		=> array(
		'portfolio'	    => esc_html__( 'Portfolio', 'klenster' ),
		'team'	        => esc_html__( 'Team', 'klenster' ),
		'testimonial'	=> esc_html__( 'Testimonial', 'klenster' ),
		'events'	    => esc_html__( 'Events', 'klenster' ),
		'services'	    => esc_html__( 'Services', 'klenster' ),
	),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Radio Image
$settings = array(
	'id'			=> 'ajax-trigger-radio-image-test',
	'type'			=> 'radioimage',
	'title'			=> esc_html__( 'Radio Image Field', 'klenster' ),
	'description'	=> esc_html__( 'This is radio image field', 'klenster' ),
	'default'		=> 'no-sidebar',
	'items' 		=> array(
		'no-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/1.png',
		'right-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/2.png',
		'left-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/3.png',
		'both-sidebar'	=> KLENSTER_ADMIN_URL . '/customizer/assets/images/page-layouts/4.png'		
	),
	'cols'			=> '4',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Sidebars
$settings = array(
	'id'			=> 'ajax-trigger-sidebars-test',
	'type'			=> 'sidebars',
	'title'			=> esc_html__( 'Sidebar Field', 'klenster' ),
	'description'	=> esc_html__( 'This is sidebar field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Toggle Switch
$settings = array(
	'id'			=> 'ajax-trigger-toggle-test',
	'type'			=> 'toggle',
	'title'			=> esc_html__( 'Toggle Switch Field', 'klenster' ),
	'description'	=> esc_html__( 'This is toggle switch field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Pages
$settings = array(
	'id'			=> 'ajax-trigger-pages-test',
	'type'			=> 'pages',
	'title'			=> esc_html__( 'Pages Field', 'klenster' ),
	'description'	=> esc_html__( 'This is pages field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Height Width
$settings = array(
	'id'			=> 'ajax-trigger-hw-test',
	'type'			=> 'hw',
	'title'			=> esc_html__( 'Height Width Field', 'klenster' ),
	'description'	=> esc_html__( 'This is height width field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 0
);
KlensterCustomizerConfig::buildFields( $settings );

//Fonts
$settings = array(
	'id'			=> 'ajax-trigger-fonts-test',
	'type'			=> 'fonts',
	'title'			=> esc_html__( 'Google Fonts Field', 'klenster' ),
	'description'	=> esc_html__( 'This is fonts field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Drag Drop
$settings = array(
	'id'			=> 'ajax-trigger-dd-test',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Drag Drop Field', 'klenster' ),
	'description'	=> esc_html__( 'This is drag and drop field.', 'klenster' ),
	'default' 		=> array(
		'Left' 	=> array(
			'date'		=> esc_html__( 'Date', 'klenster' ),
			'client'	=> esc_html__( 'Client', 'klenster' ),
			'duration'	=> esc_html__( 'Duration', 'klenster' )		
		),
		'Right' 	=> array(
			'category'	=> esc_html__( 'Category', 'klenster' ),
			'tag'		=> esc_html__( 'Tags', 'klenster' ),
			'share'		=> esc_html__( 'Share', 'klenster' )			
		),
		'Disabled' 	=> array(
			'estimation'=> esc_html__( 'Estimation', 'klenster' ),
			'url'		=> esc_html__( 'Url', 'klenster' ),
			'place'		=> esc_html__( 'Place', 'klenster' )
		)
	),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Export
$settings = array(
	'id'			=> 'ajax-trigger-export-test',
	'type'			=> 'export',
	'title'			=> esc_html__( 'Export Field', 'klenster' ),
	'description'	=> esc_html__( 'This is export field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Import
$settings = array(
	'id'			=> 'ajax-trigger-import-test',
	'type'			=> 'import',
	'title'			=> esc_html__( 'Import Field', 'klenster' ),
	'description'	=> esc_html__( 'This is import field', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Section Start
$settings = array(
	'type'			=> 'section',
	'label'			=> esc_html__( 'Options Section Title', 'klenster' ),
	'description'	=> esc_html__( 'This is inside option section description.', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Section End
$settings = array(
	'type'			=> 'section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Label Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Header Label Settings', 'klenster' ),
	'description'	=> esc_html__( 'Click to edit address label settings.', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Label End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );