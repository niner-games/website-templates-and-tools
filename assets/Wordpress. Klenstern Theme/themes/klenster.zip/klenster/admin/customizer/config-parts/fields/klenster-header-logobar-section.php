<?php

//Layout Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Layout', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Logo Section Items
$settings = array(
	'id'			=> 'header-logobar-items',
	'type'			=> 'dragdrop',
	'title'			=> esc_html__( 'Header Logo Section Items', 'klenster' ),
	'description'	=> esc_html__( 'Needed header logo section items drag from disabled and put enabled.', 'klenster' ),
	'default' 		=> array(
		'disabled' => array(
			'header-logobar-social'		=> esc_html__( 'Social', 'klenster' ),
			'header-logobar-search'		=> esc_html__( 'Search', 'klenster' ),
			'header-logobar-secondary-toggle'	=> esc_html__( 'Secondary Toggle', 'klenster' ),	
			'header-phone'   			=> esc_html__( 'Phone Number', 'klenster' ),
			'header-address'  			=> esc_html__( 'Address Text', 'klenster' ),
			'header-email'   			=> esc_html__( 'Email', 'klenster' ),
			'header-logobar-menu'   	=> esc_html__( 'Main Menu', 'klenster' ),
			'header-logobar-search-toggle'	=> esc_html__( 'Search Toggle', 'klenster' ),
			'header-logobar-text-1'		=> esc_html__( 'Custom Text 1', 'klenster' ),
			'header-logobar-text-2'		=> esc_html__( 'Custom Text 2', 'klenster' ),
			'header-logobar-text-3'		=> esc_html__( 'Custom Text 3', 'klenster' ),	
			'header-cart'   			=> esc_html__( 'Cart', 'klenster' ),
			'multi-info'   				=> esc_html__( 'Address, Phone, Email', 'klenster' )
		),
		'Left'  => array(
			'header-logobar-logo'		=> esc_html__( 'Logo', 'klenster' ),
			'header-logobar-sticky-logo' => esc_html__( 'Sticky Logo', 'klenster' )											
		),
		'Center' => array(),
		'Right' => array()
	),
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Layout End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Style Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Style', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Logo Section Height
$settings = array(
	'id'			=> 'header-logobar-height',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Header Logo Section Height', 'klenster' ),
	'description'	=> esc_html__( 'Increase or decrease header logo section height. Here no need to put dimension units like px, em etc. Example 50', 'klenster' ),
	'default'		=> '80',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Logo Section Sticky Height
$settings = array(
	'id'			=> 'header-logobar-sticky-height',
	'type'			=> 'text',
	'title'			=> esc_html__( 'Header Logo Section Sticky Height', 'klenster' ),
	'description'	=> esc_html__( 'Increase or decrease header logo section sticky height. Here no need to put dimension units like px, em etc. Example 50', 'klenster' ),
	'default'		=> '80',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Logo Section Background
$settings = array(
	'id'			=> 'header-logobar-background',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Header Logo Section Background', 'klenster' ),
	'description'	=> esc_html__( 'Choose logo section background color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Logo Section Link Color
$settings = array(
	'id'			=> 'header-logobar-link-color',
	'type'			=> 'link',
	'title'			=> esc_html__( 'Header Logo Section Link Color', 'klenster' ),
	'description'	=> esc_html__( 'Choose logo section link color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Logo Section Border
$settings = array(
	'id'			=> 'header-logobar-border',
	'type'			=> 'border',
	'title'			=> esc_html__( 'Header Logo Section Border', 'klenster' ),
	'description'	=> esc_html__( 'Here you can set border. No need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Logo Section Padding Option
$settings = array(
	'id'			=> 'header-logobar-padding',
	'type'			=> 'dimension',
	'title'			=> esc_html__( 'Header Logo Section Padding Option', 'klenster' ),
	'description'	=> esc_html__( 'Here no need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Sticky Logo Section Font Color
$settings = array(
	'id'			=> 'sticky-header-logobar-color',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Header Sticky Logo Section Font Color', 'klenster' ),
	'description'	=> esc_html__( 'Set header sticky logo section font color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Sticky Logo Section Background
$settings = array(
	'id'			=> 'sticky-header-logobar-background',
	'type'			=> 'color',
	'title'			=> esc_html__( 'Header Sticky Logo Section Background', 'klenster' ),
	'description'	=> esc_html__( 'Choose sticky logo section background color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Sticky Logo Section Link Color
$settings = array(
	'id'			=> 'sticky-header-logobar-link-color',
	'type'			=> 'link',
	'title'			=> esc_html__( 'Header Sticky Logo Section Link Color', 'klenster' ),
	'description'	=> esc_html__( 'Choose sticky logo section link color.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Sticky Logo Section Border
$settings = array(
	'id'			=> 'sticky-header-logobar-border',
	'type'			=> 'border',
	'title'			=> esc_html__( 'Header Sticky Logo Section Border', 'klenster' ),
	'description'	=> esc_html__( 'Here you can set border. No need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Header Sticky Logo Section Padding Option
$settings = array(
	'id'			=> 'sticky-header-logobar-padding',
	'type'			=> 'dimension',
	'title'			=> esc_html__( 'Header Sticky Logo Section Padding Option', 'klenster' ),
	'description'	=> esc_html__( 'Here no need to put dimension units like px, em etc. Example 10 10 20 10.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Style End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );

//Custom Text Start
$settings = array(
	'type'			=> 'toggle_section',
	'label'			=> esc_html__( 'Custom Text', 'klenster' ),
	'section_stat'	=> true
);
KlensterCustomizerConfig::buildFields( $settings );

//Logo Section Custom Text 1
$settings = array(
	'id'			=> 'header-logobar-text-1',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Logo Section Custom Text 1', 'klenster' ),
	'description'	=> esc_html__( 'Custom text shows header logo section. Here, you can place shortcode.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Logo Section Custom Text 2
$settings = array(
	'id'			=> 'header-logobar-text-2',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Logo Section Custom Text 2', 'klenster' ),
	'description'	=> esc_html__( 'Custom text shows header logo section. Here, you can place shortcode.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Logo Section Custom Text 3
$settings = array(
	'id'			=> 'header-logobar-text-3',
	'type'			=> 'textarea',
	'title'			=> esc_html__( 'Logo Section Custom Text 3', 'klenster' ),
	'description'	=> esc_html__( 'Custom text shows header logo section. Here, you can place shortcode.', 'klenster' ),
	'default'		=> '',
	'refresh'		=> 1
);
KlensterCustomizerConfig::buildFields( $settings );

//Custom Text End
$settings = array(
	'type'			=> 'toggle_section',
	'section_stat'	=> false
);
KlensterCustomizerConfig::buildFields( $settings );